"""Browser entry points for the SL-DVJ analysis page (runs inside Pyodide, in a web worker).

Every function takes and returns plain JSON-friendly values. Files live in the worker's
in-memory file system: inputs in /in, results in /out/<session>, the summary in /share.
Nothing here touches the network.
"""
from __future__ import annotations

import json
import math
import os
import shutil
import traceback

import matplotlib

matplotlib.use("Agg")

import pandas as pd                                 # noqa: E402

from kitlib.analysis import KitError, N_CHANNELS, run_session, scan_records   # noqa: E402

CFG = "/app/config/lab.json"
IN, OUT, SHARE = "/in", "/out", "/share"



SECTIONS = {"rebound": "Rebound", "landing": "Landing", "stability": "Balance",
            "emg_EMG1": "EMG, vastus lateralis (EMG1)", "emg_EMG2": "EMG, biceps femoris (EMG2)",
            "n1": "Novel N1", "n2": "Novel N2"}
TABLE_COLS = ["section", "measure", "unit", "T1", "T2", "T3", "mean", "SD", "CV %", "MDC95", "n", "definition"]


def _num(x, dp):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return ""
    return "" if v != v else round(v, dp)


def _sig(x, sig=4):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return ""
    if v != v:
        return ""
    if v == 0:
        return 0.0
    return round(v, max(0, sig - 1 - int(math.floor(math.log10(abs(v))))))


def one_table(out_dir: str, suffix: str) -> str:
    """Write one CSV per session: the agreed measures first, then every trial measure."""
    rows = []
    panel = os.path.join(out_dir, f"cycle_phase_panel_{suffix}.csv")
    if os.path.exists(panel):
        for _, r in pd.read_csv(panel, dtype=str, keep_default_na=False).iterrows():
            rows.append({"section": "Agreed measures", "measure": r["metric"], "unit": r["unit"],
                         "T1": r["T1"], "T2": r["T2"], "T3": r["T3"], "mean": _sig(r["mean"]),
                         "SD": _sig(r["sd"]), "CV %": _num(r["cv_pct"], 1), "MDC95": _sig(r["mdc95"]),
                         "n": r["n"], "definition": r["definition"]})
    allm = os.path.join(out_dir, "metrics_by_trial.csv")
    if os.path.exists(allm):
        for _, r in pd.read_csv(allm, dtype=str, keep_default_na=False).iterrows():
            try:
                dp = int(float(r["decimals"])) + 1
            except ValueError:
                dp = 3
            sd = _num(r["sd"], 12)
            rows.append({"section": SECTIONS.get(r["section"], r["section"]), "measure": r["metric"],
                         "unit": r["unit"], "T1": r["T1"], "T2": r["T2"], "T3": r["T3"],
                         "mean": _num(r["mean"], dp), "SD": _num(r["sd"], dp), "CV %": _num(r["cv_pct"], 1),
                         "MDC95": "" if sd == "" else round(2.77 * sd, dp), "n": r["n"],
                         "definition": r["definition"]})
    name = f"SLDVJ_{suffix}.csv"
    pd.DataFrame(rows, columns=TABLE_COLS).to_csv(os.path.join(out_dir, name), index=False, encoding="utf-8-sig")
    return name


def _deliver_only(out_dir: str, keep: list) -> None:
    """Delete every result file the page does not hand out. The two summary tables stay for the Calgary zip."""
    for root, _, fs in os.walk(out_dir):
        for f in fs:
            rel = os.path.relpath(os.path.join(root, f), out_dir)
            if rel not in keep and not f.startswith(("session_summary_", "cycle_phase_panel_")):
                os.remove(os.path.join(root, f))


def _err(exc: BaseException) -> dict:
    if isinstance(exc, KitError):
        return {"ok": False, "error": str(exc)}
    if isinstance(exc, MemoryError):
        return {"ok": False, "error": "the browser ran out of memory. Close other tabs, reload the page "
                                      "and analyse fewer files at a time."}
    return {"ok": False, "error": f"unexpected error ({type(exc).__name__}: {exc})",
            "detail": traceback.format_exc()}


def scan(name: str) -> str:
    """Check one uploaded file. Return the records it holds and the one to use."""
    try:
        found = scan_records(os.path.join(IN, name), CFG)
        recs = [{"record": k, "jumps": n, "channels": c, "seconds": round(d, 1)} for k, n, c, d in found]
        usable = [r for r in recs if r["channels"] >= N_CHANNELS and r["jumps"] > 0]
        if not usable:
            if all(r["channels"] < N_CHANNELS for r in recs):
                most = max(r["channels"] for r in recs)
                raise KitError(f"this file has {most} channels, but the SL-DVJ analysis needs {N_CHANNELS} "
                               "(8 force plate, 2 EMG, 6 accelerometer). Is it a static-balance file?")
            raise KitError("no drop jump was found. A trial needs an empty plate, a first contact, "
                           "a flight and a landing that stays on the plate for at least 1 s.")
        best = max(usable, key=lambda r: (r["jumps"], r["seconds"]))
        out = {"ok": True, "records": recs, "record": best["record"]}
    except BaseException as exc:                    # noqa: BLE001
        out = _err(exc)
    return json.dumps(out)


def run(name: str, record: int, leg: str) -> str:
    """Analyse one file. Results go to /out/<session>. Return a short summary."""
    try:
        path = os.path.join(IN, name)
        found = scan_records(path, CFG, [int(record)])
        if found[0][2] < N_CHANNELS or found[0][1] == 0:
            raise KitError(f"record {record} holds no complete drop jump.")
        stem = os.path.splitext(name)[0]
        out_dir = os.path.join(OUT, stem)
        shutil.rmtree(out_dir, ignore_errors=True)
        info = run_session(path, CFG, int(record), leg, out_dir)
        page = os.path.basename(info["page"])
        table = one_table(out_dir, info["suffix"])
        fig_dir = os.path.join(out_dir, "figures")
        figs = sorted("figures/" + f for f in os.listdir(fig_dir)) if os.path.isdir(fig_dir) else []
        deliver = [page, table] + figs
        _deliver_only(out_dir, deliver)
        out = {"ok": True, "suffix": info["suffix"], "dir": out_dir, "deliver": deliver,
               "page": page, "n_trials": info["n_trials"],
               "body_weight_N": round(info["body_weight_N"], 1), "flags": info["flags"],
               "reader_warnings": [str(w) for w in info["reader_warnings"]]}
    except BaseException as exc:                    # noqa: BLE001
        out = _err(exc)
    return json.dumps(out)


def trim(out_dir: str) -> None:
    """Free memory once the page holds a copy: keep only the two small summary tables."""
    for root, _, fs in os.walk(out_dir):
        for f in fs:
            if not f.startswith(("session_summary_", "cycle_phase_panel_")):
                os.remove(os.path.join(root, f))


SHARE_COLS = ["session", "participant", "session code", "body weight N", "measure", "unit",
              "T1", "T2", "T3", "mean", "SD", "CV %", "MDC95", "n"]


def share(dirs_json: str, log_text: str) -> str:
    """Build the summary for Calgary: one table, one chart and the run log. Return the file list."""
    from jumpkit import compare
    try:
        shutil.rmtree(SHARE, ignore_errors=True)
        os.makedirs(SHARE)
        rows, paths = [], []
        for d in json.loads(dirs_json):
            for f in sorted(os.listdir(d)):
                if not (f.startswith("session_summary_") and f.endswith(".csv")):
                    continue
                suffix = f[len("session_summary_"):-4]
                s = pd.read_csv(os.path.join(d, f), dtype={"participant_code": str, "session_code": str}).iloc[0]
                paths.append(os.path.join(d, f))
                panel = os.path.join(d, f"cycle_phase_panel_{suffix}.csv")
                if not os.path.exists(panel):
                    continue
                for _, r in pd.read_csv(panel, dtype=str, keep_default_na=False).iterrows():
                    rows.append({"session": suffix, "participant": s["participant_code"],
                                 "session code": s["session_code"], "body weight N": _num(s["body_weight_N"], 1),
                                 "measure": r["metric"], "unit": r["unit"], "T1": r["T1"], "T2": r["T2"],
                                 "T3": r["T3"], "mean": _sig(r["mean"]), "SD": _sig(r["sd"]),
                                 "CV %": _num(r["cv_pct"], 1), "MDC95": _sig(r["mdc95"]), "n": r["n"]})
        rows.sort(key=lambda r: r["session"])
        pd.DataFrame(rows, columns=SHARE_COLS).to_csv(os.path.join(SHARE, "SLDVJ summary.csv"),
                                                      index=False, encoding="utf-8-sig")
        if paths:
            compare.figure(compare.long_table(compare.load_summaries(paths)), os.path.join(SHARE, "SLDVJ summary.png"))
        with open(os.path.join(SHARE, "Run log.txt"), "w", encoding="utf-8") as f:
            f.write(log_text)
        out = {"ok": True, "files": sorted(os.listdir(SHARE))}
    except BaseException as exc:                    # noqa: BLE001
        out = _err(exc)
    return json.dumps(out)
