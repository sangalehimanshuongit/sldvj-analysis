"""Stand-in for plotly.offline: the reports only embed the plotly.js source."""
import os


def get_plotlyjs():
    with open(os.path.join(os.path.dirname(__file__), 'plotly.min.js'), encoding='utf-8') as f:
        return f.read()
