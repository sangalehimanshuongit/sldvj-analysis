"""Analyse one SL-DVJ session without video and write its reports, tables and figures.

This is the no-video path of ``the full pipeline script`` (Jump Utility v2): the same
analysis, figures and HTML pages, without the video, pose, legacy-v1 comparison, LaTeX
manifest, PDF printing or the full technical report (which needs the v1 comparison).
"""
from __future__ import annotations

import os

import pandas as pd

from jumpkit import figures, figures_results, report, report_extra
from jumpkit.adicht import read_adicht
from jumpkit.events import DetectParams, detect_drop_jumps
from jumpkit.forceplate import build_plate
from jumpkit.pipeline import analyse, save_json
from jumpkit.session import load_config, session_code, suffix

N_CHANNELS = 16


class KitError(Exception):
    """A problem with an input file, explained in plain words for the console."""


def _read(path: str) -> list:
    try:
        R = read_adicht(path)
    except Exception as exc:                        # noqa: BLE001
        raise KitError("could not read the file. It may be damaged, or it may not be a LabChart "
                       f"file from this lab's set-up ({type(exc).__name__}: {exc}).") from exc
    if not R:
        raise KitError("the file holds no recordings.")
    return R


def scan_records(path: str, cfg_path: str, candidates: list[int] | None = None) -> list[tuple]:
    """(record, drop jumps found, channels, duration s) for each candidate record. Raise KitError if unreadable."""
    R = _read(path)
    base = load_config(cfg_path, None, {"record": 1, "stance_leg": "R"})
    found = []
    for k in candidates or range(1, len(R) + 1):
        rec = R[k - 1]
        dur = max((len(c.counts) / c.fs for c in rec.channels.values()), default=0.0)
        if len(rec.channels) < N_CHANNELS:
            found.append((k, 0, len(rec.channels), dur))
            continue
        try:
            P = build_plate(rec, base)
            trials, _ = detect_drop_jumps(P.Fz, P.fs, P.noise_sd_N, DetectParams(), pkres_N=P.pkres_N)
            n = len(trials)
        except Exception:                           # noqa: BLE001
            n = 0
        found.append((k, n, len(rec.channels), dur))
    return found


def check_and_pick_record(path: str, cfg_path: str, record: int | None) -> tuple[int, list[str]]:
    """Check the file and return (record to analyse, notes). Raise KitError if unusable."""
    R = _read(path)
    notes = [f"{len(R)} record(s) in the file"]
    if record is not None:
        if not 1 <= record <= len(R):
            raise KitError(f"'Session settings.csv' asks for record {record}, but the file has "
                           f"{len(R)} record(s).")
        candidates = [record]
    else:
        candidates = list(range(1, len(R) + 1))
    found = scan_records(path, cfg_path, candidates)
    best = max(found, key=lambda x: (x[1], x[3]))
    k, n, nch, dur = best
    if nch < N_CHANNELS:
        raise KitError(f"record {k} has {nch} channels, but the SL-DVJ analysis needs {N_CHANNELS} "
                       "(8 force plate, 2 EMG, 6 accelerometer). Is this a static-balance file?")
    if n == 0:
        which = f"record {k}" if record is not None else "any record"
        raise KitError(f"no drop jump was found in {which}. A trial needs an empty plate, a first "
                       "contact, a flight and a landing that stays on the plate for at least 1 s.")
    notes.append(f"record {k} used ({dur:.1f} s, {n} trial(s) found)")
    if record is None and sum(1 for f in found if f[1] > 0) > 1:
        notes.append("more than one record holds jumps: set 'record' in Session settings.csv "
                     "to choose another one")
    return k, notes


def run_session(path: str, cfg_path: str, record: int, stance_leg: str, out_dir: str) -> dict:
    """Run the analysis of one file into out_dir. Return a short summary for the console."""
    fig_dir = os.path.join(out_dir, "figures")
    os.makedirs(fig_dir, exist_ok=True)
    for f in os.listdir(fig_dir):                   # clear figures from an earlier run
        if f.endswith((".png", ".jpg")):
            os.remove(os.path.join(fig_dir, f))
    cfg = load_config(cfg_path, path, {"record": record, "stance_leg": stance_leg})
    res, ser = analyse(path, cfg)
    res["meta"]["video"] = None
    res["video"] = {}
    sfx = suffix(path)

    figures.overview(ser, res, os.path.join(fig_dir, "overview_force.png"))
    lim = figures.shared_limits(ser, res)
    for k in range(len(res["trials"])):
        figures.trial_panel(ser, res, k, os.path.join(fig_dir, f"trial{k+1}_panel.png"), lim)
    res["heatmaps"] = figures.heatmaps(ser, res, cfg, os.path.join(fig_dir, "cop_heatmaps_standardised.png"),
                                       os.path.join(fig_dir, "cop_paths_plate.png"))
    res["heatmaps"]["zone"] = figures.zone_heatmaps(ser, res, cfg, os.path.join(fig_dir, "cop_zone_heatmaps.png"))
    figures.sync_figure(ser.get("delay_curves", {}), None, os.path.join(fig_dir, "sync.png"))
    FR, rf = figures_results, lambda n: os.path.join(fig_dir, f"res_{n}.png")
    FR.contact_overlay(ser, res, rf("contact_overlay"))
    FR.com_overlay(ser, res, rf("com_overlay"))
    FR.force_com_loops(ser, res, rf("force_com_loops"))
    FR.loading_figure(ser, res, rf("loading"))
    FR.phase_timeline(res, rf("phases"))
    FR.tts_curves(ser, res, rf("tts_curves"))
    FR.tts_methods(res, rf("tts_methods"))
    FR.dpsi_bars(res, rf("dpsi"))
    FR.cop_stance_overlay(ser, res, rf("cop_stance"))
    FR.cop_metric_bars(res, rf("cop_bars"))
    FR.emg_overlay(ser, res, rf("emg_overlay"))
    FR.emg_bars(res, rf("emg_bars"))
    FR.consistency(res, report_extra.KEY, rf("consistency"))
    FR.cop_entropy_figure(res, rf("cop_entropy"))
    FR.cocontraction_figure(ser, res, rf("cocontraction"))

    tables = report.tables(res, None)
    for name, df in tables.items():
        if isinstance(df, pd.DataFrame) and not df.empty:      # legacy_vs_v2 is empty without v1
            df.to_csv(os.path.join(out_dir, f"{name}.csv"), index=False)
    save_json(res, os.path.join(out_dir, "results.json"))
    panel, summary = report_extra.cycle_panel(res)
    panel.drop(columns=["section", "decimals"]).to_csv(os.path.join(out_dir, f"cycle_phase_panel_{sfx}.csv"),
                                                       index=False)
    summary.to_csv(os.path.join(out_dir, f"session_summary_{sfx}.csv"), index=False)
    page = os.path.join(out_dir, f"SLDVJ_{sfx}.html")
    with open(page, "w", encoding="utf-8") as f:
        f.write(report_extra.build_session_html(res, ser, tables, out_dir))
    flags = sorted({fl for T in res["trials"] for fl in T.get("flags", [])})
    return {"suffix": sfx, "page": page, "n_trials": len(res["trials"]),
            "body_weight_N": float(res["body_weight"]["session_bw_N"]), "flags": flags,
            "reader_warnings": res["meta"]["reader_warnings"]}


def name_parses(path: str) -> bool:
    return bool(session_code(path)["code"])

