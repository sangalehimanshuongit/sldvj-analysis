"""Two new landing-stability analyses that need only a force plate.

N1. Extrapolated-COM stability margin after landing (XcoM margin) and time to dynamic
    stability (TDS). Exploratory: implemented, not validated against motion capture.
    Hof's extrapolated centre of mass, XcoM = COM + v / omega0 with omega0 = sqrt(g / l),
    is normally computed from motion capture (Hof et al. 2005). Margin-of-stability work in
    hop and single-leg landings also uses motion capture (Oberlander et al. 2012;
    Sritharan et al. 2025). Here the horizontal COM comes from the force plate alone:
      COM = double integral of F/m from TD2 + 20 ms to the end of quiet stance, with its two
      integration constants set by rest over the last 1 s (mean velocity 0, mean COM = mean
      COP; the condition the zero-point method of Zatsiorsky & King 1998 relies on). The COP
      enters only through that one mean, so the XcoM can leave the COP envelope.
    An independent COM comes from the inverted-pendulum filter COM = COP * omega0^2 /
    (omega0^2 + omega^2) (zero phase; compare Lafond et al. 2004). The RMS difference between
    the two COMs is the uncertainty band. (The filter COM cannot be used for the XcoM
    itself: built from the same COP as the envelope, its XcoM stays inside by construction.)
    The analysis starts 0.4 s after landing, because before that the vertical acceleration
    and the change in angular momentum break the pendulum model.
    The margin is the distance from the XcoM to the nearest edge of the support envelope:
    the range of the 20 Hz-filtered COP from 20 ms after TD2 to the end of the window. In the
    impact phase the COP travels from forefoot to heel, so this is a measured stand-in for
    the usable foot length and width (not the anatomical base of support).
    TDS is the time after landing from which the XcoM stays inside the envelope on both
    axes. It is censored ("<= window start" or "not reached") and tested against a +/-2 N
    force offset (see xcom_analysis); if that moves it, TDS is reported as not determinable. The envelope comes from the
    same COP trace (no foot outline was measured), so margins are relative, not anatomical.

N2. Continuous stabilisation curve (time-resolved DPSI) and recovery time constant.
    DPSI (Wikstrom et al. 2005) is one number over 3 s. Here its integrand becomes a curve:
    s(t) = sqrt(LP5Hz[(Fap/BW)^2 + (Fml/BW)^2 + ((BW - Fz)/BW)^2]). s(t) is divided by its
    quiet-stance level and fitted from its peak with A exp(-t/tau) + C. The curve gives
    tau (s), the model recovery time t95 = t_peak + tau ln 20, the model-free time after
    which s stays within 2x the quiet level, and the share of the 3 s DPSI that builds up in
    the first 0.4 s. A moving-block bootstrap of the fit residuals gives a 95% CI for tau.
"""
from __future__ import annotations

import numpy as np
from scipy.optimize import curve_fit

from .signals import cumtrapz0, lowpass

G = 9.80665


# ---------------------------------------------------------------- N1: XcoM margin
def zero_points(F: np.ndarray, min_gap: int) -> np.ndarray:
    s = np.sign(F)
    idx = np.where(s[:-1] * s[1:] < 0)[0]
    idx = np.where(np.abs(F[idx]) <= np.abs(F[idx + 1]), idx, idx + 1)
    keep, last = [], -min_gap
    for i in idx:
        if i - last >= min_gap:
            keep.append(i)
            last = i
    return np.asarray(keep, int)


def com_ip_filter(cop_m: np.ndarray, fs: float, l: float, pad_s: float = 1.0) -> np.ndarray:
    """COM = COP * omega0^2 / (omega0^2 + omega^2), zero phase, with mirror padding."""
    w0 = np.sqrt(G / l)
    p = int(round(pad_s * fs))
    x = np.concatenate([cop_m[p:0:-1], cop_m, cop_m[-2:-p - 2:-1]]) if (p and cop_m.size > p + 2) else cop_m
    # a straight line passes the filter unchanged: remove the line through the end points so
    # the FFT does not join the two ends with a step (wrap-around), then add it back
    line = np.linspace(x[0], x[-1], x.size)
    X = np.fft.rfft(x - line)
    w = 2 * np.pi * np.fft.rfftfreq(x.size, 1 / fs)
    y = np.fft.irfft(X * w0 ** 2 / (w0 ** 2 + w ** 2), n=x.size) + line
    return y[p:p + cop_m.size] if (p and cop_m.size > p + 2) else y


def com_force(F_h: np.ndarray, cop_end_mean: float, fs: float, m: float, fc: float = 10.0,
              rest_s: float = 1.0, eps_N: float = 0.0) -> dict:
    """COM from double-integrated F/m. The two integration constants come from the end of
    quiet stance, where the body is at rest above its mean COP: mean velocity = 0 and mean
    COM = mean COP over the last rest_s. No force-offset term (the plate baselines vary by
    less than 0.4 N). The COP enters only through one mean, so the XcoM can leave the COP
    envelope."""
    a = (lowpass(F_h, fs, fc) - eps_N) / m
    I1 = cumtrapz0(a, 1 / fs)
    I2 = cumtrapz0(I1, 1 / fs)
    t = np.arange(a.size) / fs
    w = min(a.size, int(round(rest_s * fs)))
    v0 = -I1[-w:].mean()
    p0 = cop_end_mean - (v0 * t[-w:] + I2[-w:]).mean()
    return {"pos": p0 + v0 * t + I2, "vel": v0 + I1}


def _tds(margins, t0, fs):
    ok = np.all(np.vstack([mg >= 0 for mg in margins]), axis=0)
    bad = np.where(~ok)[0]
    if bad.size == 0:
        return t0, "<=", ok
    if bad[-1] + 1 >= ok.size:
        return float("nan"), "not reached", ok
    return t0 + (bad[-1] + 1) / fs, "", ok


def xcom_analysis(F_ap, F_ml, cop_ap_m, cop_ml_m, fs, m, a, b, td2, end, l_values=(0.8, 0.9, 1.0),
                  eps_N: float = 2.0) -> dict:
    """Run N1 over [a, b) for both axes and several pendulum lengths l.

    The force-integral COM is computed over [td2 + 20 ms, end) with its constants set by rest
    over the last 1 s, then cut to [a, b). Because both constants sit at the end, a force
    offset e gives a position error of (e / 2m)(t_end - t)^2 that grows back towards landing.
    So TDS is recomputed with offsets of -eps_N, 0 and +eps_N on each axis (9 combinations).
    TDS is "determinable" only if every combination gives a finite, uncensored TDS within
    0.2 s of the others. The XcoM uncertainty band grows with the same law:
    u(t) = sqrt(u_pos^2 + (u_vel / omega0)^2) + (eps_N / 2m)(t_end - t)^2.
    """
    s0 = td2 + int(round(0.02 * fs))
    env = {"ap": (np.nanmin(cop_ap_m[s0:b]), np.nanmax(cop_ap_m[s0:b])),
           "ml": (np.nanmin(cop_ml_m[s0:b]), np.nanmax(cop_ml_m[s0:b]))}
    t0 = (a - td2) / fs
    res = {"t0_s": t0, "by_l": {}, "envelope": env}
    w = int(round(1.0 * fs))
    tt = np.arange(s0, end)[a - s0:b - s0] / fs
    drift = (eps_N / (2 * m)) * (end / fs - tt) ** 2
    for l in l_values:
        w0 = np.sqrt(G / l)
        d, xc = {}, {}
        for ax_, F, c in (("ap", F_ap, cop_ap_m), ("ml", F_ml, cop_ml_m)):
            seg = c[s0:end]
            cop_full = np.nan_to_num(seg, nan=np.nanmean(seg))
            ref = float(np.mean(cop_full[-w:]))
            ip = com_ip_filter(cop_full, fs, l, pad_s=0.0)
            ip_v = np.gradient(lowpass(ip, fs, 10.0), 1 / fs)
            k0, k1 = a - s0, b - s0
            lo, hi = env[ax_]
            xc[ax_] = {}
            for e in (-eps_N, 0.0, eps_N):
                cf = com_force(F[s0:end], ref, fs, m, eps_N=e)
                pos, vel = cf["pos"][k0:k1], cf["vel"][k0:k1]
                xc[ax_][e] = np.minimum(pos + vel / w0 - lo, hi - (pos + vel / w0))
                if e == 0.0:
                    xcom = pos + vel / w0
                    u_pos = float(np.sqrt(np.mean((pos - ip[k0:k1]) ** 2)))
                    u_vel = float(np.sqrt(np.mean((vel - ip_v[k0:k1]) ** 2)))
                    u0 = float(np.hypot(u_pos, u_vel / w0))
                    d[ax_] = {"cop": cop_full[k0:k1], "com": pos, "vel": vel, "xcom": xcom, "com_ip": ip[k0:k1],
                              "margin": xc[ax_][e], "u_mm": u0 * 1000, "u_t": u0 + drift,
                              "u_pos_mm": u_pos * 1000, "u_vel_mm_s": u_vel * 1000,
                              "support_lo": float(lo), "support_hi": float(hi)}
        tds, cens, ok = _tds([d["ap"]["margin"], d["ml"]["margin"]], t0, fs)
        combos = [_tds([xc["ap"][ea], xc["ml"][em]], t0, fs)[:2] for ea in (-eps_N, 0.0, eps_N)
                  for em in (-eps_N, 0.0, eps_N)]
        vals = [v for v, cn in combos]
        determinable = all(cn == "" and np.isfinite(v) for v, cn in combos) and (max(vals) - min(vals) <= 0.2)
        d.update({"tds_s": tds, "tds_censoring": cens, "tds_determinable": bool(determinable),
                  "tds_offset_range_s": [float(np.nanmin(vals)) if np.isfinite(vals).any() else float("nan"),
                                         float(np.nanmax(vals)) if np.isfinite(vals).any() else float("nan")],
                  "tds_offset_states": [cn if cn else f"{v:.2f}" for v, cn in combos],
                  "min_margin_ap_mm": float(d["ap"]["margin"].min() * 1000),
                  "min_margin_ml_mm": float(d["ml"]["margin"].min() * 1000),
                  "pct_time_outside": float(100 * np.mean(~ok)),
                  "u_ap_mm": d["ap"]["u_mm"], "u_ml_mm": d["ml"]["u_mm"],
                  "u_at_window_start_mm": float((d["ap"]["u_t"][0]) * 1000)})
        res["by_l"][l] = d
    return res


# ---------------------------------------------------------- N2: stabilisation curve
def stabilisation_curve(F_ap, F_ml, Fz, fs, td2, end, bw, fc=10.0, quiet_s=1.0) -> dict:
    """s(t) from TD2 to the end of quiet stance. The low-pass runs on this segment only, so
    the rebound flight before TD2 (where the vertical term is 1) cannot leak into it."""
    seg = slice(td2, end)
    parts = {"AP": (F_ap[seg] / bw) ** 2, "ML": (F_ml[seg] / bw) ** 2, "V": ((bw - Fz[seg]) / bw) ** 2}
    total = parts["AP"] + parts["ML"] + parts["V"]
    env = lambda x: np.sqrt(np.clip(lowpass(x, fs, fc), 0, None))
    s = env(total)
    q = int(round(quiet_s * fs))
    level = float(np.sqrt(np.mean(s[-q:] ** 2)))          # RMS of the last quiet second
    horiz = env(parts["AP"] + parts["ML"])
    return {"t": np.arange(s.size) / fs, "s": s, "quiet_level": level, "s_norm": s / level,
            "s_horizontal": horiz, "parts": {k: env(v) for k, v in parts.items()}}


def _exp(x, A, tau, C):
    return A * np.exp(-x / tau) + C


def recovery_fit(t: np.ndarray, s: np.ndarray, fs: float, n_boot: int = 300, block_s: float = 0.2,
                 seed: int = 0, i0: int | None = None) -> dict:
    """Fit A exp(-t/tau) + C from index i0 (default: the curve maximum in the first 0.3 s).
    Pass the impact-peak index so that every filter cut-off fits the same decay."""
    if i0 is None:
        i0 = int(np.argmax(s[: int(0.3 * fs)]))
    x, y = t[i0:] - t[i0], s[i0:]
    nan = {"t_peak_s": float(t[i0]), "A": np.nan, "tau_s": np.nan, "C": np.nan, "tau_ci95_s": (np.nan, np.nan),
           "r2": np.nan, "t95_s": np.nan, "pred": np.full_like(y, np.nan), "i0": i0}
    try:
        p, _ = curve_fit(_exp, x, y, p0=(y[0], 0.2, y[-int(0.5 * fs):].mean()),
                         bounds=([0, 0.005, 0], [10, 5, 1]), maxfev=20000)
    except (RuntimeError, ValueError):
        return nan
    pred = _exp(x, *p)
    r2 = 1 - np.sum((y - pred) ** 2) / np.sum((y - y.mean()) ** 2)
    rng = np.random.default_rng(seed)
    res = y - pred
    blk = int(round(block_s * fs))
    taus = []
    for _ in range(n_boot if res.size > 2 * blk else 0):
        idx = np.concatenate([np.arange(j, j + blk) for j in rng.integers(0, res.size - blk + 1, res.size // blk + 1)])[: res.size]
        try:
            pb, _ = curve_fit(_exp, x, pred + res[idx], p0=p, bounds=([0, 0.005, 0], [10, 5, 1]), maxfev=5000)
            taus.append(pb[1])
        except (RuntimeError, ValueError):
            continue
    lo, hi = (np.percentile(taus, [2.5, 97.5]) if len(taus) > 20 else (np.nan, np.nan))
    return {"t_peak_s": float(t[i0]), "A": float(p[0]), "tau_s": float(p[1]), "C": float(p[2]),
            "tau_ci95_s": (float(lo), float(hi)), "r2": float(r2),
            "t95_s": float(t[i0] + p[1] * np.log(20.0)), "pred": pred, "i0": i0}


def stays_below(s_norm: np.ndarray, fs: float, k: float = 2.0) -> float:
    bad = np.where(s_norm > k)[0]
    if bad.size == 0:
        return 0.0
    return (bad[-1] + 1) / fs if bad[-1] + 1 < s_norm.size else float("nan")


def dpsi_share(s: np.ndarray, fs: float, split_s: float = 0.4, dur_s: float = 3.0) -> float:
    """Share (%) of the DPSI sum of squares that builds up in the first split_s."""
    n = min(int(round(dur_s * fs)), s.size)
    sq = s[:n] ** 2
    k = int(round(split_s * fs))
    return float(100 * sq[:k].sum() / sq.sum())
