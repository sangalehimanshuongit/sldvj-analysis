"""Static figures (PNG/JPEG) for the report and the PDF. One consistent style for all."""
from __future__ import annotations

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
try:                         # only the video frame figures use OpenCV; the no-video kit runs without it
    import cv2
except ImportError:          # pragma: no cover
    cv2 = None

from . import heatmap as hm

C = {"fz": "#1f2937", "ap": "#2563eb", "ml": "#d97706", "comv": "#7c3aed", "comz": "#6b7280",
     "emg1": "#059669", "emg2": "#be185d", "ev": "#dc2626", "low": "#16a34a", "band": "#e5e7eb",
     "fit": "#dc2626"}
TRIAL_COLOURS = ["#2563eb", "#059669", "#d97706", "#7c3aed", "#be185d", "#0891b2"]
plt.rcParams.update({"figure.dpi": 110, "savefig.dpi": 200, "font.size": 9, "axes.titlesize": 10, "axes.grid": True,
                     "grid.alpha": 0.3, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.unicode_minus": False})
EV = [("td1", "TD1"), ("to2", "TO2"), ("td2", "TD2"), ("stance_end", "end")]


def tcol(k):
    return TRIAL_COLOURS[k % len(TRIAL_COLOURS)]


EV_STYLE = {"td1": ("#dc2626", "--"), "to2": ("#7c3aed", "--"), "td2": ("#dc2626", "--"),
            "stance_end": ("#6b7280", "-."), "off": ("#6b7280", ":")}


def ev_handles(keys=("td1", "to2", "stance_end"), lowest=False):
    """Legend handles for event lines (TD1 and TD2 share a style)."""
    lab = {"td1": "touchdown (TD1, TD2)", "td2": "touchdown (TD1, TD2)", "to2": "rebound take-off (TO2)",
           "stance_end": "end of quiet stance", "off": "step-off"}
    h = [Line2D([], [], color=EV_STYLE[k][0], ls=EV_STYLE[k][1], lw=1, label=lab[k]) for k in keys]
    if lowest:
        h.append(Line2D([], [], color=C["low"], ls=":", lw=1.2, label="lowest COM (COM velocity = 0)"))
    return h


def overview(ser, res, path):
    t, Fz = ser["t"], ser["Fz"]
    bw = res["body_weight"]["session_bw_N"]
    fig, ax = plt.subplots(figsize=(11, 3.6))
    ax.plot(t, Fz / bw, color=C["fz"], lw=0.8, label="vertical GRF")
    ax.axhline(1, color="#9ca3af", lw=0.7, label="1 BW (body weight)")
    for T in res["trials"]:
        e = T["events_s"]
        ax.axvspan(e["td1"], e["stance_end"], color=C["band"], alpha=0.6, lw=0)
        ax.text((e["td1"] + e["stance_end"]) / 2, 4.15, f"Trial {T['number']}", fontsize=9, ha="center",
                va="bottom", fontweight="bold")
        for k in ("td1", "to2", "td2", "stance_end"):
            ax.axvline(e[k], color=EV_STYLE[k][0], lw=0.7, ls=EV_STYLE[k][1])
    ax.set_ylim(-0.2, 4.6)
    ax.set_xlabel("Force time from record start (s)")
    ax.set_ylabel("Vertical GRF (BW)")
    ax.set_title("Record 2: vertical ground reaction force, whole record")
    h, _ = ax.get_legend_handles_labels()
    h += [plt.Rectangle((0, 0), 1, 1, color=C["band"], alpha=0.6, label="analysed trial (TD1 to end of quiet stance)")]
    ax.legend(handles=h + ev_handles(), fontsize=8, loc="upper left", bbox_to_anchor=(1.005, 1), frameon=False)
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def shared_limits(ser, res, pre=0.3, post=0.2):
    """Shared y-limits for the trial panels."""
    fs = ser["fs"]
    bw = res["body_weight"]["session_bw_N"]
    fz, h, cop = [], [], []
    for S in ser["trials"]:
        a, b = int(S["td1"] - pre * fs), min(S["se"] + int(post * fs), ser["t"].size)
        fz.append(np.nanmax(ser["Fz"][a:b]) / bw)
        h += [np.nanmin(ser["F_ap"][a:b] / bw), np.nanmax(ser["F_ap"][a:b] / bw),
              np.nanmin(ser["F_ml"][a:b] / bw), np.nanmax(ser["F_ml"][a:b] / bw)]
        for c in (ser["cop_ap"][a:b], ser["cop_ml"][a:b]):
            if np.isfinite(c).any():
                cc = c - np.nanmean(c)
                cop.append(max(abs(np.nanmin(cc)), abs(np.nanmax(cc))))
    return {"fz": (-0.1, 1.05 * max(fz)), "h": (1.1 * min(h), 1.1 * max(h)), "cop_half": 1.1 * max(cop)}


def trial_panel(ser, res, k, path, lim=None):
    """One trial: force, COM, horizontal force, COP, EMG, from 0.3 s before TD1. Shared scales."""
    lim = lim or shared_limits(ser, res)
    T, S = res["trials"][k], ser["trials"][k]
    fs = ser["fs"]
    bw = res["body_weight"]["session_bw_N"]
    e = T["events_s"]
    t0 = e["td1"] - 0.3
    a, b = int(t0 * fs), min(S["se"] + int(0.2 * fs), ser["t"].size)
    t = ser["t"][a:b] - e["td1"]
    fig, ax = plt.subplots(5, 1, figsize=(10, 7.2), sharex=True,
                           gridspec_kw={"height_ratios": [1.3, 1, 1, 1, 1]})
    ax[0].plot(t, ser["Fz"][a:b] / bw, color=C["fz"], lw=0.9, label="vertical GRF")
    ax[0].axhline(1, color="#9ca3af", lw=0.6, label="1 BW")
    ax[0].set_ylim(*lim["fz"])
    ax[0].set_ylabel("Fz (BW)")
    ax[0].legend(fontsize=8, loc="upper right")
    tv = np.arange(S["v_contact"].size) / fs
    n2 = min(S["v_land"].size, S["i_low2"] + int(0.3 * fs))      # landing COM to lowest point + 0.3 s
    tl = np.arange(n2) / fs + (e["td2"] - e["td1"])
    ax[1].plot(tv, S["v_contact"], color=C["comv"], lw=1.1, label="COM velocity (m/s)")
    ax[1].plot(tl, S["v_land"][:n2], color=C["comv"], lw=1.1)
    ax[1].plot(tv, S["z_contact"], color=C["comz"], lw=1.1, ls="--", label="COM displacement (m)")
    ax[1].plot(tl, S["z_land"][:n2], color=C["comz"], lw=1.1, ls="--")
    ax[1].set_ylim(-1.8, 1.8)
    ax[1].set_ylabel("COM (m/s, m)")
    ax[1].legend(fontsize=8, loc="upper right")
    ax[2].plot(t, ser["F_ap"][a:b] / bw, color=C["ap"], lw=0.8, label="AP GRF (anterior +)")
    ax[2].plot(t, ser["F_ml"][a:b] / bw, color=C["ml"], lw=0.8, label="ML GRF (lateral +)")
    ax[2].set_ylim(*lim["h"])
    ax[2].set_ylabel("GRF (BW)")
    ax[2].legend(fontsize=8, loc="upper right")
    h = lim["cop_half"]
    for c, col, lab in ((ser["cop_ap"][a:b], C["ap"], "COP AP"), (ser["cop_ml"][a:b], C["ml"], "COP ML")):
        ax[3].plot(t, c - np.nanmean(c), color=col, lw=0.8, label=lab + " (minus its mean)")
    ax[3].set_ylim(-h, h)
    ax[3].set_ylabel("COP (mm)")
    ax[3].legend(fontsize=8, loc="upper right")
    te = ser["te"]
    m = (te >= t0) & (te <= ser["t"][b - 1])
    for name, col in (("EMG1", C["emg1"]), ("EMG2", C["emg2"])):
        ax[4].plot(te[m] - e["td1"], 100 * ser["emg_env"][name][m], color=col, lw=0.9, label=name)
    ax[4].axvspan(-0.15, 0, color="#fde68a", alpha=0.5, lw=0, label="150 ms before TD1 and TD2")
    ax[4].axvspan(e["td2"] - e["td1"] - 0.15, e["td2"] - e["td1"], color="#fde68a", alpha=0.5, lw=0)
    ax[4].set_ylim(0, 105)
    ax[4].set_ylabel("EMG (% peak)")
    ax[4].legend(fontsize=8, loc="upper right")
    ax[4].set_xlabel("Time from first touchdown TD1 (s)")
    lows = [e["td1_lowest_com"] - e["td1"], e["td2_lowest_com"] - e["td1"]]
    for axx in ax:
        for key, lab in EV:
            axx.axvline(e[key] - e["td1"], color=EV_STYLE[key][0], lw=0.6, ls=EV_STYLE[key][1])
        for x in lows:
            axx.axvline(x, color=C["low"], lw=0.7, ls=":")
    for key, lab in EV:
        ax[0].text(e[key] - e["td1"], lim["fz"][1], lab, color=EV_STYLE[key][0], fontsize=7, ha="center", va="bottom")
    ax[0].set_title(f"Trial {T['number']}", pad=14)
    fig.legend(handles=ev_handles(lowest=True), loc="lower center", ncol=4, fontsize=8, frameon=False)
    fig.tight_layout(rect=(0, 0.03, 1, 1))
    fig.savefig(path)
    plt.close(fig)


def frame_for(t_video, t_frames, kind):
    """First frame at or after the event for contact and take-off events, else the nearest."""
    if kind in ("td1", "td2", "to2"):
        idx = np.where(t_frames >= t_video)[0]
        if idx.size:
            return int(idx[0])
    return int(np.argmin(np.abs(t_frames - t_video)))


TIMELINE_EVENTS = [("td1", "TD1"), ("td1_lowest_com", "lowest COM 1"), ("to2", "TO2"), ("td2", "TD2"),
                   ("td2_lowest_com", "lowest COM 2"), ("stance_end", "end of quiet stance")]


FPPA_BGR = (178, 145, 8)                 # C["fppa"] (#0891b2) in BGR


def _draw_fppa(img, row, a_xy, side, view="frontal", min_vis=0.5):
    """Draw the FPPA geometry on a frame: the ASIS point and the ASIS-knee and knee-ankle lines,
    with the angle (valgus +) next to the knee. Returns the angle or NaN."""
    s = side.lower()
    knee, ankle = [np.array([row[f"{s}_{n}_x"], row[f"{s}_{n}_y"]], float)
                   if row.get(f"{s}_{n}_vis", 0) >= min_vis else np.full(2, np.nan) for n in ("knee", "ankle")]
    a = np.asarray(a_xy, float)
    if not (np.isfinite(a).all() and np.isfinite(knee).all() and np.isfinite(ankle).all()):
        return float("nan")
    one = pd.DataFrame({f"{s}_hip_x": [0.0], f"{s}_hip_y": [0.0], f"{s}_hip_vis": [1.0],
                        f"{s}_knee_x": [knee[0]], f"{s}_knee_y": [knee[1]], f"{s}_knee_vis": [1.0],
                        f"{s}_ankle_x": [ankle[0]], f"{s}_ankle_y": [ankle[1]], f"{s}_ankle_vis": [1.0]})
    from .video import fppa_deg
    ang = float(fppa_deg(one, side, view=view, hip_xy=a[None, :]).iloc[0])
    P = [tuple(int(round(v)) for v in q) for q in (a, knee, ankle)]
    for (p0, p1) in ((P[0], P[1]), (P[1], P[2])):
        cv2.line(img, p0, p1, (255, 255, 255), 4, cv2.LINE_AA)
        cv2.line(img, p0, p1, FPPA_BGR, 2, cv2.LINE_AA)
    cv2.circle(img, P[0], 6, (20, 20, 20), -1, cv2.LINE_AA)
    cv2.circle(img, P[0], 4, (0, 230, 255), -1, cv2.LINE_AA)
    if np.isfinite(ang):
        txt = f"{ang:+.0f} deg"
        for col, th in (((20, 20, 20), 3), ((255, 255, 255), 1)):
            cv2.putText(img, txt, (P[1][0] + 10, P[1][1] + 22), cv2.FONT_HERSHEY_SIMPLEX, 0.55, col, th, cv2.LINE_AA)
    return ang


def event_timeline(ser, res, k, video_mod, video_path, pose, path, asis=None):
    """Trial timeline: Fz from TD1 - 0.1 s to TD2 + 0.6 s, with the video frame at each event
    above it, joined to the event time by a leader line. Contact and take-off frames are the
    first frame at or after the event, so they show the foot on (or just off) the plate.
    With ``asis`` (the marker track), each frame also shows the FPPA geometry: the ASIS point,
    the ASIS-knee and knee-ankle lines of the stance leg, and the angle."""
    T = res["trials"][k]
    fs = ser["fs"]
    bw = res["body_weight"]["session_bw_N"]
    e = T["events_s"]
    off = res["video"]["offset_s"]
    tf = video_mod.frame_times(video_path)
    idx = [frame_for(e[key] + off, tf, key) for key, _ in TIMELINE_EVENTS]
    frames = video_mod._grab_frames(video_path, np.array(idx))
    prow = pose.set_index("frame") if pose is not None else None
    n = len(TIMELINE_EVENTS)
    fig = plt.figure(figsize=(11, 6.6))
    gs = fig.add_gridspec(3, n, height_ratios=[2.3, 0.9, 0.8], hspace=0.12, wspace=0.03,
                          left=0.06, right=0.99, top=0.92, bottom=0.08)
    axf = fig.add_subplot(gs[1, : n - 1])
    axe = fig.add_subplot(gs[2, : n - 1], sharex=axf)
    t0, t1 = e["td1"] - 0.2, e["td2"] + 0.6
    a, b = int(t0 * fs), int(t1 * fs)
    axf.plot(ser["t"][a:b], ser["Fz"][a:b] / bw, color=C["fz"], lw=0.9)
    axf.set_xlim(t0, t1)
    axf.set_ylabel("Fz (BW)")
    axf.tick_params(labelbottom=False)
    te = ser["te"]
    me = (te >= t0) & (te <= t1)
    for name, col in (("EMG1", C["emg1"]), ("EMG2", C["emg2"])):
        axe.plot(te[me], 100 * ser["emg_env"][name][me], color=col, lw=1.0, label=name)
    axe.set_ylim(0, 105)
    axe.set_ylabel("EMG (%)")
    axe.set_xlabel("Force time from record start (s)")

    def emg_at(t_force, name, half=0.025):
        m = (te >= t_force - half) & (te <= t_force + half)
        return float(100 * np.mean(ser["emg_env"][name][m])) if m.any() else float("nan")
    fig.canvas.draw()
    rows = []
    # crop every frame of the trial to one box around the participant (native pixels, no
    # upscaling): centred on the median hip midpoint of the trial's frames
    cx = 320.0
    if prow is not None:
        hx = [np.nanmean([prow.loc[int(i)].get("l_hip_x", np.nan), prow.loc[int(i)].get("r_hip_x", np.nan)])
              for i in idx if int(i) in prow.index]
        if np.isfinite(hx).any():
            cx = float(np.nanmedian(hx))
    cw = 340
    x0 = int(np.clip(cx - cw / 2, 0, 640 - cw))
    for j, ((key, lab), i) in enumerate(zip(TIMELINE_EVENTS, idx)):
        img = frames[int(i)].copy()
        if prow is not None and int(i) in prow.index:
            row = prow.loc[int(i)].copy()
            other = "l_" if res["meta"]["stance_leg"].upper() == "R" else "r_"
            for c in row.index:                  # stance leg only: the raised leg's landmarks are unreliable
                if c.startswith(other) and c.endswith("_x"):
                    row[c] = np.nan
            video_mod._draw_lower_body(img, row, scale=1.0)
            if asis is not None:
                sl = res["meta"]["stance_leg"].lower()
                ar = asis[asis["frame"] == int(i)]
                a_xy = ar[[f"{sl}_asis_x", f"{sl}_asis_y"]].to_numpy(float)[0] if len(ar) else (np.nan, np.nan)
                _draw_fppa(img, prow.loc[int(i)], a_xy, res["meta"]["stance_leg"])
        img = img[:, x0:x0 + cw].copy()
        # EMG gauges on the frame: activation (% peak) at the frame's time, +/- 25 ms
        tfz = tf[i] - off
        for q, (name, col) in enumerate((("EMG1", (105, 150, 5)), ("EMG2", (93, 24, 190)))):     # BGR of C["emg1"], C["emg2"]
            val = emg_at(tfz, name)
            if not np.isfinite(val):
                continue
            x_a, y_b, hmax, wbar = 8 + q * 36, img.shape[0] - 16, 150, 28
            cv2.rectangle(img, (x_a, y_b - hmax), (x_a + wbar, y_b), (245, 245, 245), -1)
            cv2.rectangle(img, (x_a, y_b - int(hmax * min(val, 100) / 100)), (x_a + wbar, y_b), col, -1)
            cv2.rectangle(img, (x_a, y_b - hmax), (x_a + wbar, y_b), (40, 40, 40), 1)
            for colr, th in (((20, 20, 20), 3), ((255, 255, 255), 1)):
                cv2.putText(img, f"{val:.0f}", (x_a, y_b - hmax - 7), cv2.FONT_HERSHEY_SIMPLEX, 0.62, colr, th, cv2.LINE_AA)
                cv2.putText(img, f"E{q+1}", (x_a + 2, y_b + 13), cv2.FONT_HERSHEY_SIMPLEX, 0.5, colr, th, cv2.LINE_AA)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        axi = fig.add_subplot(gs[0, j])
        axi.imshow(img)
        axi.set_xticks([])
        axi.set_yticks([])
        gap = (tf[i] - off - e[key]) * 1000
        same = [TIMELINE_EVENTS[q][1] for q in range(j) if idx[q] == i]
        note = f"(same frame as {same[0]})" if same else f"{gap:+.0f} ms"
        axi.set_title(f"{lab}\n{note}", fontsize=9)
        rows.append({"event": key, "frame": int(i), "gap_ms": float(gap)})
        if key != "stance_end":
            x = e[key]
            axf.axvline(x, color=C["low"] if "lowest" in key else C["ev"], lw=0.8, ls=":")
            axe.axvline(x, color=C["low"] if "lowest" in key else C["ev"], lw=0.8, ls=":")
            axe.axvline(tfz, color="#9ca3af", lw=0.6)
            fig.canvas.draw()
            xy = fig.transFigure.inverted().transform(axf.transData.transform((x, axf.get_ylim()[1])))
            bb = axi.get_position()
            fig.add_artist(Line2D([bb.x0 + bb.width / 2, xy[0]], [bb.y0 - 0.005, xy[1]], color="#9ca3af", lw=0.8))
    axn = fig.add_subplot(gs[1:, n - 1])
    axn.axis("off")
    axn.text(0.05, 1.12 if asis is not None else 1.0, f"End of quiet stance:\n{e['stance_end'] - e['td2']:.2f} s after TD2\n"
                        f"(force time {e['stance_end']:.2f} s)", fontsize=8.5, va="top")
    hl = [Line2D([], [], color=C["fz"], lw=1, label="vertical GRF (Fz)"),
          Line2D([], [], color=C["emg1"], lw=1.2, label="EMG1 envelope"),
          Line2D([], [], color=C["emg2"], lw=1.2, label="EMG2 envelope"),
          Line2D([], [], color=C["ev"], ls=":", lw=1, label="TD1, TO2, TD2"),
          Line2D([], [], color=C["low"], ls=":", lw=1, label="lowest COM"),
          Line2D([], [], color="#9ca3af", lw=1, label="time of the frame shown"),
          plt.Rectangle((0, 0), 1, 1, fc="#059669", ec="#282828", label="E1 bar = EMG1"),
          plt.Rectangle((0, 0), 1, 1, fc="#be185d", ec="#282828", label="E2 bar = EMG2")]
    if asis is not None:
        sk = "#ff8c00" if res["meta"]["stance_leg"].upper() == "R" else "#00aaff"     # video._SIDE_COLOUR
        hl += [Line2D([], [], color=sk, lw=1.5, label="pose skeleton"),
               Line2D([], [], color=C.get("fppa", "#0891b2"), lw=2, marker="o", mfc="#ffe600", mec="#141414",
                      label="FPPA lines (ASIS-knee-ankle)"),
               Line2D([], [], ls="", marker="o", mfc="#ffe600", mec="#141414", label="ASIS marker")]
    fs_ = 6.8 if asis is not None else 7.5           # three more entries with the FPPA geometry
    axn.legend(handles=hl, loc="lower left", bbox_to_anchor=(0.0, -0.08 if asis is not None else 0.0), fontsize=fs_,
               frameon=False, labelspacing=0.35 if asis is not None else 0.5,
               title="Key (bars: % of session\npeak, mean of ±25 ms)", title_fontsize=fs_, alignment="left")
    fig.suptitle(f"Trial {T['number']}: video frame at each force event, with EMG at that frame "
                 f"(bars: E1 = EMG1, E2 = EMG2, % of session peak)", fontsize=10)
    fig.savefig(path, dpi=200, pil_kwargs={"quality": 93})
    plt.close(fig)
    return rows


def heatmaps(ser, res, cfg, path_std, path_place):
    """Standardised dwell maps (each panel centred on its own window mean, one fixed extent)
    and a placement plot of the paths on the plate (fixed extent from config)."""
    hcfg = cfg.get("heatmap", {})
    half_ml, half_ap = hcfg.get("half_ml_mm", 40.0), hcfg.get("half_ap_mm", 100.0)
    bin_mm = hcfg.get("bin_mm", 4.0)
    cols = [("td1_20_200ms", "TD1, 20-200 ms"), ("td1_contact", "TD1 to TO2"),
            ("td2_20_200ms", "TD2, 20-200 ms"), ("td2_dynamic_0.4s_to_end", "TD2, 0.4 s to end")]
    panels, rows, raw = [], [], []
    for T in res["trials"]:
        w = T["cop_windows_idx"]
        r, rr = [], []
        for key, _ in cols:
            a, b = w[key]
            ml, ap = ser["cop_ml"][a:b], ser["cop_ap"][a:b]
            rr.append((ml, ap))
            r.append((ml - np.nanmean(ml), ap - np.nanmean(ap)) if np.isfinite(ml).any() else (ml, ap))
        panels.append(r)
        raw.append(rr)
        rows.append(f"Trial {T['number']}")
    ext = (-half_ml, half_ml, -half_ap, half_ap)
    info = hm.heatmap_grid(panels, path_std, [c[1] for c in cols], rows, ext, bin_mm=bin_mm, panel_in=1.7,
                           suptitle=f"COP dwell maps: each panel centred on its window mean, fixed "
                                    f"{2*half_ml:.0f} x {2*half_ap:.0f} mm, {bin_mm:g} mm bins, top view",
                           ellipse_cols=(3,))
    pe = tuple(hcfg.get("plate_extent_mm", [-150, 50, -200, 200]))
    fig, axes = plt.subplots(1, len(cols), figsize=(2.6 * len(cols) + 0.6, 5.2), sharey=True,
                             constrained_layout=True)
    for j, (key, lab) in enumerate(cols):
        for k, rr in enumerate(raw):
            ml, ap = rr[j]
            axes[j].plot(ml, ap, color=tcol(k), lw=0.9, label=f"Trial {k+1}")
            ok = np.isfinite(ml) & np.isfinite(ap)
            if ok.any():
                axes[j].plot(ml[ok][0], ap[ok][0], "o", ms=5, mfc=tcol(k), mec="black", mew=0.6)
                axes[j].plot(ml[ok][-1], ap[ok][-1], "s", ms=5, mfc=tcol(k), mec="black", mew=0.6)
        axes[j].set_xlim(pe[0], pe[1])
        axes[j].set_ylim(pe[2], pe[3])
        axes[j].set_aspect("equal")
        axes[j].set_title(lab, fontsize=9)
        axes[j].set_xlabel("ML (mm), lateral →", fontsize=8)
    axes[0].set_ylabel("AP (mm), anterior ↑", fontsize=8)
    h = [Line2D([], [], color=tcol(k), lw=1.2, label=f"Trial {k+1}") for k in range(len(raw))]
    h += [Line2D([], [], ls="", marker="o", mfc="white", mec="black", label="start of window"),
          Line2D([], [], ls="", marker="s", mfc="white", mec="black", label="end of window")]
    fig.legend(handles=h, loc="lower center", ncol=len(h), fontsize=8, frameon=False, bbox_to_anchor=(0.5, -0.07))
    fig.suptitle("COP paths on the plate, top view, plate coordinates (fixed extent)", fontsize=10)
    fig.savefig(path_place, dpi=150)
    plt.close(fig)
    return {"standardised": info, "placement_extent_mm": pe}


def novel_n1(ser, res, path):
    fs = ser["fs"]
    trials = [S for S in ser["trials"] if "xcom" in S]
    fig, ax = plt.subplots(2, len(trials), figsize=(4 * len(trials), 5.5), squeeze=False)
    for k, S in enumerate(trials):
        x = S["xcom"]
        d = x["by_l"][0.9]
        n = d["ap"]["com"].size
        t = np.arange(n) / fs + x["t0_s"]
        for r, axn, lab in ((0, "ap", "AP"), (1, "ml", "ML")):
            A = ax[r][k]
            lo, hi = d[axn]["support_lo"] * 1000, d[axn]["support_hi"] * 1000
            A.axhspan(lo, hi, color="#e5e7eb", lw=0, label="support envelope")
            A.plot(t, d[axn]["cop"] * 1000, color="#9ca3af", lw=0.6, label="COP")
            A.plot(t, d[axn]["com"] * 1000, color=C["ap"], lw=1.2, label="COM (force integral)")
            A.plot(t, d[axn]["com_ip"] * 1000, color=C["ap"], lw=0.8, ls="--", label="COM (pendulum filter)")
            u = d[axn]["u_t"] * 1000                  # grows towards landing (integration drift)
            A.fill_between(t, d[axn]["xcom"] * 1000 - u, d[axn]["xcom"] * 1000 + u, color=C["ml"], alpha=0.25, lw=0)
            A.plot(t, d[axn]["xcom"] * 1000, color=C["ml"], lw=1.2, label="XcoM ± uncertainty")
            xs = np.concatenate([d[axn]["xcom"], d[axn]["com"]]) * 1000
            ymin = min(lo, np.nanmin(xs)) - 10
            ymax = max(hi, np.nanmax(xs)) + 10
            A.set_ylim(ymin, ymax)
            if d.get("tds_determinable"):
                A.axvline(d["tds_s"], color="k", ls=":", lw=1)
            A.set_ylabel(f"{lab} (mm)")
            if r == 0:
                A.set_title(f"Trial {S['number']}")
            else:
                A.set_xlabel("Time from landing TD2 (s)")
    h, lab = ax[1][0].get_legend_handles_labels()
    h += [Line2D([], [], color="k", ls=":", lw=1)]
    lab += ["TDS (only where determinable)"]
    fig.legend(h, lab, loc="lower center", ncol=6, fontsize=8, frameon=False)
    fig.suptitle("N1: force-plate-only XcoM against the support envelope (l = 0.9 m); dotted = TDS where determinable")
    fig.tight_layout(rect=(0, 0.06, 1, 1))
    fig.savefig(path)
    plt.close(fig)


def novel_n2(ser, res, path):
    fig, ax = plt.subplots(1, 2, figsize=(12, 3.8))
    for k, (T, S) in enumerate(zip(res["trials"], ser["trials"])):
        if "stab" not in S:
            continue
        st, f = S["stab"], S["stab_fit"]
        col = tcol(k)
        ax[0].plot(st["t"], st["s"], color=col, lw=0.9, label=f"Trial {T['number']}  τ = {f['tau_s']*1000:.0f} ms")
        ax[0].plot(st["t"][f["i0"]:], f["pred"], color=col, lw=1.4, ls="--")
        ax[0].axvline(f["t95_s"], color=col, lw=0.8, ls=":")
        shared = res.get("n2_shared_quiet_level") or st["quiet_level"]
        ax[1].semilogy(st["t"], np.clip(st["s"] / shared, 0.1, None), color=col, lw=0.9, label=f"Trial {T['number']}")
        t2 = T["novel_tdpsi"].get("t_within_2x_shared_s")
        if t2 is not None:
            ax[1].axvline(t2, color=col, lw=0.8, ls=":")
    ax[0].set_xlim(0, 1.2)
    ax[0].set_xlabel("Time from landing TD2 (s)")
    ax[0].set_ylabel("s(t)")
    h, _ = ax[0].get_legend_handles_labels()
    h += [Line2D([], [], color="#6b7280", ls="--", lw=1.4, label="exponential fit"),
          Line2D([], [], color="#6b7280", ls=":", lw=1, label="t95 (model recovery time)")]
    ax[0].legend(handles=h, fontsize=7)
    ax[0].set_title("s(t), exponential fit and t95")
    ax[1].axhline(2, color="k", lw=0.8, ls=":")
    ax[1].set_ylim(0.1, None)
    ax[1].set_xlabel("Time from landing TD2 (s)")
    ax[1].set_ylabel("s(t) / shared quiet level")
    ax[1].set_title("s(t) relative to the shared quiet level")
    h, _ = ax[1].get_legend_handles_labels()
    h += [Line2D([], [], color="k", ls=":", lw=0.8, label="2 x quiet level"),
          Line2D([], [], color="#6b7280", ls=":", lw=0.8, label="time it stays within 2 x (vertical)")]
    ax[1].legend(handles=h, fontsize=7)
    fig.suptitle("N2: continuous stabilization curve (time-resolved DPSI, 10 Hz)")
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def sync_figure(delay_curves, video_sync, path):
    fig, ax = plt.subplots(1, 2, figsize=(12, 3.4))
    for name, (lags, r) in delay_curves.items():
        ax[0].plot(np.asarray(lags) * 1000, r, label=name)
    ax[0].axvline(48, color="k", ls=":", lw=1, label="48 ms (Delsys)")
    ax[0].set_xlabel("Trigno lag (ms)")
    ax[0].set_ylabel("correlation")
    ax[0].set_title("Trigno accelerometer jerk vs force rate")
    ax[0].legend(fontsize=7)
    if video_sync is not None and len(video_sync.get("lags_s", [])):
        ax[1].plot(video_sync["lags_s"], video_sync["r"], color=C["ap"], label="motion-energy correlation")
        ax[1].axvline(video_sync["xcorr_offset_s"], color=C["ap"], ls=":", lw=1, label="correlation peak")
        ax[1].axvline(video_sync["offset_s"], color=C["ev"], ls="--", lw=1, label="final (contact transitions)")
        ax[1].set_xlabel("video time - force time (s)")
        ax[1].set_ylabel("correlation")
        ax[1].set_title("Video motion energy vs force movement signal")
        ax[1].legend(fontsize=7)
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


ZONE_COLS = [("td2_20_200ms", "TD2, 20-200 ms"), ("td2_tts_phase", "TTS phase"), ("td2_after_tts", "after TTS")]


def zone_heatmaps(ser, res, cfg, path):
    """Dwell maps of the landing (TD2) windows, each centred on the trial's quiet-stance COP, with the
    acceptable zone: the pooled 95% ellipse of quiet stance. Outside it = the risk zone, as defined here."""
    hcfg = cfg.get("heatmap", {})
    ext = tuple(hcfg.get("zone_extent_mm", [-40, 40, -40, 100]))
    bin_mm = hcfg.get("bin_mm", 4.0)
    zone = res["cop_quiet_zone"]
    panels, notes, rows = [], [], []
    for T, S in zip(res["trials"], ser["trials"]):
        if "cop_zone" not in T:
            continue
        cx, cy = T["cop_zone"]["centre_mm"]
        r, n = [], []
        for key, _ in ZONE_COLS:
            a, b = T["cop_windows_idx"][key]
            r.append((ser["cop_ml"][a:b] - cx, ser["cop_ap"][a:b] - cy))
            n.append(f"outside: {T['cop_zone']['outside_pct'][key]:.0f}%")
        panels.append(r)
        notes.append(n)
        rows.append(f"Trial {T['number']}")
    return hm.heatmap_grid(panels, path, [c[1] for c in ZONE_COLS], rows, ext, bin_mm=bin_mm, panel_in=2.0,
                           suptitle=f"COP dwell after landing, centred on quiet-stance COP\n"
                                    f"fixed {ext[1]-ext[0]:.0f} x {ext[3]-ext[2]:.0f} mm, {bin_mm:g} mm bins, top view",
                           zone=zone, notes=notes)
