"""Jump and landing kinetics from vertical and horizontal ground reaction force.

Forces are reaction forces on the body (N), zeroed. Times are seconds from the event.

Body weight (BW). Per trial:
- quiet: mean Fz in the quietest 1 s of single-leg stance, inside [TD2 + 1 s, stance end];
- joint: the BW at which the COM, integrated forward from TD2 with v_TD2 = -g FT/2, has
  zero mean velocity over the last 1 s of quiet stance (so its position is flat there).
  In closed form: BW = g mean(I) / (g mean(t) - v_TD2), with I(t) = integral of Fz from TD2.
The session BW is the mean of the joint estimates. Both appear in the results.

COM velocity. A drop jump starts with a non-zero touchdown velocity. Two routes:
- flight-time route: v_TO2 = g FT / 2, then v_TD1 = v_TO2 - integral((Fz - BW)/m) over
  contact 1 (assumes equal COM height at TO2 and TD2);
- backward route (Baca 1999; Xu et al. 2023): mean v = 0 over the last 1 s of quiet stance,
  integrate back to TD2, add the ballistic flight (v_TO2 = v_TD2 + g FT), then back through
  contact 1. It gives an impulse-momentum jump height v_TO2^2 / 2g that does not use flight
  time. Its error is about g (dBW/BW) T, with T the integrated time.
"""
from __future__ import annotations

import numpy as np
from scipy.integrate import trapezoid
from scipy.signal import find_peaks

from .signals import cumtrapz0, lowpass

G = 9.80665


def body_weight_quiet(Fz: np.ndarray, fs: float, s: int, e: int, win_s: float = 1.0,
                      skip_s: float = 1.0) -> dict:
    """Mean Fz in the quietest win_s window of [s + skip_s, e). e should be the stance end."""
    w = int(round(win_s * fs))
    a, b = s + int(round(skip_s * fs)), e
    if b - a < w:
        return {"bw_N": float("nan"), "sd_N": float("nan"), "start": a, "end": a,
                "flag": "stance too short for a quiet window"}
    best = None
    for i in range(a, b - w + 1, max(1, w // 20)):
        sd = float(np.std(Fz[i:i + w]))
        if best is None or sd < best[0]:
            best = (sd, i)
    sd, i = best
    return {"bw_N": float(np.mean(Fz[i:i + w])), "sd_N": sd, "start": i, "end": i + w, "flag": ""}


def body_weight_joint(Fz: np.ndarray, fs: float, td2: int, end: int, ft: float, win_s: float = 1.0) -> float:
    """BW that gives zero mean COM velocity over the last win_s before end."""
    I = cumtrapz0(Fz[td2:end], 1 / fs)
    t = np.arange(I.size) / fs
    w = int(round(win_s * fs))
    if I.size < w + int(0.5 * fs):
        return float("nan")
    v0 = -G * ft / 2.0
    return float(G * I[-w:].mean() / (G * t[-w:].mean() - v0))


def peaks(Fz: np.ndarray, fs: float, td: int, end: int, bw: float, fc: float = 75.0) -> dict:
    """First (forefoot) and largest (often heel-drop) peaks after a touchdown.

    Detection runs on a 75 Hz low-passed copy: the first peak within 150 ms with a
    prominence of at least 0.1 BW and a height of at least 0.3 x the largest value.
    Peak values are read from the unfiltered force at the detected index (+/- 3 ms).
    """
    seg = Fz[td:end]
    f = lowpass(Fz, fs, fc)[td:end]
    imax = int(np.argmax(seg))
    pk, _ = find_peaks(f[: int(0.15 * fs)], height=0.3 * f.max(), prominence=0.1 * bw)
    i1 = int(pk[0]) if pk.size else imax
    j = slice(max(0, i1 - 3), i1 + 4)
    i1 = int(j.start + np.argmax(seg[j]))
    return {"i_first": i1, "i_max": imax, "first_N": float(seg[i1]), "max_N": float(seg[imax])}


def loading(Fz: np.ndarray, fs: float, td: int, end: int, bw: float) -> dict:
    """Peak forces, loading rates and early impulse after a touchdown.

    LR definitions, all to the first peak (they differ; Ueda et al. 2016):
      inst    max dF/dt (50 Hz low-pass copy) from touchdown to the first peak (Pedley et al. 2023)
      t20_80  [F(0.8 T) - F(0.2 T)] / (0.6 T), T = time to first peak (Schmitz et al. 2014)
      f20_80  slope between 20% and 80% of the first-peak force (Milner et al. 2006)
    Impulses are total (not net) vertical impulse from touchdown.
    """
    pk = peaks(Fz, fs, td, end, bw)
    seg = Fz[td:end]
    i1 = pk["i_first"]
    f50 = lowpass(Fz, fs, 50.0)[td:end]
    dfdt = np.gradient(f50, 1.0 / fs)
    inst = float(np.max(dfdt[:max(i1, 2) + 1]))
    p1 = seg[i1]
    rise = seg[: i1 + 1]
    i20 = int(np.argmax(rise >= 0.2 * p1))
    i80 = int(np.argmax(rise >= 0.8 * p1))
    f2080 = (rise[i80] - rise[i20]) / max((i80 - i20) / fs, 1.0 / fs)
    T = i1 / fs
    j20, j80 = int(round(0.2 * i1)), int(round(0.8 * i1))
    t2080 = (seg[j80] - seg[j20]) / max(0.6 * T, 1.0 / fs)
    imp = lambda ms: float(trapezoid(seg[: int(round(ms / 1000 * fs)) + 1], dx=1 / fs))
    return {
        "first_peak_BW": float(p1 / bw), "t_first_peak_s": T,
        "max_peak_BW": pk["max_N"] / bw, "max_peak_N": pk["max_N"], "t_max_peak_s": pk["i_max"] / fs,
        "lr_inst_BW_s": inst / bw, "lr_t20_80_BW_s": float(t2080 / bw),
        "lr_f20_80_BW_s": float(f2080 / bw),
        "impulse_50ms_BWs": imp(50) / bw, "impulse_100ms_BWs": imp(100) / bw,
    }


def com_from_force(Fz: np.ndarray, fs: float, s: int, e: int, bw: float, v0: float) -> tuple:
    """COM vertical velocity and displacement over [s, e) from impulse-momentum."""
    a = (Fz[s:e] - bw) / (bw / G)
    v = v0 + cumtrapz0(a, 1.0 / fs)
    return v, cumtrapz0(v, 1.0 / fs)


def backward_velocity(Fz: np.ndarray, fs: float, tr, bw: float, end: int, win_s: float = 1.0) -> dict:
    """Backward integration with mean v = 0 over the last win_s before end (Baca 1999)."""
    m = bw / G
    ft = (tr.td2 - tr.to2) / fs
    I = cumtrapz0((Fz[tr.td2:end] - bw) / m, 1 / fs)
    w = int(round(win_s * fs))
    v_td2 = -float(I[-w:].mean())
    v_to2 = v_td2 + G * ft
    v_td1 = v_to2 - float(trapezoid((Fz[tr.td1:tr.to2 + 1] - bw) / m, dx=1 / fs))
    T = ((end - tr.td2) - w / 2 + (tr.to2 - tr.td1)) / fs
    return {"v_td2_back_m_s": v_td2, "v_to2_back_m_s": v_to2, "v_td1_back_m_s": v_td1,
            "jump_height_im_m": v_to2 ** 2 / (2 * G) if v_to2 > 0 else float("nan"),
            "v_to2_ft_m_s": G * ft / 2, "v_to2_diff_m_s": v_to2 - G * ft / 2,
            "dv_per_pct_bw_m_s": G * 0.01 * T}


def _extremes(x: np.ndarray, fs: float, fc: float = 20.0, prefix: str = "") -> dict:
    f = lowpass(x, fs, fc) if x.size > 30 else x
    i, j = int(np.argmin(f)), int(np.argmax(f))
    return {f"{prefix}min_N": float(f[i]), f"{prefix}t_min_s": i / fs,
            f"{prefix}max_N": float(f[j]), f"{prefix}t_max_s": j / fs}


def drop_jump(Fz, fs, tr, bw, ap, ml) -> tuple[dict, dict]:
    """Metrics for contact 1 (TD1 -> TO2) and the rebound (flight-time route)."""
    ct = (tr.to2 - tr.td1) / fs
    ft = (tr.td2 - tr.to2) / fs
    m = bw / G
    v_to = G * ft / 2.0
    dv = float(trapezoid((Fz[tr.td1:tr.to2 + 1] - bw) / m, dx=1 / fs))
    v_td = v_to - dv
    v, z = com_from_force(Fz, fs, tr.td1, tr.to2 + 1, bw, v_td)
    i0 = int(np.argmax(v >= 0)) if np.any(v >= 0) else len(v) - 1   # lowest COM point
    jh = G * ft ** 2 / 8.0
    c = slice(tr.td1, tr.to2 + 1)
    out = {
        "contact_time_s": ct, "flight_time_s": ft, "jump_height_ft_m": jh,
        "rsi_m_s": jh / ct, "rsr": ft / ct,
        "v_takeoff_m_s": v_to, "v_touchdown1_m_s": v_td,
        "effective_drop_height_m": v_td ** 2 / (2 * G),
        "braking_time_s": i0 / fs, "propulsive_time_s": ct - i0 / fs,
        "braking_net_impulse_BWs": float(trapezoid(Fz[tr.td1:tr.td1 + i0 + 1] - bw, dx=1 / fs) / bw),
        "propulsive_net_impulse_BWs": float(trapezoid(Fz[tr.td1 + i0:tr.to2 + 1] - bw, dx=1 / fs) / bw),
        "com_depression_m": float(-z.min()),
        "fz_at_lowest_com_BW": float(Fz[tr.td1 + i0] / bw),
        "peak_fz_braking_BW": float(Fz[tr.td1:tr.td1 + i0 + 1].max() / bw),
        # vertical stiffness = peak force / peak COM lowering (McMahon & Cheng 1990)
        "vertical_stiffness_BW_m": float(Fz[tr.td1:tr.td1 + i0 + 1].max() / bw / max(-z[i0], 1e-6)),
        "peak_power_W_kg": float(np.max(Fz[c] * v) / m),
        "ap_impulse_Ns": float(trapezoid(ap[c], dx=1 / fs)),
        "ml_impulse_Ns": float(trapezoid(ml[c], dx=1 / fs)),
    }
    out.update(_extremes(ap[c], fs, prefix="ap_"))
    out.update(_extremes(ml[c], fs, prefix="ml_"))
    out.update({f"td1_{k}": val for k, val in loading(Fz, fs, tr.td1, tr.to2, bw).items()})
    return out, {"v": v, "z": z, "i_lowest": i0}


def landing(Fz, fs, tr, bw, ft, ap, ml, end: int) -> tuple[dict, dict]:
    """Metrics for the second landing (TD2 -> end of quiet stance)."""
    v0 = -G * ft / 2.0
    v, z = com_from_force(Fz, fs, tr.td2, end, bw, v0)
    i0 = int(np.argmax(v >= 0)) if np.any(v >= 0) else len(v) - 1
    win = slice(tr.td2, tr.td2 + i0 + 1)
    out = {
        "v_touchdown2_m_s": v0,
        "time_to_lowest_com_s": i0 / fs,
        "landing_com_depression_m": float(-z[i0]),
        "fz_at_lowest_com_BW": float(Fz[tr.td2 + i0] / bw),
        "peak_fz_absorption_BW": float(Fz[win].max() / bw),
        "landing_stiffness_BW_m": float(Fz[win].max() / bw / max(-z[i0], 1e-6)),
        "landing_net_impulse_BWs": float(trapezoid(Fz[win] - bw, dx=1 / fs) / bw),
        "quiet_stance_s": (end - tr.td2) / fs,
    }
    hw = slice(tr.td2, min(end, tr.td2 + int(0.5 * fs)))      # horizontal extremes: first 0.5 s
    out.update(_extremes(ap[hw], fs, prefix="ap_"))
    out.update(_extremes(ml[hw], fs, prefix="ml_"))
    out.update({f"td2_{k}": val for k, val in loading(Fz, fs, tr.td2, min(end, tr.td2 + int(fs)), bw).items()})
    return out, {"v": v, "z": z, "i_lowest": i0}
