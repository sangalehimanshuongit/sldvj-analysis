"""jumpkit: force-plate, EMG, accelerometer and video analysis of jump landings."""
__version__ = "2.0.0"
