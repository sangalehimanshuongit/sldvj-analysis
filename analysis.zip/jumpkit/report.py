"""Tables and the self-contained HTML report (video + synchronized plots), and PDF export.

Every number in the report text is computed here from results.json, so the text cannot
drift from the tables.
"""
from __future__ import annotations

import base64
import html as H
import json
import os
import re
import subprocess

import numpy as np
import pandas as pd

R, L = "rebound", "landing"

# (path into one trial's results, label, unit, scale, decimals, definition / source)
CAT = {
    "rebound": [
        ((R, "contact_time_s"), "Ground contact time", "ms", 1000, 0, "TD1 to TO2"),
        ((R, "flight_time_s"), "Flight time", "ms", 1000, 0, "TO2 to TD2"),
        ((R, "jump_height_ft_m"), "Jump height, flight time", "cm", 100, 1, "g FT²/8 (Bosco et al. 1983); main jump height"),
        ((R, "rsi_m_s"), "RSI", "m/s", 1, 2, "jump height (flight time) / contact time (Flanagan & Comyns 2008)"),
        ((R, "rsr"), "RSR", "", 1, 2, "flight time / contact time (Healy et al. 2018)"),
        ((R, "v_touchdown1_m_s"), "COM velocity at TD1", "m/s", 1, 2, "from flight time and the contact-1 impulse"),
        ((R, "effective_drop_height_m"), "Effective drop height", "cm", 100, 1, "v_TD1²/2g (box height not recorded)"),
        ((R, "braking_time_s"), "Braking phase", "ms", 1000, 0, "TD1 to lowest COM (COM velocity = 0; Pedley et al. 2023)"),
        ((R, "propulsive_time_s"), "Propulsive phase", "ms", 1000, 0, "lowest COM to TO2"),
        ((R, "braking_net_impulse_BWs"), "Braking net impulse", "BW·s", 1, 3, "∫(Fz - BW) dt, TD1 to lowest COM"),
        ((R, "propulsive_net_impulse_BWs"), "Propulsive net impulse", "BW·s", 1, 3, "∫(Fz - BW) dt, lowest COM to TO2"),
        ((R, "com_depression_m"), "COM lowering", "cm", 100, 1, "lowest COM below its TD1 height"),
        ((R, "vertical_stiffness_BW_m"), "Vertical stiffness", "BW/m", 1, 1, "peak Fz in braking / COM lowering (McMahon & Cheng 1990)"),
        ((R, "peak_power_W_kg"), "Peak COM power", "W/kg", 1, 1, "max(Fz v) / mass"),
        ((R, "td1_first_peak_BW"), "First force peak", "BW", 1, 2, "first peak with prominence ≥ 0.1 BW (75 Hz copy); sensitive to that threshold"),
        ((R, "td1_t_first_peak_s"), "Time to first peak", "ms", 1000, 0, ""),
        ((R, "td1_max_peak_BW"), "Largest force peak", "BW", 1, 2, ""),
        ((R, "td1_lr_inst_BW_s"), "Loading rate, peak instantaneous", "BW/s", 1, 0, "max dF/dt to the first peak (Pedley et al. 2023)"),
        ((R, "td1_lr_t20_80_BW_s"), "Loading rate, 20-80% of time", "BW/s", 1, 0, "Schmitz et al. 2014"),
        ((R, "td1_lr_f20_80_BW_s"), "Loading rate, 20-80% of force", "BW/s", 1, 0, "Milner et al. 2006"),
        ((R, "td1_impulse_50ms_BWs"), "Vertical impulse, first 50 ms", "BW·s", 1, 3, "total (not net) impulse"),
        ((R, "td1_impulse_100ms_BWs"), "Vertical impulse, first 100 ms", "BW·s", 1, 3, "total (not net) impulse"),
        ((R, "ap_min_N"), "Peak braking GRF (AP minimum)", "N", 1, 0, "20 Hz low-pass; time in Appendix A"),
        ((R, "ap_max_N"), "Peak propulsive GRF (AP maximum)", "N", 1, 0, "20 Hz low-pass"),
        ((R, "ap_impulse_Ns"), "AP impulse", "N·s", 1, 1, "negative = net braking"),
        ((R, "ml_min_N"), "Peak medial GRF (ML minimum)", "N", 1, 0, "20 Hz low-pass"),
        ((R, "ml_max_N"), "Peak lateral GRF (ML maximum)", "N", 1, 0, "20 Hz low-pass"),
    ],
    "landing": [
        ((L, "td2_first_peak_BW"), "First force peak", "BW", 1, 2, "prominence ≥ 0.1 BW"),
        ((L, "td2_t_first_peak_s"), "Time to first peak", "ms", 1000, 0, ""),
        ((L, "td2_max_peak_BW"), "Largest force peak", "BW", 1, 2, ""),
        ((L, "td2_lr_inst_BW_s"), "Loading rate, peak instantaneous", "BW/s", 1, 0, ""),
        ((L, "td2_lr_t20_80_BW_s"), "Loading rate, 20-80% of time", "BW/s", 1, 0, "Schmitz et al. 2014"),
        ((L, "td2_lr_f20_80_BW_s"), "Loading rate, 20-80% of force", "BW/s", 1, 0, "Milner et al. 2006"),
        ((L, "td2_impulse_50ms_BWs"), "Vertical impulse, first 50 ms", "BW·s", 1, 3, "total impulse"),
        ((L, "td2_impulse_100ms_BWs"), "Vertical impulse, first 100 ms", "BW·s", 1, 3, "total impulse"),
        ((L, "v_touchdown2_m_s"), "COM velocity at TD2", "m/s", 1, 2, "-g FT/2"),
        ((L, "time_to_lowest_com_s"), "Time to lowest COM", "ms", 1000, 0, "absorption phase"),
        ((L, "landing_com_depression_m"), "COM lowering", "cm", 100, 1, ""),
        ((L, "landing_stiffness_BW_m"), "Landing stiffness", "BW/m", 1, 1, "peak Fz in absorption / COM lowering"),
        ((L, "ap_min_N"), "Peak braking GRF (AP minimum)", "N", 1, 0, "first 0.5 s after TD2, 20 Hz"),
        ((L, "ml_min_N"), "Peak medial GRF (ML minimum)", "N", 1, 0, "first 0.5 s after TD2, 20 Hz"),
        ((L, "ml_max_N"), "Peak lateral GRF (ML maximum)", "N", 1, 0, "first 0.5 s after TD2, 20 Hz"),
        ((L, "quiet_stance_s"), "Usable stance after TD2", "s", 1, 2, "TD2 to end of quiet stance"),
    ],
    "stability": [
        (("dpsi_common", "DPSI"), "DPSI, common 2.5 s window", "", 1, 3, "Wikstrom et al. 2005 form, 20 Hz; the 3 s standard is not reachable"),
        (("dpsi_common", "APSI"), "APSI, 2.5 s", "", 1, 3, ""),
        (("dpsi_common", "MLSI"), "MLSI, 2.5 s", "", 1, 3, ""),
        (("dpsi_common", "VSI"), "VSI, 2.5 s", "", 1, 3, ""),
        (("dpsi", "DPSI"), "DPSI, whole usable stance", "", 1, 3, "window below; shorter windows read higher"),
        (("dpsi", "window_s"), "Usable stance window", "s", 1, 2, ""),
    ],
}
COP_WINDOWS = [("td1_20_100ms", "TD1 20-100 ms"), ("td1_20_200ms", "TD1 20-200 ms"), ("td1_contact", "TD1+20 ms to TO2"),
               ("td2_20_100ms", "TD2 20-100 ms"), ("td2_20_200ms", "TD2 20-200 ms"),
               ("td2_dynamic_0.4s_to_end", "TD2 0.4 s-end"), ("td2_full_to_end", "TD2 whole stance"),
               ("td2_tts_phase", "TD2 TTS phase"), ("td2_after_tts", "TD2 after TTS")]
COP_METRICS = [("path_mm", "Path length", "mm", 0), ("mean_velocity_mm_s", "Mean velocity", "mm/s", 0),
               ("net_displacement_mm", "Net displacement", "mm", 0), ("ap_range_mm", "AP range", "mm", 0),
               ("ml_range_mm", "ML range", "mm", 0), ("rms_distance_mm", "RMS distance", "mm", 1),
               ("ellipse95_area_mm2", "95% ellipse area", "mm²", 0), ("coverage_pct", "Valid COP", "%", 0)]
EMG_METRICS = [("pre100_pct", "pre-activation, 100 ms", "% peak", 0), ("pre150_pct", "pre-activation, 150 ms", "% peak", 0),
               ("pre150_pct_delay18ms", "pre-activation 150 ms, if the delay were 18 ms", "% peak", 0),
               ("pre150_pct_delay78ms", "pre-activation 150 ms, if the delay were 78 ms", "% peak", 0),
               ("post50_pct", "0-50 ms after contact", "% peak", 0),
               ("slr_30_60ms_pct", "30-60 ms after contact", "% peak", 0), ("post200_pct", "0-200 ms mean", "% peak", 0),
               ("peak_post_pct", "envelope peak, 0-200 ms", "% peak", 0), ("t_peak_post_s", "time to envelope peak", "ms", 1),
               ("clipped_pct_window", "clipped samples, -150 to +200 ms", "%", 1)]
EVENT_LABELS = [("td1", "First touchdown (TD1)"), ("td1_lowest_com", "Lowest COM, contact 1"),
                ("to2", "Rebound take-off (TO2)"), ("td2", "Second touchdown (TD2)"),
                ("td2_lowest_com", "Lowest COM, landing"), ("stance_end", "End of quiet stance"),
                ("off", "Step-off, or record end if not observed")]


def _get(d, path):
    for p in path:
        if not isinstance(d, dict):
            return None
        d = d.get(p)
    return d


def _num(v):
    return v is not None and isinstance(v, (int, float, np.floating)) and not isinstance(v, bool) and np.isfinite(v)


def _stats(vals):
    v = np.array([x for x in vals if _num(x)], float)
    if v.size == 0:
        return None, None, None, 0
    mean = float(v.mean())
    sd = float(v.std(ddof=1)) if v.size > 1 else None
    same_sign = bool((v > 0).all() or (v < 0).all())
    cv = float(100 * sd / abs(mean)) if (sd is not None and same_sign and abs(mean) > 1e-12) else None
    return mean, sd, cv, int(v.size)


def _row(section, label, unit, vals, dec, note, text=None):
    mean, sd, cv, n = _stats(vals)
    r = {"section": section, "metric": label, "unit": unit}
    for i, v in enumerate(vals):
        r[f"T{i+1}"] = (text[i] if text and text[i] else (round(float(v), dec + 2) if _num(v) else None))
    r.update({"mean": mean, "sd": sd, "cv_pct": cv, "n": n, "decimals": dec, "definition": note})
    return r


def _scaled(T, path, sc):
    v = _get(T, path)
    return v * sc if _num(v) else None


def tables(res, legacy_df) -> dict:
    trials = res["trials"]
    rows = []
    for sec, items in CAT.items():
        for path, lab, unit, sc, dec, note in items:
            rows.append(_row(sec, lab, unit, [_scaled(T, path, sc) for T in trials], dec, note))
    for mus in ("EMG1", "EMG2"):
        for ev in ("td1", "td2"):
            for mk, ml_, unit, dec in EMG_METRICS:
                sc = 1000 if unit == "ms" else 1
                rows.append(_row(f"emg_{mus}", f"{ev.upper()} {ml_}", unit,
                                 [_scaled(T, ("emg", mus, ev, mk), sc) for T in trials], dec, ""))
    kin = (res.get("video") or {}).get("kinematics")
    if kin:
        for key, lab, note in (("fppa_at_td1_deg", "Knee FPPA, first frame after TD1", "frame gap in Appendix A"),
                               ("fppa_at_td2_deg", "Knee FPPA, first frame after TD2", ""),
                               ("fppa_peak_0_500ms_deg", "Knee FPPA peak, 0-500 ms after TD2", ""),
                               ("fppa_change_from_td2_deg", "Knee FPPA change from TD2", "use this one (Asaeda et al. 2024)"),
                               ("fppa_stance_mean_deg", "Knee FPPA, mean in stance", "0.5 s after TD2 to 1 s before stance end")):
            rows.append(_row("kin", lab, "deg", [k.get(key) for k in kin], 1, note))
    n1 = [T.get("novel_xcom") for T in trials]
    if all(n1):
        d9 = [d["by_l"]["0.9"] for d in n1]
        txt = [(f"{d['tds_s']:.2f}" if d.get("tds_determinable") else "not determinable") for d in d9]
        rows.append(_row("n1", "Time to dynamic stability (TDS)", "s",
                         [d["tds_s"] if d.get("tds_determinable") else None for d in d9], 2,
                         "from TD2; determinable only if a ±2 N force offset moves it by ≤ 0.2 s", text=txt))
        rng_txt = [(f"{d['tds_offset_range_s'][0]:.2f}-{d['tds_offset_range_s'][1]:.2f}"
                    + ("" if all(c[0].isdigit() for c in d["tds_offset_states"]) else " (some censored)"))
                   for d in d9]
        rows.append(_row("n1", "TDS range under ±2 N offset", "s", [None] * len(d9), 2,
                         "9 offset combinations (AP × ML)", text=rng_txt))
        rows.append(_row("n1", "XcoM uncertainty at window start", "mm", [d.get("u_at_window_start_mm") for d in d9], 0,
                         "grows towards landing (integration drift)"))
        for key, lab, unit, dec, note in (
                ("min_margin_ap_mm", "Minimum XcoM margin, AP", "mm", 1, "negative = outside the envelope"),
                ("min_margin_ml_mm", "Minimum XcoM margin, ML", "mm", 1, ""),
                ("u_ap_mm", "XcoM uncertainty, AP", "mm", 1, "from position and velocity differences of the two COM estimates"),
                ("u_ml_mm", "XcoM uncertainty, ML", "mm", 1, ""),
                ("pct_time_outside", "Time with XcoM outside", "%", 0, "")):
            rows.append(_row("n1", lab, unit, [d.get(key) for d in d9], dec, note))
        rows.append(_row("n1", "Support envelope, AP width", "mm",
                         [d["envelope_ap_mm"][1] - d["envelope_ap_mm"][0] for d in n1], 0, "COP range from 20 ms after TD2"))
        rows.append(_row("n1", "Support envelope, ML width", "mm",
                         [d["envelope_ml_mm"][1] - d["envelope_ml_mm"][0] for d in n1], 0, ""))
    n2 = [T.get("novel_tdpsi") for T in trials]
    if all(n2):
        ci = [f"{d['tau_s']*1000:.0f} ({d['tau_ci95_s'][0]*1000:.0f}-{d['tau_ci95_s'][1]*1000:.0f})"
              if _num(d["tau_ci95_s"][0]) else None for d in n2]
        rows.append(_row("n2", "Recovery time constant τ (95% CI)", "ms", [d["tau_s"] * 1000 for d in n2], 0,
                         "10 Hz; A e^(-t/τ) + C from the curve peak; block-bootstrap CI", text=ci))
        for key, lab, unit, sc, dec, note in (
                ("tau_fc20Hz_s", "τ with a 20 Hz filter", "ms", 1000, 0, "same fit start (impact peak)"),
                ("tau_fc40Hz_s", "τ with a 40 Hz filter", "ms", 1000, 0, ""),
                ("tau_fc5Hz_s", "τ with a 5 Hz filter", "ms", 1000, 0, "a 5 Hz filter smears the impact peak"),
                ("t95_s", "Model recovery time t95", "s", 1, 2, "t_peak + τ ln 20"),
                ("t_within_2x_shared_s", "Time to stay within 2x quiet level", "s", 1, 2,
                 "model-free; one quiet level shared by all trials (trial 2's own level is 1.6x the shared one)"),
                ("dpsi_share_first_0.4s_pct", "Share of DPSI built in the first 0.4 s", "%", 1, 0, "from the 10 Hz N2 curve, 2.5 s window"),
                ("r2", "Fit R²", "", 1, 2, ""),
                ("tau_horizontal_from_lowest_com_s", "Horizontal-only τ from lowest COM", "ms", 1000, 0,
                 "not identifiable when R² < 0.6"),
                ("r2_horizontal", "Horizontal-only fit R²", "", 1, 2, "")):
            vals = [(d.get(key) * sc if _num(d.get(key)) else None) for d in n2]
            if key == "tau_horizontal_from_lowest_com_s":
                vals = [v if (d.get("r2_horizontal") or 0) >= 0.6 else None for v, d in zip(vals, n2)]
                rows.append(_row("n2", lab, unit, vals, dec, note + " (n.i. = not identifiable)",
                                 text=[None if v is not None else "n.i." for v in vals]))
                continue
            rows.append(_row("n2", lab, unit, vals, dec, note))
    metrics = pd.DataFrame(rows)

    cop_rows = []
    for mk, lab, unit, dec in COP_METRICS:
        r = {"measure": lab, "unit": unit}
        for key, wl in COP_WINDOWS:
            mean, sd, _, _ = _stats([T["cop"].get(key, {}).get(mk) for T in trials])
            r[wl] = None if mean is None else (f"{mean:.{dec}f}" + (f" ± {sd:.{dec}f}" if sd is not None else ""))
        cop_rows.append(r)
    cop = pd.DataFrame(cop_rows)

    off = (res.get("video") or {}).get("offset_s", 0.0)
    ev_rows = []
    for key, lab in EVENT_LABELS:
        r = {"event": lab}
        for T in trials:
            v = T["events_s"][key]
            r[f"T{T['number']} force (s)"] = round(v, 3)
            r[f"T{T['number']} video (s)"] = round(v + off, 3)
        ev_rows.append(r)
    events = pd.DataFrame(ev_rows)

    sens = pd.DataFrame(res["qc"]["threshold_sensitivity"])
    if len(sens):
        sens = sens.pivot_table(index="threshold_N", columns="trial", values=["contact_ms", "flight_ms"])
        sens.columns = [f"T{int(t)} {'contact' if c == 'contact_ms' else 'flight'} (ms)" for c, t in sens.columns]
        sens = sens.reset_index().rename(columns={"threshold_N": "threshold (N)"})

    tts_cols = [c for c in (legacy_df.columns if legacy_df is not None else []) if "tts" in c]
    return {"metrics_by_trial": metrics, "cop_summary": cop, "events": events,
            "threshold_sensitivity": sens, "legacy_vs_v2": legacy_table(res, legacy_df),
            "all_values": all_values(res),
            "legacy_tts_max_s": float(np.nanmax(legacy_df[tts_cols].values)) if tts_cols else float("nan")}


def all_values(res) -> pd.DataFrame:
    """Every scalar result per trial (Appendix A)."""
    skip = {"events_idx", "cop_windows_idx", "number", "flags"}
    flat = []
    for T in res["trials"]:
        d = {}

        def walk(x, pre):
            if isinstance(x, dict):
                for k, v in x.items():
                    if pre == "" and k in skip:
                        continue
                    walk(v, f"{pre}.{k}" if pre else k)
            elif isinstance(x, (int, float)) and not isinstance(x, bool):
                d[pre] = x
            elif isinstance(x, str) and x:
                d[pre] = x
        walk(T, "")
        flat.append(d)
    keys = list(dict.fromkeys(k for d in flat for k in d))
    fmt = lambda v: (f"{v:.4f}".rstrip("0").rstrip(".") if abs(v) < 1e4 else f"{v:.0f}") if isinstance(v, float) else ("" if v is None else str(v))
    return pd.DataFrame([{"value": k, **{f"T{i+1}": fmt(d.get(k)) for i, d in enumerate(flat)}} for k in keys])


def legacy_table(res, legacy_df) -> pd.DataFrame:
    """One row per legacy output: legacy mean, v2 equivalent mean, verdict.

    Axis note: v1 takes "AP" from plate y and "ML" from plate x. In this setup plate x is AP,
    so v1 "AP" is ML here and the reverse; rows are paired by the true axis.
    """
    if legacy_df is None or not len(legacy_df):
        return pd.DataFrame()
    trials = res["trials"]
    lt = legacy_df["first_touchdown_time_s"].values
    pair = [int(np.argmin(np.abs(lt - T["events_s"]["td1"]))) for T in trials]     # match by TD1
    Lv = lambda col: [float(legacy_df.iloc[i][col]) for i in pair]
    V = lambda path: [(_get(T, path) if _num(_get(T, path)) else np.nan) for T in trials]
    rows = []

    def add(name, lv, nv, unit, verdict, sc=1.0):
        lm = float(np.nanmean(np.array(lv, float) * sc)) if lv is not None else None
        nm = float(np.nanmean(np.array(nv, float) * sc)) if nv is not None else None
        rows.append({"legacy output": name, "unit": unit, "legacy mean": lm, "v2 mean": nm, "verdict": verdict})

    for col, key, lab in (("first_touchdown_time_s", "td1", "TD1"), ("rebound_takeoff_time_s", "to2", "TO2"),
                          ("second_touchdown_time_s", "td2", "TD2")):
        d = [1000 * (a - T["events_s"][key]) for a, T in zip(Lv(col), trials)]
        md = float(np.mean(d))
        rows.append({"legacy output": f"{lab} time, legacy minus v2", "unit": "ms", "legacy mean": md, "v2 mean": 0.0,
                     "verdict": f"legacy {lab} is {abs(md):.0f} ms {'early' if md < 0 else 'late'} "
                                f"(range {min(d):.0f} to {max(d):.0f}): 20 Hz pre-filter and 20 N threshold"})
    add("jump count", [len(legacy_df)], [len(trials)], "", "same")
    rows.append({"legacy output": "mode", "unit": "", "legacy mean": None, "v2 mean": None,
                 "verdict": f"legacy {legacy_df.iloc[0]['mode']}; v2 single-leg drop vertical jump, "
                            f"{'right' if res['meta']['stance_leg'].upper() == 'R' else 'left'} leg"})
    add("ground contact time", Lv("ground_contact_time_s"), V((R, "contact_time_s")), "ms", "kept; v2 removes the event bias", 1000)
    add("flight time", Lv("flight_time_s"), V((R, "flight_time_s")), "ms", "kept", 1000)
    add("jump height", Lv("jump_height_m"), V((R, "jump_height_ft_m")), "cm", "kept; legacy reads low because its flight time is short", 100)
    add("RSI", Lv("reactive_strength_index_m_per_s"), V((R, "rsi_m_s")), "m/s", "kept; legacy reads low")
    for w, lab in (("td1", "TD1"), ("td2", "TD2")):
        add(f"{lab} COP net displacement, 200 ms", Lv(f"{w}_cop_net_displacement_200ms_mm"),
            V(("cop", f"{w}_20_200ms", "net_displacement_mm")), "mm",
            "kept as 20-200 ms; v2 masks the first 20 ms and low-force COP, legacy does not")
        add(f"{lab} COP path length, 200 ms", Lv(f"{w}_cop_path_length_200ms_mm"),
            V(("cop", f"{w}_20_200ms", "path_mm")), "mm", "kept as 20-200 ms; legacy is inflated by impact artefacts")
    for c, lab in (("vertical", "vertical"), ("ap", "'AP' (plate y = ML here)"), ("total", "total")):
        add(f"TD1 TTS {lab}", Lv(f"td1_tts_{c}_s"), None, "s", "dropped: a rebound jump follows TD1, so the body never settles")
    add("TD2 TTS vertical", Lv("td2_tts_vertical_s"), V(("tts", "tts_sa_V_s")), "s",
        "not interpretable here (needs at least 10 s of stance); the legacy cubic method is also incorrect")
    add("TD2 TTS 'AP' (plate y = ML here)", Lv("td2_tts_ap_s"), V(("tts", "tts_sa_ML_s")), "s", "as above; compared with v2 ML")
    add("TD2 TTS total", Lv("td2_tts_total_s"), V(("tts", "rv_tts_sa_s")), "s", "as above; v2 equivalent is the resultant-vector TTS")
    pairs = (("ap_range", "ml_range_mm", "'AP' range (plate y = ML here)"), ("ml_range", "ap_range_mm", "'ML' range (plate x = AP here)"),
             ("total_rms", "rms_distance_mm", "RMS distance"), ("mean_velocity", "mean_velocity_mm_s", "mean velocity"))
    for c, key, lab in pairs:
        unit = "mm/s" if "velocity" in c else "mm"
        lc1 = "td1_cop_mean_velocity_10s_mm_s" if "velocity" in c else f"td1_cop_{c}_10s_mm"
        lc2 = "td2_cop_mean_velocity_10s_mm_s" if "velocity" in c else f"td2_cop_{c}_10s_mm"
        add(f"TD1 '10 s' COP {lab}", Lv(lc1), V(("cop", "td1_contact", key)), unit,
            "replaced by the TD1-TO2 window (contact 1 lasts about 0.36 s)")
        add(f"TD2 '10 s' COP {lab}", Lv(lc2), V(("cop", "td2_dynamic_0.4s_to_end", key)), unit,
            "replaced by TD2 0.4 s to end of quiet stance (about 2.2 s); legacy ran past the step-off")
    add("body weight", [float(legacy_df.iloc[0]["body_weight_N"])], [res["body_weight"]["session_bw_N"]], "N",
        "legacy: histogram mode of loaded samples; v2: joint quiet-stance estimate")
    add("body mass", [float(legacy_df.iloc[0]["body_mass_kg"])], [res["body_weight"]["session_mass_kg"]], "kg", "follows body weight")
    add("event threshold", [float(legacy_df.iloc[0]["event_threshold_N"])], [res["qc"]["detection"]["threshold_N"]], "N",
        "v2: max(5 SD, peak residual, 5 N floor), then edge refinement")
    r0 = legacy_df.iloc[0]
    rows.append({"legacy output": "QC verdict", "unit": "", "legacy mean": None, "v2 mean": None,
                 "verdict": f"legacy: {r0['jump_count_flag']} (confidence {r0['confidence_score']}, {r0['qc_reasons']}); "
                            f"v2: explicit checks (Appendix D)"})
    rows.append({"legacy output": "COP heatmaps", "unit": "", "legacy mean": None, "v2 mean": None,
                 "verdict": "replaced by standardized maps: fixed extent, bins and colour scale"})
    rows.append({"legacy output": "CMJ outputs", "unit": "", "legacy mean": None, "v2 mean": None,
                 "verdict": "no CMJ in this file; v2 has CMJ detection and metrics (jumpkit/cmj.py), tested on synthetic data"})
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------- HTML
VIDEO_BLOCK = re.compile(r"<!--VIDEO-->(.*?)<!--/VIDEO-->", re.S)


def video_blocks(tpl: str, has_video: bool) -> str:
    """Keep the <!--VIDEO--> ... <!--/VIDEO--> parts of a template only when the session has video."""
    return VIDEO_BLOCK.sub(lambda m: m.group(1) if has_video else "", tpl)


def session_fields(res) -> dict:
    """Template values that name the session: file, record, stance leg, video and output names."""
    from .session import suffix
    m = res["meta"]
    leg = "right" if m["stance_leg"].upper() == "R" else "left"
    sfx = suffix(m["file"])
    return {"%%SUFFIX%%": sfx, "%%FILE%%": os.path.basename(m["file"]), "%%RECORD%%": str(m["record"]),
            "%%LEG%%": leg, "%%LEGCAP%%": leg.capitalize(), "%%VIDEOFILE%%": os.path.basename(m.get("video") or ""),
            "%%REPORTNAME%%": f"SLDVJ_report_{sfx}.html"}


def _img(path):
    mime = "image/jpeg" if path.lower().endswith((".jpg", ".jpeg")) else "image/png"
    with open(path, "rb") as f:
        return f"data:{mime};base64," + base64.b64encode(f.read()).decode()


def _fmt(v, dec):
    if isinstance(v, str):
        return H.escape(v)
    if not _num(v):
        return "–"
    return f"{v:.{dec}f}"


def _metric_table(df, section, defs=True):
    d = df[df.section == section]
    if not len(d):
        return ""
    n = len([c for c in d.columns if c.startswith("T") and c[1:].isdigit()])
    head = "".join(f"<th>Trial {i+1}</th>" for i in range(n))
    rows = []
    for _, r in d.iterrows():
        dec = int(r["decimals"])
        cells = "".join(f"<td class='num'>{_fmt(r[f'T{i+1}'], dec)}</td>" for i in range(n))
        nn = f" <span class='n'>(n={int(r['n'])})</span>" if 0 < r["n"] < n else ""
        rows.append(f"<tr><td>{H.escape(r['metric'])}</td><td class='unit'>{H.escape(r['unit'])}</td>{cells}"
                    f"<td class='num strong'>{_fmt(r['mean'], dec)}{nn}</td><td class='num'>{_fmt(r['sd'], dec)}</td>"
                    f"<td class='num'>{_fmt(r['cv_pct'], 0)}</td>"
                    + (f"<td class='def'>{H.escape(r['definition'] or '')}</td>" if defs else "") + "</tr>")
    return (f"<table class='metrics'><thead><tr><th>Measure</th><th>Unit</th>{head}<th>Mean</th><th>SD</th>"
            f"<th>CV %</th>{'<th>Definition / source</th>' if defs else ''}</tr></thead><tbody>{''.join(rows)}</tbody></table>")


def _simple_table(df, fmt=None, cls="metrics"):
    if df is None or not len(df):
        return ""
    fmt = fmt or {}
    cols = list(df.columns)
    head = "".join(f"<th>{H.escape(str(c))}</th>" for c in cols)
    body = []
    for _, r in df.iterrows():
        cells = []
        for c in cols:
            v = r[c]
            if isinstance(v, (float, np.floating)):
                cells.append(f"<td class='num'>{_fmt(float(v), fmt.get(c, 1))}</td>")
            else:
                cells.append(f"<td>{'&ndash;' if v is None else H.escape(str(v))}</td>")
        body.append("<tr>" + "".join(cells) + "</tr>")
    return f"<table class='{cls}'><thead><tr>{head}</tr></thead><tbody>{''.join(body)}</tbody></table>"


def _legacy_display(lg):
    """Means to 3 significant figures (so RSI 0.222 vs 0.243 is visible)."""
    if not len(lg):
        return lg
    d = lg.copy()
    f = lambda v: "" if v is None or not np.isfinite(v) else (f"{v:.3g}" if abs(v) < 100 else f"{v:.0f}")
    for c in ("legacy mean", "v2 mean"):
        d[c] = [f(v) if v is not None else "" for v in lg[c]]
    return d


def _vals(res, path, sc=1):
    return np.array([(_get(T, path) * sc if _num(_get(T, path)) else np.nan) for T in res["trials"]], float)


def _rng(a, d):
    return f"{np.nanmin(a):.{d}f}-{np.nanmax(a):.{d}f}"


def findings(res) -> str:
    """Main findings, built from results so the text always matches the tables."""
    g = lambda p, sc=1: _vals(res, p, sc)
    ct, ft, jh, rsi = g((R, "contact_time_s"), 1000), g((R, "flight_time_s"), 1000), g((R, "jump_height_ft_m"), 100), g((R, "rsi_m_s"))
    pk1, t1, lr1 = g((R, "td1_first_peak_BW")), g((R, "td1_t_first_peak_s"), 1000), g((R, "td1_lr_inst_BW_s"))
    pk2, dep2, tz2 = g((L, "td2_first_peak_BW")), g((L, "landing_com_depression_m"), 100), g((L, "time_to_lowest_com_s"))
    v2 = g((L, "v_touchdown2_m_s"))
    dp, share, tau = g(("dpsi_common", "DPSI")), g(("novel_tdpsi", "dpsi_share_first_0.4s_pct")), g(("novel_tdpsi", "tau_s"), 1000)
    n = len(res["trials"])
    lo_jh = int(np.nanargmin(jh)) + 1
    hard = int(np.nanargmax(pk1)) + 1
    soft = int(np.nanargmin(pk2)) + 1
    oth = [i for i in range(n) if i != soft - 1]
    cv = lambda a: 100 * np.nanstd(a, ddof=1) / np.nanmean(a)
    qc = res["qc"]
    clip = [T["emg"]["EMG2"][ev]["clipped_pct_window"] for T in res["trials"] for ev in ("td1", "td2")]
    lower = " after its lower jump" if soft == lo_jh else ""
    items = [
        f"<b>Rebound.</b> Contact lasted {_rng(ct, 0)} ms and flight {_rng(ft, 0)} ms. Jump height was {_rng(jh, 1)} cm "
        f"(flight time, CV {cv(jh):.0f}%), so RSI was {_rng(rsi, 2)} m/s. Trial {lo_jh} jumped lowest.",
        f"<b>First touchdown.</b> The first force peak was {_rng(pk1, 2)} BW at {_rng(t1, 0)} ms. "
        f"Peak loading rate was {_rng(lr1, 0)} BW/s (CV {cv(lr1):.0f}%). Trial {hard} hit hardest.",
        f"<b>Landing.</b> The first force peak was {_rng(pk2, 2)} BW. Trial {soft} landed softest: its absorption phase "
        f"lasted {tz2[soft-1]:.2f} s (others {_rng(tz2[oth], 2)} s) and the COM dropped {dep2[soft-1]:.1f} cm "
        f"(others {_rng(dep2[oth], 1)} cm). It also arrived slower ({abs(v2[soft-1]):.2f} vs "
        f"{_rng(np.abs(v2[oth]), 2)} m/s){lower}.",
        f"<b>Stability.</b> DPSI over a common {res['common_window_s']:.1f} s window was {_rng(dp, 3)}. "
        f"{np.nanmin(share):.0f}-{np.nanmax(share):.0f}% of its sum of squares builds up in the first 0.4 s, so it "
        f"mostly reflects the impact. This is consistent with Huurnink et al. (2019), who found that DPSI tracks peak force.",
        n1_sentence(res) + f" N2 gives a recovery time constant of {_rng(tau, 0)} ms.",
        review_sentence(res),
        f"<b>Fix in future sessions.</b> Stance after landing was {_rng(g((L, 'quiet_stance_s')), 1)} s, too short for "
        f"the standard time to stabilization (it needs at least 10 s), so TTS here uses a short-stance method. EMG2 clips in {qc['emg_clipping_pct']['EMG2']:.1f}% of all "
        f"samples and in up to {max(clip):.0f}% of the impact windows. Both accelerometers clip on every axis at impact. "
        f"Trigno timing carries about \u00b130 ms of uncertainty.",
    ]
    return "<ul>" + "".join(f"<li>{i}</li>" for i in items) + "</ul>"


def review_sentence(res) -> str:
    """The measures added after the 2026-10-22 feature review, in one findings item."""
    g = lambda p, sc=1: _vals(res, p, sc)
    pk, imp, st = g((L, "td2_max_peak_BW")), g((L, "td2_impulse_50ms_BWs")), g((L, "landing_stiffness_BW_m"))
    z = {w: g(("cop_zone", "outside_pct", w)) for w in ("td2_20_200ms", "td2_tts_phase", "td2_after_tts")}
    ea, em = g(("cop_entropy", "td2_tts_phase", "sampen_AP")), g(("cop_entropy", "td2_tts_phase", "sampen_ML"))
    cb, ca = g(("cocontraction", "td2", "pre150", "cci_pct")), g(("cocontraction", "td2", "post50", "cci_pct"))
    return (f"<b>Review measures.</b> Landing peak force was {_rng(pk, 2)} BW, the vertical impulse over the first 50 ms "
            f"{_rng(imp, 3)} BW&middot;s, and stiffness (peak force / largest COM lowering) {_rng(st, 1)} BW/m. The COP "
            f"was outside the quiet-stance zone for {_rng(z['td2_20_200ms'], 0)}% of TD2 + 20-200 ms, "
            f"{_rng(z['td2_tts_phase'], 0)}% of the TTS phase and {_rng(z['td2_after_tts'], 0)}% after it. COP sample "
            f"entropy in the TTS phase was {_rng(ea, 2)} AP and {_rng(em, 2)} ML. VL-BF co-contraction was {_rng(cb, 0)}% "
            f"in the 150 ms before TD2 and {_rng(ca, 0)}% in the first 50 ms after it.")


def _range_cell(v, d=0) -> str:
    v = np.asarray([x for x in v if x is not None and np.isfinite(x)], float)
    if not v.size:
        return "-"
    return f"{np.mean(v):.{d}f} ({np.min(v):.{d}f}-{np.max(v):.{d}f})"


def sensitivity_tables(res) -> str:
    """Co-contraction under other Trigno delays and smoothing, and time outside the quiet zone
    under other quiet windows: mean (range) of the trials."""
    T = res["trials"]
    d0 = int(round(res["qc"]["trigno_delay"]["applied_s"] * 1000))
    cols = [("main", f"main ({d0} ms, 25 ms)"), (f"delay{d0 - 30}ms", f"delay {d0 - 30} ms"),
            (f"delay{d0 + 30}ms", f"delay {d0 + 30} ms"), ("smooth15ms", "smoothing 15 ms"), ("smooth50ms", "smoothing 50 ms")]
    rows = []
    for ev in ("td2", "td1"):
        for w, wl in (("pre150", "150 ms before"), ("post50", "0-50 ms after")):
            r = {"VL-BF co-contraction index (%)": f"{ev.upper()}, {wl}"}
            for k, lab in cols:
                v = [(t.get("cocontraction") or {}).get(ev, {}).get(w, {}).get("cci_pct") if k == "main"
                     else (t.get("cocontraction_sensitivity") or {}).get(f"{ev}_{w}_{k}") for t in T]
                r[lab] = _range_cell(v)
            rows.append(r)
    zr = []
    for w, wl in (("td2_20_200ms", "TD2 + 20-200 ms"), ("td2_tts_phase", "TTS phase"), ("td2_after_tts", "after TTS")):
        r = {"COP outside the quiet zone (%)": wl,
             "quiet window 1 s (main)": _range_cell([(t.get("cop_zone") or {}).get("outside_pct", {}).get(w) for t in T])}
        for q in ("0.5", "1.5"):
            r[f"quiet window {q} s"] = _range_cell([(t.get("cop_zone_sensitivity") or {}).get(f"quiet_{q}s", {}).get(w)
                                                    for t in T])
        zr.append(r)
    return _simple_table(pd.DataFrame(rows)) + _simple_table(pd.DataFrame(zr))


def n1_sentence(res) -> str:
    d9 = [(T["number"], T["novel_xcom"]["by_l"]["0.9"]) for T in res["trials"] if T.get("novel_xcom")]
    if not d9:
        return "<b>New analyses.</b>"
    det = [(n, d) for n, d in d9 if d.get("tds_determinable")]
    und = [str(n) for n, d in d9 if not d.get("tds_determinable")]
    u0 = [d["u_at_window_start_mm"] for _, d in d9]
    parts = []
    if det:
        parts.append("N1 found a time to dynamic stability in "
                     + ", ".join(f"trial {n} ({d['tds_s']:.2f} s)" for n, d in det))
    if und:
        parts.append(f"it was not determinable in trial{'s' if len(und) > 1 else ''} {' and '.join(und)}, "
                     f"because a ±2 N force offset moves it by more than 0.2 s")
    return (f"<b>New analyses.</b> {'; '.join(parts)}. The XcoM uncertainty grows to {min(u0):.0f}-{max(u0):.0f} mm "
            f"near landing, so N1 is a demonstration only.")


def _series_json(res, ser, step=2):
    bw = res["body_weight"]["session_bw_N"]
    sl = slice(None, None, step)
    ke = max(1, int(ser["fe"] / 250))
    clean = lambda a, dd: [None if not np.isfinite(x) else round(float(x), dd) for x in a]
    d = {"t": np.round(ser["t"][sl], 4).tolist(), "fz": np.round(ser["Fz"][sl] / bw, 4).tolist(),
         "fap": np.round(ser["F_ap"][sl] / bw, 4).tolist(), "fml": np.round(ser["F_ml"][sl] / bw, 4).tolist(),
         "cap": clean(ser["cop_ap"][sl], 1), "cml": clean(ser["cop_ml"][sl], 1),
         "te": np.round(ser["te"][::ke], 4).tolist(),
         "e1": np.round(100 * ser["emg_env"]["EMG1"][::ke], 2).tolist(),
         "e2": np.round(100 * ser["emg_env"]["EMG2"][::ke], 2).tolist(), "stab_t": [], "stab": []}
    for S in ser["trials"]:
        if "stab" not in S:
            continue
        st = S["stab"]
        d["stab_t"] += np.round(st["t"][::step] + S["td2"] / ser["fs"], 4).tolist() + [None]
        shared = res.get("n2_shared_quiet_level") or st["quiet_level"]
        d["stab"] += np.round(np.clip(st["s"][::step] / shared, 0.1, None), 3).tolist() + [None]
    if "pose" in ser:
        p = ser["pose"]
        d["pose_t"] = np.round(p["t"] - res["video"]["offset_s"], 4).tolist()
        d["fppa"] = clean(p["fppa"], 2)
    d["events"] = [{"trial": T["number"], "key": k, "label": lab, "t": round(T["events_s"][k], 4)}
                   for T in res["trials"] for k, lab in
                   (("td1", "TD1"), ("td1_lowest_com", "low COM 1"), ("to2", "TO2"), ("td2", "TD2"),
                    ("td2_lowest_com", "low COM 2"), ("stance_end", "stance end"))]
    d["offset"] = (res.get("video") or {}).get("offset_s", 0.0)
    d["frames"] = (res.get("video") or {}).get("frame_times_s", [])
    return json.dumps(d, separators=(",", ":"))


REFERENCES = [
    "Asaeda M, et al. 2024. Heliyon 10:e36338. doi:10.1016/j.heliyon.2024.e36338",
    "Baca A. 1999. A comparison of methods for analyzing drop jump performance. Med Sci Sports Exerc 31:437-42. doi:10.1097/00005768-199903000-00013",
    "Bobbert MF, Schamhardt HC. 1990. J Biomech 23:705-10. doi:10.1016/0021-9290(90)90169-4",
    "Bosco C, et al. 1983. Eur J Appl Physiol 50:273-82. doi:10.1007/BF00422166",
    "Colby SM, et al. 1999. J Orthop Sports Phys Ther 29:444-54. doi:10.2519/jospt.1999.29.8.444",
    "Flanagan EP, Comyns TM. 2008. Strength Cond J 30(5):32-8. doi:10.1519/SSC.0b013e318187e25b",
    "Fransz DP, et al. 2015. Gait Posture 41:63-9. doi:10.1016/j.gaitpost.2014.08.018",
    "Fransz DP, et al. 2016. J Biomech 49:496-501. doi:10.1016/j.jbiomech.2015.12.048 (corrigendum doi:10.1016/j.jbiomech.2017.07.036)",
    "Healy R, et al. 2018. Int J Sports Physiol Perform 13:802-9. doi:10.1123/ijspp.2017-0511",
    "Hof AL, et al. 2005. J Biomech 38:1-8. doi:10.1016/j.jbiomech.2004.03.025",
    "Huurnink A, et al. 2019. Gait Posture 73:80-5. doi:10.1016/j.gaitpost.2019.06.015",
    "Lafond D, et al. 2004. J Biomech 37:1421-6. doi:10.1016/S0021-9290(03)00251-3",
    "McMahon JJ, et al. 2018. Strength Cond J 40(4):96-106. doi:10.1519/SSC.0000000000000375",
    "McMahon TA, Cheng GC. 1990. J Biomech 23(Suppl 1):65-78",
    "Milner CE, et al. 2006. Med Sci Sports Exerc 38:323-8. doi:10.1249/01.mss.0000183477.75808.92",
    "Munro A, et al. 2012. J Sport Rehabil 21:7-11. doi:10.1123/jsr.21.1.7",
    "Oberländer KD, et al. 2012. J Biomech 45:1387-92. doi:10.1016/j.jbiomech.2012.02.029",
    "Ota M, et al. 2022. BMC Sports Sci Med Rehabil 14:174. doi:10.1186/s13102-022-00570-7",
    "Owen NJ, et al. 2014. J Strength Cond Res 28:1552-8. doi:10.1519/JSC.0000000000000311",
    "Pedley JS, et al. 2023. Strength Cond J 45:683-97. doi:10.1519/SSC.0000000000000776",
    "Ross SE, Guskiewicz KM. 2004. Clin J Sport Med 14:332-8. doi:10.1097/00042752-200411000-00002",
    "Ross SE, et al. 2005. J Athl Train 40:298-304. PMID 16404451",
    "Schmiedmayer HB, Kastner J. 2000. J Biomech Eng 122:523-7. doi:10.1115/1.1289687",
    "Schmitz A, et al. 2014. J Biomech 47:32-8. doi:10.1016/j.jbiomech.2013.10.026",
    "Schubert P, Kirchner M. 2014. Gait Posture 39:518-22. doi:10.1016/j.gaitpost.2013.09.001",
    "Smith JC, et al. 2024. Int J Exerc Sci 17:660-8. doi:10.70252/QBUA4521",
    "Sritharan P, et al. 2025. J Sports Sci 44:270-84. doi:10.1080/02640414.2025.2577563",
    "Street G, et al. 2001. J Appl Biomech 17:43-54. doi:10.1123/jab.17.1.43",
    "Ueda T, et al. 2016. Int J Sports Med 37:1087-90. doi:10.1055/s-0042-107248",
    "Wikstrom EA, et al. 2005. J Athl Train 40:305-9. PMID 16404452",
    "Wikstrom EA, et al. 2006. J Athl Train 41:245-50. PMID 17043691",
    "Xu J, et al. 2023. Sports Med 53:1055-72. doi:10.1007/s40279-023-01828-x",
    "Zatsiorsky VM, King DL. 1998. J Biomech 31:161-4. doi:10.1016/S0021-9290(97)00116-4",
    "Delsys Inc. Trigno Wireless System user's guide (legacy sensors). Vendor document, no DOI",
]


def _trial_blocks(res, fig):
    out = []
    for t in res["trials"]:
        n = t["number"]
        note = " The force record ends during this stance; the step-off is only in the video." if not t["step_off_observed"] else ""
        tl = fig(f"trial{n}_timeline.jpg")
        out.append(
            f"<h3>Trial {n}</h3>"
            + (f"<figure><img class='fig' src='{tl}' alt='Trial {n} video frames at each event'>"
               f"<figcaption>Trial {n}: the video frame at each force event, joined to its time on the force trace. "
               f"Contact and take-off frames are the first frame at or after the event. Teal lines: the ASIS-knee and "
               f"knee-ankle lines of the knee FPPA, with the ASIS marker (yellow dot) and the angle (valgus +).{note}"
               f"</figcaption></figure>" if tl else "")
            + f"<figure><img class='fig' src='{fig(f'trial{n}_panel.png')}' alt='Trial {n} signals'>"
            f"<figcaption>Trial {n} signals, on scales shared by all trials. Red dashed: TD1, TO2, TD2, end of quiet "
            f"stance. Green dotted: lowest COM. COP is shown minus its own mean.</figcaption></figure>")
    return "".join(out)


def _tts_table(res):
    from .report_extra import TTS_ROWS, key_rows
    return _metric_table(pd.DataFrame(key_rows(res, TTS_ROWS, "tts")), "tts")


def build_html(res, ser, tables_, out_dir) -> str:
    import plotly.offline as po
    tpl = open(os.path.join(os.path.dirname(__file__), "report_template.html")).read()

    def fig(name):
        p = os.path.join(out_dir, "figures", name)
        return _img(p) if os.path.exists(p) else ""
    from .report_extra import COCON_ROWS, ENTROPY_ROWS, SUMMARY_KEY, ZONE_ROWS, key_rows
    from .manifest import EXTRA_REFS
    vid = res.get("video") or {}
    mp4 = os.path.join(out_dir, vid["mp4"]) if vid.get("mp4") else None
    video_src = ("data:video/mp4;base64," + base64.b64encode(open(mp4, "rb").read()).decode()) if mp4 else ""
    df = tables_["metrics_by_trial"]
    review_t = {k: _metric_table(pd.DataFrame(key_rows(res, rows, k)), k)
                for k, rows in (("ent", ENTROPY_ROWS), ("zone", ZONE_ROWS), ("cocon", COCON_ROWS), ("key", SUMMARY_KEY))}
    qz = res.get("cop_quiet_zone") or {}
    bw = res["body_weight"]
    T = res["trials"]
    qc = res["qc"]
    g = lambda p, sc=1: _vals(res, p, sc)
    mean = lambda p, sc=1: float(np.nanmean(g(p, sc)))
    cards = [("Jump height (flight time)", f"{mean((R, 'jump_height_ft_m'), 100):.1f} cm"),
             ("Contact time", f"{mean((R, 'contact_time_s'), 1000):.0f} ms"),
             ("RSI", f"{mean((R, 'rsi_m_s')):.2f} m/s"),
             ("Landing first peak", f"{mean((L, 'td2_first_peak_BW')):.2f} BW"),
             (f"DPSI ({res['common_window_s']:.1f} s)", f"{mean(('dpsi_common', 'DPSI')):.3f}"),
             ("N2 recovery τ", f"{mean(('novel_tdpsi', 'tau_s'), 1000):.0f} ms")]
    card_html = "".join(f"<div class='card'><div class='cv'>{H.escape(v)}</div><div class='cl'>{H.escape(k)}</div></div>"
                        for k, v in cards)
    tare_max = max(abs(v["diff_N"]) for v in qc["lab_tare_check_record1"].values())
    td = qc["trigno_delay"]
    sens = pd.DataFrame(qc["threshold_sensitivity"])
    s5, s50 = sens[sens.threshold_N == 5].set_index("trial"), sens[sens.threshold_N == 50].set_index("trial")
    dct, dft = (s50.contact_ms - s5.contact_ms).values, (s50.flight_ms - s5.flight_ms).values
    lg = tables_["legacy_vs_v2"]
    ev_bias = lg[lg["legacy output"].str.contains("legacy minus")]["legacy mean"].values if len(lg) else []
    pick = lambda name: lg[lg["legacy output"] == name]
    bias = lambda name: (100 * (pick(name)["legacy mean"].values[0] / pick(name)["v2 mean"].values[0] - 1)) if len(pick(name)) else np.nan
    n1 = [t["novel_xcom"] for t in T if t.get("novel_xcom")]
    n1w = [d["window_s"][1] - d["window_s"][0] for d in n1]
    tl_rows = [r for rows in (vid.get("timeline_frames") or {}).values() for r in rows]
    tl_gaps = [r["gap_ms"] for r in tl_rows if r["event"] in ("td1", "td2")]
    to_gaps = [r["gap_ms"] for r in tl_rows if r["event"] == "to2"]
    clip = [t["emg"]["EMG2"][ev]["clipped_pct_window"] for t in T for ev in ("td1", "td2")]
    imq = g(("impulse_momentum", "jump_height_im_quiet_bw_m"), 100)
    dv = g(("impulse_momentum", "dv_per_pct_bw_m_s"))
    leg_tts = tables_.get("legacy_tts_max_s", float("nan"))
    bw_rows = "".join(
        f"<tr><td>{b['trial']}</td><td class='num'>{_fmt(b['bw_joint_N'], 1)}</td><td class='num'>{_fmt(b['bw_quiet_N'], 1)}</td>"
        f"<td class='num'>{_fmt(b['quiet_sd_N'], 1)}</td></tr>" for b in bw["per_trial"])
    names = {"v_touchdown1_m_s": "COM velocity at TD1", "effective_drop_height_m": "effective drop height",
             "com_depression_m": "COM lowering, contact 1", "vertical_stiffness_BW_m": "vertical stiffness",
             "braking_time_s": "braking phase", "time_to_lowest_com_s": "time to lowest COM, landing",
             "landing_com_depression_m": "COM lowering, landing", "landing_stiffness_BW_m": "landing stiffness"}
    bws = [{"measure": names.get(k, k), "change": 100 * (d["quiet"] / d["joint"] - 1) if d["joint"] else np.nan}
           for t in T for k, d in t["bw_sensitivity"].items()]
    agg = pd.DataFrame(bws).groupby("measure", sort=False)["change"].agg(["min", "max"]).reset_index()
    bwsd = pd.DataFrame({"measure (quiet BW instead of joint BW)": agg["measure"],
                         "change across trials, %": [f"{a:+.1f} to {b:+.1f}" for a, b in zip(agg["min"], agg["max"])]})
    er = vid.get("event_refinement") or {}
    cen = []
    for t in T:
        c = t["cop"]["td2_dynamic_0.4s_to_end"]
        a, b = t["cop_windows_idx"]["td2_dynamic_0.4s_to_end"]
        cen.append((np.nanmean(ser["cop_ap"][a:b]), np.nanmean(ser["cop_ml"][a:b])))
    place = []
    for t, (ap_, ml_) in list(zip(T, cen))[1:]:
        dap, dml = ap_ - cen[0][0], ml_ - cen[0][1]
        place.append(f"Trial {t['number']} stood {abs(dap)/10:.0f} cm {'further forward' if dap > 0 else 'further back'} "
                     f"and {abs(dml)/10:.0f} cm {'more lateral (right)' if dml > 0 else 'more medial (left)'} than trial 1")
    place_note = (". ".join(place) + ". The video shows the same shifts.") if place else ""
    rep = {
        "%%PLOTLY%%": po.get_plotlyjs(), "%%DATA%%": _series_json(res, ser), "%%VIDEO%%": video_src,
        "%%CARDS%%": card_html, "%%FINDINGS%%": findings(res), "%%PLACENOTE%%": place_note,
        "%%HEXT%%": (lambda e: f"{e[1]-e[0]:.0f} &times; {e[3]-e[2]:.0f}")(res["heatmaps"]["standardised"]["extent_mm"]),
        "%%HBIN%%": f"{res['heatmaps']['standardised']['bin_mm']:g}",
        "%%BW%%": f"{bw['session_bw_N']:.1f}", "%%MASS%%": f"{bw['session_mass_kg']:.1f}",
        "%%BWQ%%": f"{bw['session_bw_quiet_N']:.1f}", "%%BWROWS%%": bw_rows,
        "%%T_BWSENS%%": _simple_table(bwsd),
        "%%NTRIALS%%": str(len(T)), "%%START%%": res["meta"]["record_start_utc"][:19].replace("T", " ") + " UTC",
        "%%OFFSET%%": f"{vid.get('offset_s', float('nan')):.3f}",
        "%%XOFF%%": f"{vid.get('xcorr_offset_s', float('nan')):.3f}",
        "%%XCI%%": "-".join(f"{x:.3f}" for x in vid.get("xcorr_ci95_s", [np.nan, np.nan])),
        "%%FEAS%%": "-".join(f"{x:.3f}" for x in er.get("feasible_s", [np.nan, np.nan])),
        "%%NSAT%%": f"{er.get('n_satisfied', 0)} of {er.get('n_constraints', 0)}",
        "%%NFR%%": str(vid.get("n_frames", 0)), "%%FPS%%": f"{vid.get('mean_fps', 0):.1f}",
        "%%FRMED%%": f"{vid.get('median_interval_ms', 0):.0f}", "%%FRMAX%%": f"{vid.get('max_interval_ms', 0):.0f}",
        "%%TLGAP%%": f"+{min(tl_gaps):.0f} to +{max(tl_gaps):.0f}" if tl_gaps else "-",
        "%%TOGAP%%": f"+{min(to_gaps):.0f} to +{max(to_gaps):.0f}" if to_gaps else "-",
        "%%EMG2WIN%%": f"{max(clip):.0f}", "%%IMQ%%": _rng(imq, 1), "%%DVBW%%": f"{np.nanmin(dv):.2f}-{np.nanmax(dv):.2f}",
        "%%LEGTTS%%": f"{leg_tts:.0f}", "%%PREPARED%%": "Prepared 21 October 2026 by Himanshu Sangale with Jump Utility",
        "%%TAREMAX%%": f"{tare_max:.3f}", "%%DRIFTMAX%%": f"{max(qc['plate']['drift_N'].values()):.1f}",
        "%%FZBASE%%": f"{qc['plate']['fz_baseline_range_N']:.2f}",
        "%%NOISE%%": f"{qc['plate']['noise_sd_N']:.2f}", "%%PKRES%%": f"{qc['plate']['pkres_N']:.2f}",
        "%%THR%%": f"{qc['detection']['threshold_N']:.1f}", "%%THRBY%%": qc["detection"]["threshold_set_by"],
        "%%COPMIN%%": f"{qc['plate']['cop_min_N']:.0f}",
        "%%DCT%%": f"{dct.min():.0f} to {dct.max():.0f}", "%%DFT%%": f"+{dft.min():.0f} to +{dft.max():.0f}",
        "%%DELAY1%%": f"{td['ACC1']['record_lag_s']*1000:.0f}", "%%DELAY1E%%": f"{td['ACC1']['median_event_lag_s']*1000:.0f}",
        "%%DELAY2%%": f"{td['ACC2']['record_lag_s']*1000:.0f}", "%%DELAYAPP%%": f"{td['applied_s']*1000:.0f}",
        "%%LAGRANGE%%": f"{td['per_event_range_s'][0]*1000:.0f}-{td['per_event_range_s'][1]*1000:.0f}",
        "%%EMG2CLIP%%": f"{qc['emg_clipping_pct']['EMG2']:.2f}", "%%EMG1CLIP%%": f"{qc['emg_clipping_pct']['EMG1']:.2f}",
        "%%GRAV1%%": f"{qc['acc_gravity']['ACC1']['mean_g']:.2f}", "%%GRAV2%%": f"{qc['acc_gravity']['ACC2']['mean_g']:.2f}",
        "%%POSERATE%%": f"{100*vid.get('pose_detect_rate', float('nan')):.0f}",
        "%%ASISRATE%%": f"{100*vid.get('asis_detect_rate_used', float('nan')):.0f}",
        "%%EVBIAS%%": ", ".join(f"{abs(x):.0f}" for x in ev_bias),
        "%%JHBIAS%%": f"{abs(bias('jump height')):.0f}", "%%RSIBIAS%%": f"{abs(bias('RSI')):.0f}",
        "%%N1WIN%%": f"{min(n1w):.1f}-{max(n1w):.1f}" if n1w else "-",
        "%%STANCE%%": _rng(g((L, "quiet_stance_s")), 1), "%%COMMON%%": f"{res['common_window_s']:.1f}",
        "%%T_REBOUND%%": _metric_table(df, "rebound"), "%%T_LANDING%%": _metric_table(df, "landing"),
        "%%T_STAB%%": _metric_table(df, "stability"),
        "%%T_TTS%%": _tts_table(res), "%%T_EMG1%%": _metric_table(df, "emg_EMG1"),
        "%%T_EMG2%%": _metric_table(df, "emg_EMG2"), "%%T_KIN%%": _metric_table(df, "kin"),
        "%%T_N1%%": _metric_table(df, "n1"), "%%T_N2%%": _metric_table(df, "n2"),
        "%%T_COP%%": _simple_table(tables_["cop_summary"]),
        "%%T_EVENTS%%": _simple_table(tables_["events"], {c: 3 for c in tables_["events"].columns}),
        "%%T_SENS%%": _simple_table(tables_["threshold_sensitivity"], {c: 0 for c in tables_["threshold_sensitivity"].columns}),
        "%%T_LEGACY%%": _simple_table(_legacy_display(lg)),
        "%%T_ALL%%": _simple_table(tables_["all_values"], cls="metrics small"),
        "%%TRIALS%%": _trial_blocks(res, fig),
        "%%F_OVERVIEW%%": fig("overview_force.png"), "%%F_HEAT%%": fig("cop_heatmaps_standardised.png"),
        "%%F_PLACE%%": fig("cop_paths_plate.png"), "%%F_N1%%": fig("novel_n1_xcom.png"),
        "%%F_N2%%": fig("novel_n2_stabilisation.png"), "%%F_SYNC%%": fig("sync.png"),
        "%%REFS%%": "".join(f"<li>{H.escape(r)}</li>" for r in sorted(REFERENCES + [
            r for r in EXTRA_REFS if r.startswith(("Richman", "Ramdani", "Falconer"))])),
        "%%T_ENTROPY%%": review_t["ent"], "%%T_ZONE%%": review_t["zone"], "%%T_COCON%%": review_t["cocon"],
        "%%T_SENS9%%": sensitivity_tables(res), "%%T_KEY%%": review_t["key"], "%%F_ZONE%%": fig("cop_zone_heatmaps.png"),
        "%%F_ENTROPY%%": fig("res_cop_entropy.png"), "%%F_COCON%%": fig("res_cocontraction.png"),
        "%%F_CONTACT%%": fig("res_contact_overlay.png"), "%%F_LOOPS%%": fig("res_force_com_loops.png"),
        "%%ZAREA%%": f"{qz.get('area_mm2', float('nan')):.0f}",
        "%%VERSION%%": res["meta"]["jumpkit_version"], **session_fields(res),
    }
    tpl = video_blocks(tpl, bool(vid))
    for k, v in rep.items():
        tpl = tpl.replace(k, v)
    return tpl


def print_pdf(html_path: str, pdf_path: str, view: str = "") -> str:
    """Print with headless Chrome. view sets the page's #fragment (for example 'summary' or 'detailed')."""
    chrome = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
    if not os.path.exists(chrome):
        return ""
    subprocess.run([chrome, "--headless=new", "--disable-gpu", "--no-pdf-header-footer",
                    "--virtual-time-budget=30000", f"--print-to-pdf={pdf_path}",
                    "file://" + html_path + (f"#{view}" if view else "")],
                   check=True, capture_output=True, timeout=300)
    return pdf_path
