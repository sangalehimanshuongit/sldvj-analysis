"""Clock alignment between the PowerLab (force) and Trigno (EMG, accelerometer) streams.

The Trigno samples reach LabChart late. Delsys documents a fixed 48 ms delay for the
legacy Trigno. Here the delay is measured from the data: the accelerometer jerk
(sum of |da/dt| over 3 axes) is cross-correlated with |dFz/dt|, over the whole record and
around each touchdown. A positive lag means the Trigno signal arrives late.
"""
from __future__ import annotations

import numpy as np

from .signals import lowpass


def _xcorr_lag(sig_t, sig, ref_t, ref, lags, grid):
    out = []
    rr = np.interp(grid, ref_t, ref)
    rr = (rr - rr.mean()) / rr.std()
    for L in lags:
        s = np.interp(grid, sig_t - L, sig)
        s = (s - s.mean()) / s.std()
        out.append(float(np.mean(s * rr)))
    return np.array(out)


def trigno_delay(acc_axes: list, fa: float, Fz: np.ndarray, fs: float, td_idx: list,
                 lags=np.arange(-0.2, 0.3, 0.002)) -> dict:
    ta = np.arange(len(acc_axes[0])) / fa
    t = np.arange(Fz.size) / fs
    jerk = sum(np.abs(np.gradient(a, 1 / fa)) for a in acc_axes)
    dF = np.abs(np.gradient(lowpass(Fz, fs, 30.0), 1 / fs))
    grid = np.arange(0, t[-1], 0.001)
    c = _xcorr_lag(ta, jerk, t, dF, lags, grid)
    i = int(np.argmax(c))
    per = []
    for ev in td_idx:
        m = (grid > ev / fs - 0.25) & (grid < ev / fs + 0.35)
        b = np.interp(grid[m], t, dF)
        best = max(((np.corrcoef(np.interp(grid[m], ta - L, jerk), b)[0, 1], L) for L in lags))
        per.append({"t_s": ev / fs, "lag_s": float(best[1]), "r": float(best[0])})
    return {"record_lag_s": float(lags[i]), "record_r": float(c[i]), "lags_s": lags, "r": c,
            "per_event": per, "median_event_lag_s": float(np.median([p["lag_s"] for p in per]))}
