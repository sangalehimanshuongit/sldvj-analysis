"""Pure-Python reader for ADInstruments LabChart ``.adicht`` files.

LabChart files are normally read with the ADInstruments SDK, which is a Windows DLL.
This reader needs only numpy, so it runs on macOS and Linux. The format was worked out
from a LabChart 8 file (PowerLab 8/35 + Delsys Trigno through the SDA device) and is
checked against the lab's own tare values. See ``docs/adicht_format.md``.

Container
    512-byte file header, then sectors of 2**shift bytes, where shift is the uint32 at
    header byte 152 (10 = 1 KB in sdvj_1234_AB.adicht, 12 = 4 KB in the static-balance
    file). Sector k starts at 0x200 + (k - 2) * sector size.
    A directory block is int32 n, int32 -n, then n entries of 160 bytes:
    UTF-16 name (72 bytes), uint64 first sector, uint64 size in bytes, uint64 last sector.
    Streams need not sit in consecutive sectors. A chain table, which starts at the sector
    named by the uint32 at header byte 172, holds one (next, previous) uint32 pair per
    sector (next = 0 ends a chain). The table is itself a chain.

Samples ("Blocks_0")
    A chain of blocks: uint32 length L, then L bytes: uint32 checksum (0 if compressed),
    int32 -L, uint32 codec, payload.
    codec 0x104       uint32 uncompressed size, then PackBits run-length data. It expands to
                      17 bit planes (LSB first), each padded to 4 bytes. Bit k of sample i
                      is bit i of plane k. Plane values are first differences of the int16
                      samples, with the sign in bit 0 (the first value is absolute).
    codec 0x80000100  raw little-endian int16 samples.

Index ("Map")
    For every record and channel, one entry per block:
    uint32 n_samples, uint32 0, float32 min, float32 max, uint64 byte offset in Blocks_0.
    An entry followed by 01 00 02 80 continues the same channel. Otherwise it closes the
    channel. A closed channel (except the last) is followed by the marker
    1b 80 03 00 00 00 and its 1-based channel number. Each record header holds the
    tick rate (uint32), 4 zero bytes, the start time (float64 Unix seconds, local clock)
    and UTC minus local time (float64 seconds; -7200 for UTC+2).

Comments ("Map")
    Each LabChart comment sits after its record's header: uint32 2, uint32 0, uint32 comment
    number, uint32 position in ticks as 16.16 fixed point, the marker 01 00 00 80, int32 L,
    int32 -L, then L UTF-16 characters (the last is a null). Channel titles and units use the
    same string marker, so the 2, 0 prefix and the number are what identify a comment. Checked on the static-balance file: in 8 of
    10 trials the recording stops 29.9-31.3 s after the comment, as in a 30 s timed trial.
"""
from __future__ import annotations

import struct
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

import numpy as np

SECTOR0 = 0x200
SECTOR = 0x400                  # default when the header holds no usable shift


def sector_size(buf: bytes) -> int:
    """Sector size in bytes, from the shift stored at header byte 152."""
    shift = struct.unpack_from("<I", buf, 152)[0]
    return 1 << shift if 9 <= shift <= 16 else SECTOR
CODEC_PACKED = 0x104
CODEC_RAW = 0x80000100
CONTINUE = b"\x01\x00\x02\x80"
CHANNEL_MARK = b"\x1b\x80\x03\x00\x00\x00"


@dataclass
class Channel:
    number: int                 # 1-based, as in LabChart
    fs: float                   # samples per second
    counts: np.ndarray          # int16 samples
    block_offsets: list = field(default_factory=list)


@dataclass
class Record:
    number: int
    tick_rate: float
    start_unix_local: float
    utc_minus_local_s: float
    channels: dict = field(default_factory=dict)
    warnings: list = field(default_factory=list)
    comments: list = field(default_factory=list)   # (time in s from record start, text)

    @property
    def start_utc(self) -> datetime:
        """Record start in UTC (the stored clock is local time)."""
        local = datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(seconds=self.start_unix_local)
        return local + timedelta(seconds=self.utc_minus_local_s)


def _sector(buf: bytes, k: int) -> bytes:
    ss = sector_size(buf)
    off = SECTOR0 + (k - 2) * ss
    return buf[off:off + ss]


def chain_table(buf: bytes) -> bytes:
    """The (next, previous) table, read by following its own chain from header byte 172."""
    start = struct.unpack_from("<I", buf, 172)[0]
    ss = sector_size(buf)
    nsec = (len(buf) - SECTOR0) // ss + 2
    need = -(-(nsec * 8) // ss)
    # bootstrap: assume the table is contiguous, then confirm with its own chain
    guess = b"".join(_sector(buf, start + i) for i in range(need))
    chain = [start]
    while len(chain) < need:
        nxt = struct.unpack_from("<I", guess, 8 * chain[-1])[0] if 8 * chain[-1] + 8 <= len(guess) else 0
        if nxt == 0:
            break
        chain.append(nxt)
    if chain != list(range(start, start + len(chain))):
        guess = b"".join(_sector(buf, k) for k in chain)
    return guess


def _stream(buf: bytes, first_sector: int, size: int, table: bytes | None = None) -> bytes:
    """Read a stream by following its sector chain."""
    need = -(-size // sector_size(buf))
    if table is None:
        table = chain_table(buf)
    chain = [first_sector]
    while len(chain) < need:
        if 8 * chain[-1] + 8 > len(table):
            raise ValueError("sector chain points outside the chain table")
        nxt = struct.unpack_from("<I", table, 8 * chain[-1])[0]
        if nxt == 0:
            raise ValueError(f"sector chain from {first_sector} ends after {len(chain)} of {need} sectors")
        chain.append(nxt)
    return b"".join(_sector(buf, k) for k in chain)[:size]


def directory(buf: bytes) -> dict:
    """Return {stream name: [(first_sector, size, last_sector), ...]}."""
    out: dict = {}
    ss = sector_size(buf)
    nsec = (len(buf) - SECTOR0) // ss
    for k in range(2, nsec + 2):
        off = SECTOR0 + (k - 2) * ss
        if off + 8 > len(buf):
            break
        cnt, neg = struct.unpack_from("<ii", buf, off)
        if not (0 < cnt <= ss // 160 and neg == -cnt):
            continue
        for e in range(cnt):
            eo = off + 8 + e * 160
            name = buf[eo:eo + 72].decode("utf-16le", errors="ignore").split("\x00")[0]
            first, size, last = struct.unpack_from("<QQQ", buf, eo + 72)
            if name:
                out.setdefault(name, []).append((first, size, last))
    return out


def unpackbits(p: bytes) -> bytes:
    """Expand PackBits run-length data."""
    out = bytearray()
    i, n_p = 0, len(p)
    while i < n_p:
        n = p[i]
        i += 1
        if n < 128:
            out += p[i:i + n + 1]
            i += n + 1
        elif n > 128:
            out += bytes([p[i]]) * (257 - n)
            i += 1
    return bytes(out)


def decode_planes(payload: bytes, nbytes: int) -> np.ndarray:
    """Decode a codec-0x104 payload into int16 samples."""
    n = nbytes // 2
    if n == 0:
        return np.zeros(0, np.int16)
    u = np.frombuffer(unpackbits(payload), dtype=np.uint8)
    if u.size % 17:
        raise ValueError("bit-plane data is not a multiple of 17 planes")
    planes = u.reshape(17, u.size // 17)
    if planes.shape[1] * 8 < n:
        raise ValueError("bit planes are shorter than the stated sample count")
    bits = np.unpackbits(planes, axis=1, bitorder="little")[:, :n].astype(np.int64)
    v = np.zeros(n, dtype=np.int64)
    for k in range(17):
        v |= bits[k] << k
    d = np.where(v & 1, -(v >> 1), v >> 1)
    x = np.cumsum(d)
    if x.min() < -32768 or x.max() > 32767:
        raise ValueError("decoded samples overflow int16; decoder assumptions failed")
    return x.astype(np.int16)


def read_blocks(buf: bytes, d: dict, table: bytes | None = None) -> dict:
    """Return {byte offset in Blocks_0: int16 samples} for every block."""
    first, size, _ = d["Blocks_0"][0]
    blk = _stream(buf, first, size, table)
    o, out = 4, {}
    while o + 16 <= len(blk):
        ln, _chk, neg, codec = struct.unpack_from("<IIiI", blk, o)
        if ln == 0:                      # zero padding after the last block
            break
        if neg != -ln:
            raise ValueError(f"block chain broken at byte {o}")
        if codec == CODEC_PACKED:
            nbytes = struct.unpack_from("<I", blk, o + 16)[0]
            out[o] = decode_planes(blk[o + 20:o + 4 + ln], nbytes)
        elif codec == CODEC_RAW:
            out[o] = np.frombuffer(blk[o + 16:o + 4 + ln], dtype="<i2").copy()
        else:
            raise ValueError(f"unknown codec {codec:#x} at byte {o}")
        o += 4 + ln
    return out


def _record_headers(m: bytes) -> list:
    """Find (position, tick_rate, start_unix_local, utc_minus_local_s) record headers in Map."""
    heads = []
    for i in range(0, len(m) - 23):
        tick, zero = struct.unpack_from("<II", m, i)
        if zero or not (1 <= tick <= 1_000_000):
            continue
        t0, tz = struct.unpack_from("<dd", m, i + 8)
        if 1e9 < t0 < 4e9 and -86400 <= tz <= 86400 and float(tz).is_integer():
            heads.append((i, float(tick), t0, tz))
    return heads


COMMENT_MARK = b"\x01\x00\x00\x80"
COMMENT_PREFIX = b"\x02\x00\x00\x00\x00\x00\x00\x00"


def _comments(m: bytes) -> list:
    """Find (Map position, comment number, position in ticks, text) for every comment."""
    out = []
    i = m.find(COMMENT_MARK, 8)
    while i >= 0:
        if i + 12 <= len(m):
            n, neg = struct.unpack_from("<ii", m, i + 4)
            if 1 < n <= 512 and neg == -n and i + 12 + 2 * n <= len(m):
                raw = m[i + 12:i + 12 + 2 * n]
                text = raw.decode("utf-16le", errors="replace").rstrip("\x00")
                number, pos = struct.unpack_from("<II", m, i - 8)
                if (m[i - 16:i - 8] == COMMENT_PREFIX and number >= 1 and raw[-2:] == b"\x00\x00"
                        and text and text.isprintable()):
                    out.append((i, number, round(pos / 65536.0), text))
        i = m.find(COMMENT_MARK, i + 1)
    return out


def read_adicht(path: str) -> list[Record]:
    """Read every record and channel of a LabChart file as raw int16 counts."""
    buf = open(path, "rb").read()
    d = directory(buf)
    table = chain_table(buf)
    blocks = read_blocks(buf, d, table)
    m = _stream(buf, *d["Map"][0][:2], table)
    heads = _record_headers(m)

    # Block index entries, in file order. An entry must match a real block's offset,
    # sample count, minimum and maximum, so a chance byte pattern cannot pass.
    entries = []
    for i in range(len(m) - 23):
        n, z = struct.unpack_from("<II", m, i)
        if z or n == 0:
            continue
        off = struct.unpack_from("<Q", m, i + 16)[0]
        x = blocks.get(off)
        if x is None or len(x) != n:
            continue
        mn, mx = struct.unpack_from("<ff", m, i + 8)
        if mn == float(x.min()) and mx == float(x.max()):
            entries.append((i, off))
    if len(entries) != len(blocks):
        raise ValueError(f"index lists {len(entries)} blocks but Blocks_0 holds {len(blocks)}")

    # Group entries into channels, and channels into records.
    marks = []
    for i, off in entries:
        tail = m[i + 24:i + 48]
        cont = tail.startswith(CONTINUE)
        ch = None
        if not cont:
            j = 3 if tail[3:9] == CHANNEL_MARK else tail.find(CHANNEL_MARK)
            if j >= 0:
                ch = struct.unpack_from("<I", tail, j + 6)[0]
        marks.append((i, off, cont, ch))
    known = [c for *_, c in marks if c is not None]
    nchan = (max(known) + 1) if known else 1

    records, cur, chan_blocks, ch_no = [], None, [], 1
    head_pos = [h[0] for h in heads]
    for i, off, cont, ch in marks:
        # a record header between the previous entry and this one starts a new record, even
        # if the previous record lacked trailing channels
        if cur is not None and not chan_blocks and any(cur_pos < hp < i for hp in head_pos):
            cur.warnings.append(f"record ended after channel {max(cur.channels)} of {nchan}")
            records.append(cur)
            cur, ch_no = None, 1
        cur_pos = i
        if cur is None:
            prior = [h for h in heads if h[0] < i]
            h = prior[-1] if prior else (0, 1.0, float("nan"), 0.0)
            cur = Record(number=len(records) + 1, tick_rate=h[1], start_unix_local=h[2],
                         utc_minus_local_s=h[3])
        chan_blocks.append(off)
        if cont:
            continue
        number = ch if ch is not None else ch_no
        cur.channels[number] = Channel(number=number, fs=float("nan"),
                                       counts=np.concatenate([blocks[o] for o in chan_blocks]),
                                       block_offsets=list(chan_blocks))
        chan_blocks, ch_no = [], number + 1
        if number == nchan:
            records.append(cur)
            cur, ch_no = None, 1
    if cur is not None and cur.channels:          # a record with missing trailing channels
        cur.warnings.append(f"record ended after channel {max(cur.channels)} of {nchan}")
        records.append(cur)
    if chan_blocks:
        raise ValueError("index ends inside a channel's block list")

    # Sample rates. The fastest channel runs at the tick rate; another channel's rate is
    # tick_rate * n_channel / n_fastest, taken from the longest record that holds it
    # (whole-sample rounding matters least there). Each record is checked against it.
    for k in {k for r in records for k in r.channels}:
        holders = [r for r in records if k in r.channels]
        ref = max(holders, key=lambda r: max(len(c.counts) for c in r.channels.values()))
        ratio = max(len(c.counts) for c in ref.channels.values()) / len(ref.channels[k].counts)
        for r in holders:
            c = r.channels[k]
            c.fs = r.tick_rate / ratio
            nfast = max(len(x.counts) for x in r.channels.values())
            if abs(len(c.counts) - nfast / ratio) > 1.5:
                r.warnings.append(f"channel {k}: {len(c.counts)} samples, expected {nfast / ratio:.1f}")

    # Comments belong to the record whose header comes last before them.
    if len(heads) == len(records):
        for pos, _number, ticks, text in _comments(m):
            prior = [k for k, h in enumerate(heads) if h[0] < pos]
            if prior:
                r = records[prior[-1]]
                n_ticks = max(len(c.counts) for c in r.channels.values())
                if ticks <= n_ticks:
                    r.comments.append((ticks / r.tick_rate, text))
    elif _comments(m):
        records[0].warnings.append("comments not assigned: record headers and records differ in number")
    return records
