"""Post-landing stability: DPSI, time to stabilisation (TTS) and COP measures.

Windows run from the second touchdown (TD2) to the end of quiet stance (stance_end),
which comes before the step-off. Classic methods assume 3 s (DPSI) and at least 10-20 s
(TTS) of stance (Wikstrom et al. 2005; Ross et al. 2005; Fransz et al. 2015). These trials
have about 2.6-2.8 s, so every result records the window it used, and the TTS values are
short-stance adaptations, not the published protocol.
"""
from __future__ import annotations

import numpy as np

from .signals import bouts, ellipse95, lowpass, nanpath

TTS_K = {"V": 30.0, "AP": 15.0, "ML": 7.0}     # Fransz et al. 2016 minimum thresholds x SD_stable


def stance_end(Fz: np.ndarray, fs: float, td2: int, off: int, bw: float,
               band_frac: float = 0.05, hold_s: float = 0.10) -> int:
    """Last sample before the step-off at which Fz has been within BW +/- band for hold_s."""
    band = np.abs(Fz - bw) < band_frac * bw
    h = int(round(hold_s * fs))
    k = off - 1
    while k > td2 + h and not band[k - h:k].all():
        k -= 1
    return k


def dpsi(Fap, Fml, Fz, fs, td2, end, bw, dur_s=3.0, fc=20.0) -> dict:
    """Dynamic postural stability index (Wikstrom et al. 2005) and its components.

    APSI = sqrt(sum(0 - Fap)^2 / n) / BW, MLSI likewise, VSI = sqrt(sum(BW - Fz)^2 / n) / BW,
    DPSI = sqrt((sum Fap^2 + sum Fml^2 + sum (BW - Fz)^2) / n) / BW, over dur_s after
    touchdown, forces low-passed at fc (20 Hz, 4th order, zero lag; Ota et al. 2022).
    """
    e = min(td2 + int(round(dur_s * fs)), end)
    s = slice(td2, e)
    ap, ml, fz = (lowpass(x, fs, fc)[s] for x in (Fap, Fml, Fz))
    v = bw - fz
    n = e - td2
    return {"window_s": n / fs, "full_3s_window": n >= int(round(dur_s * fs)),
            "APSI": float(np.sqrt(np.sum(ap ** 2) / n) / bw),
            "MLSI": float(np.sqrt(np.sum(ml ** 2) / n) / bw),
            "VSI": float(np.sqrt(np.sum(v ** 2) / n) / bw),
            "DPSI": float(np.sqrt((np.sum(ml ** 2) + np.sum(ap ** 2) + np.sum(v ** 2)) / n) / bw)}


def _stays(inside: np.ndarray, fs: float) -> float:
    """Time (s) after which inside stays True to the end; NaN if it never settles."""
    bad = np.where(~inside)[0]
    if bad.size == 0:
        return 0.0
    return (bad[-1] + 1) / fs if bad[-1] + 1 < inside.size else float("nan")


def tts_sequential(x: np.ndarray, fs: float, k_sd: float = 0.25) -> float:
    """Sequential-average TTS (Colby et al. 1999): the running mean of x (from touchdown)
    stays within mean(x) +/- k_sd * SD(x), both taken over the whole window."""
    run = np.cumsum(x) / np.arange(1, x.size + 1)
    return _stays(np.abs(run - x.mean()) <= k_sd * x.std(), fs)


def tts_polynomial(x: np.ndarray, fs: float, stable: np.ndarray, k: float) -> dict:
    """Unbounded third-order polynomial TTS (Ross & Guskiewicz 2004; Ross et al. 2005).

    x is rectified about the stable-phase mean, a cubic is fitted from the rectified peak to
    the end of the window, and TTS is where the cubic first falls to the threshold
    k * SD(stable) (Fransz et al. 2016 minimum k: V 30, AP 15, ML 7).
    """
    r = np.abs(x - stable.mean())
    thr = k * float(stable.std())
    i0 = int(np.argmax(r[: int(0.3 * fs)]))
    t = np.arange(r.size) / fs
    c = np.polyfit(t[i0:], r[i0:], 3)
    fit = np.polyval(c, t[i0:])
    if r.max() <= thr or fit[0] <= thr:
        # the threshold is at or above the landing response itself: TTS is undefined
        return {"tts_s": float("nan"), "threshold": thr, "coef": c.tolist(), "i0": i0,
                "flag": "threshold not exceeded by the landing response"}
    below = np.where(fit <= thr)[0]
    return {"tts_s": float(t[i0 + below[0]]) if below.size else float("nan"),
            "threshold": thr, "coef": c.tolist(), "i0": i0, "flag": ""}


def tts_raw_vertical(Fz: np.ndarray, fs: float, bw: float, frac: float = 0.05) -> float:
    """Raw vertical TTS: time after which unfiltered Fz stays within BW +/- 5% (Colby et al. 1999)."""
    return _stays(np.abs(Fz - bw) <= frac * bw, fs)


def tts_all(Fap, Fml, Fz, fs, td2, end, bw, stable_s=1.0, fc=20.0) -> dict:
    """All TTS variants over [td2, end). Use the same window length for every trial:
    the sequential average converges by construction, so it depends on window length."""
    s = slice(td2, end)
    comp = {"V": lowpass(Fz, fs, fc)[s], "AP": lowpass(Fap, fs, fc)[s], "ML": lowpass(Fml, fs, fc)[s]}
    w = int(round(stable_s * fs))
    out = {"window_s": (end - td2) / fs, "stable_window_s": stable_s}
    for k, x in comp.items():
        stable = x[-w:]
        out[f"tts_sa_{k}_s"] = tts_sequential(x, fs)
        top = tts_polynomial(x, fs, stable, TTS_K[k])
        out[f"tts_top_{k}_s"] = top["tts_s"]
        out[f"tts_top_{k}_flag"] = top["flag"]
    out["tts_raw_V_s"] = tts_raw_vertical(Fz[s], fs, bw)
    for m in ("sa", "top"):
        v = [out[f"tts_{m}_{k}_s"] for k in ("AP", "ML", "V")]
        out[f"rv_tts_{m}_s"] = float(np.sqrt(np.sum(np.square(v)))) if np.all(np.isfinite(v)) else float("nan")
    return out


def cop_window(ml_mm: np.ndarray, ap_mm: np.ndarray, fs: float) -> dict:
    """COP measures over one window; NaN samples (invalid COP) are left out and counted."""
    ok = np.isfinite(ml_mm) & np.isfinite(ap_mm)
    if ok.sum() < 5:
        return {"coverage_pct": 100 * ok.mean() if ok.size else 0.0}
    ml, ap = ml_mm[ok], ap_mm[ok]
    dur = ok.sum() / fs
    path = nanpath(ml_mm, ap_mm)
    e = ellipse95(ml, ap)
    return {"duration_s": dur, "coverage_pct": 100 * ok.mean(), "path_mm": path,
            "mean_velocity_mm_s": path / dur,
            "ap_range_mm": float(np.ptp(ap)), "ml_range_mm": float(np.ptp(ml)),
            "ap_sd_mm": float(np.std(ap)), "ml_sd_mm": float(np.std(ml)),
            "rms_distance_mm": float(np.sqrt(np.mean((ap - ap.mean()) ** 2 + (ml - ml.mean()) ** 2))),
            "ellipse95_area_mm2": e["area_mm2"],
            "net_displacement_mm": float(np.hypot(ap[-1] - ap[0], ml[-1] - ml[0]))}


def cop_smooth(c: np.ndarray, fs: float, fc: float = 20.0) -> np.ndarray:
    """Low-pass the COP for path measures, keeping NaN where the COP is invalid."""
    ok = np.isfinite(c)
    out = np.full_like(c, np.nan)
    for s, e in bouts(ok):
        if e - s > 30:
            out[s:e] = lowpass(c[s:e], fs, fc)
    return out


# ------------------------------------------------------------------ short-stance TTS
# These methods take their stable reference from the quiet stance pooled over the session
# (the last 1 s of every trial), not from the trial's own window, so the result does not
# grow with the window length. They suit stances of about 2-3 s; classic TTS assumes 10-20 s.

def _rov(x: np.ndarray, w: int) -> np.ndarray:
    n = x.size // w
    return np.array([np.ptp(x[i * w:(i + 1) * w]) for i in range(n)])


def tts_rov(x: np.ndarray, fs: float, ref_rov_mean: float, win_s: float = 0.1) -> float:
    """Range-of-variation TTS (after Ross & Guskiewicz 2004; Colby et al. 1999).

    The range (max - min) of x is taken in successive win_s windows from touchdown, an
    unbounded third-order polynomial is fitted from the largest range in the first 0.3 s,
    and TTS is where the polynomial first falls to the mean range of the pooled quiet
    stance (same window length). This is the v1 method with its threshold corrected.
    """
    c = rov_curve(x, fs, win_s)
    if c is None:
        return float("nan")
    tt, f = c["tt"], c["fit"]
    below = np.where(f <= ref_rov_mean)[0]
    return float(tt[below[0]]) if below.size and f[0] > ref_rov_mean else float("nan")


def rov_curve(x: np.ndarray, fs: float, win_s: float = 0.1) -> dict | None:
    """Window ranges, their times (window centres), and the cubic fit from the largest early range."""
    w = int(round(win_s * fs))
    rv = _rov(x, w)
    if rv.size < 6:
        return None
    t = (np.arange(rv.size) + 0.5) * win_s
    i0 = int(np.argmax(rv[:max(2, int(round(0.3 / win_s)))]))
    c = np.polyfit(t[i0:], rv[i0:], 3)
    tt = np.linspace(t[i0], t[-1], 2000)
    return {"t": t, "rov": rv, "i0": i0, "tt": tt, "fit": np.polyval(c, tt)}


def tts_rms_hold(x: np.ndarray, fs: float, ref_rms: float, factor: float = 2.0, win_s: float = 0.25,
                 hold_s: float = 0.5) -> float:
    """Moving-RMS TTS (after Fransz et al. 2015): the first time from which the centred
    moving RMS of x stays at or below factor x the pooled quiet-stance RMS for hold_s."""
    w = max(1, int(round(win_s * fs)))
    r = np.sqrt(np.convolve(x ** 2, np.ones(w) / w, mode="same"))
    ok = r <= factor * ref_rms
    h = int(round(hold_s * fs))
    for i in range(0, ok.size - h):
        if ok[i:i + h].all():
            return i / fs
    return float("nan")


def short_stance_refs(Fap, Fml, Fz, fs, bw, ends: list, quiet_s: float = 1.0, fc: float = 20.0,
                      rov_windows=(0.1, 0.2, 0.25)) -> dict:
    """Pooled quiet-stance reference (last quiet_s of each stance) for every axis."""
    f = {"V": lowpass(Fz, fs, fc) - bw, "AP": lowpass(Fap, fs, fc), "ML": lowpass(Fml, fs, fc)}
    q = int(round(quiet_s * fs))
    out = {"rms": {}, "rov": {w: {} for w in rov_windows}}
    for k, x in f.items():
        seg = np.concatenate([x[e - q:e] for e in ends])
        out["rms"][k] = float(np.sqrt(np.mean(seg ** 2)))
        for w in rov_windows:
            out["rov"][w][k] = float(np.mean(np.concatenate([_rov(x[e - q:e], int(round(w * fs))) for e in ends])))
    return out


def tts_short_stance(Fap, Fml, Fz, fs, td2, end, bw, refs: dict, fc: float = 20.0) -> dict:
    s = slice(td2, end)
    x = {"V": lowpass(Fz, fs, fc)[s] - bw, "AP": lowpass(Fap, fs, fc)[s], "ML": lowpass(Fml, fs, fc)[s]}
    out = {}
    for k in ("V", "AP", "ML"):
        for w in refs["rov"]:
            out[f"tts_rov{int(round(w * 1000))}ms_{k}_s"] = tts_rov(x[k], fs, refs["rov"][w][k], w)
        win = 0.5 if k == "ML" else 0.25            # Fransz et al. 2015: longer window for ML
        for fac in (1.5, 2.0, 3.0):
            out[f"tts_rms_x{fac:g}_{k}_s"] = tts_rms_hold(x[k], fs, refs["rms"][k], fac, win)
    for tag in ("rov100ms", "rms_x2"):
        v = [out[f"tts_{tag}_{k}_s"] for k in ("AP", "ML", "V")]
        out[f"rv_tts_{tag}_s"] = float(np.sqrt(np.sum(np.square(v)))) if np.all(np.isfinite(v)) else float("nan")
    out["tts_bw5pct_V_s"] = tts_raw_vertical(Fz[s], fs, bw)
    return out


CHI2_95_2DF = 5.991464547107979


def quiet_zone(cop_ml: np.ndarray, cop_ap: np.ndarray, fs: float, ends: list, quiet_s: float = 1.0) -> dict:
    """Pooled quiet-stance COP zone: the 95% ellipse of the last quiet_s of every stance,
    each stance taken about its own mean. Used as the 'acceptable' zone after landing.
    """
    q = int(round(quiet_s * fs))
    pts = []
    for e in ends:
        ml, ap = cop_ml[e - q:e], cop_ap[e - q:e]
        ok = np.isfinite(ml) & np.isfinite(ap)
        pts.append(np.column_stack([ml[ok] - ml[ok].mean(), ap[ok] - ap[ok].mean()]))
    p = np.vstack(pts)
    cov = np.cov(p.T)
    w, v = np.linalg.eigh(cov)
    return {"cov": cov, "semi_major_mm": float(np.sqrt(CHI2_95_2DF * w[1])),
            "semi_minor_mm": float(np.sqrt(CHI2_95_2DF * w[0])),
            "angle_deg": float(np.degrees(np.arctan2(v[1, 1], v[0, 1]))),
            "area_mm2": float(np.pi * CHI2_95_2DF * np.sqrt(max(w[0], 0) * max(w[1], 0)))}


def quiet_centre(cop_ml: np.ndarray, cop_ap: np.ndarray, fs: float, end: int, quiet_s: float = 1.0) -> tuple:
    q = int(round(quiet_s * fs))
    return float(np.nanmean(cop_ml[end - q:end])), float(np.nanmean(cop_ap[end - q:end]))


def pct_outside_zone(ml: np.ndarray, ap: np.ndarray, centre: tuple, zone: dict) -> float:
    """Share of valid COP samples outside the zone ellipse placed at centre (%)."""
    ok = np.isfinite(ml) & np.isfinite(ap)
    if not ok.any():
        return float("nan")
    d = np.column_stack([ml[ok] - centre[0], ap[ok] - centre[1]])
    m2 = np.einsum("ij,jk,ik->i", d, np.linalg.inv(zone["cov"]), d)
    return float(100.0 * np.mean(m2 > CHI2_95_2DF))
