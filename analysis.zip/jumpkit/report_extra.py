"""The session page (one HTML with a Summary / Detailed toggle, printed to two PDFs), the
separate new-analyses report, and the cycle-phase panel CSVs for the cycle-phase study.
"""
from __future__ import annotations

import base64
import html as H
import os
import re

import numpy as np
import pandas as pd

from . import report as rp
from .session import session_code                    # noqa: F401  (kept here for older callers)

R, L = rp.R, rp.L

# Summary key table: (path, label, unit, scale, decimals, note)
KEY = [
    ((R, "jump_height_ft_m"), "Jump height", "cm", 100, 1, "flight time, g FT²/8"),
    ((R, "v_touchdown1_m_s"), "COM velocity at TD1", "m/s", 1, 2, ""),
    ((R, "td1_max_peak_BW"), "TD1 peak vertical force", "BW", 1, 2, ""),
    ((R, "td1_impulse_50ms_BWs"), "TD1 vertical impulse, 0-50 ms", "BW·s", 1, 3, ""),
    ((R, "td1_lr_f20_80_BW_s"), "TD1 loading rate, 20-80% of force", "BW/s", 1, 1, ""),
    ((R, "braking_time_s"), "Braking phase", "ms", 1000, 0, ""),
    ((R, "propulsive_time_s"), "Propulsive phase", "ms", 1000, 0, ""),
    ((R, "com_depression_m"), "COM lowering, contact 1", "cm", 100, 1, ""),
    ((R, "vertical_stiffness_BW_m"), "Vertical stiffness, contact 1", "BW/m", 1, 1, ""),
    ((L, "td2_max_peak_BW"), "TD2 peak vertical force", "BW", 1, 2, ""),
    ((L, "td2_impulse_50ms_BWs"), "TD2 vertical impulse, 0-50 ms", "BW·s", 1, 3, ""),
    ((L, "td2_lr_f20_80_BW_s"), "TD2 loading rate, 20-80% of force", "BW/s", 1, 1, ""),
    ((L, "time_to_lowest_com_s"), "Landing absorption time", "ms", 1000, 0, ""),
    ((L, "landing_com_depression_m"), "COM lowering, landing", "cm", 100, 1, ""),
    ((L, "landing_stiffness_BW_m"), "Landing stiffness", "BW/m", 1, 1, ""),
    (("dpsi_common", "DPSI"), "DPSI, common window", "", 1, 3, ""),
    (("tts_short", "rv_tts_rov100ms_s"), "Time to stabilization, resultant", "s", 1, 2, ""),
    (("cop", "td2_dynamic_0.4s_to_end", "path_mm"), "COP path length, stance", "mm", 1, 0, ""),
    (("cop", "td2_dynamic_0.4s_to_end", "mean_velocity_mm_s"), "COP mean velocity, stance", "mm/s", 1, 0, ""),
    (("cop", "td2_dynamic_0.4s_to_end", "ellipse95_area_mm2"), "COP 95% ellipse area, stance", "mm²", 1, 0, ""),
    (("cop_entropy", "td2_tts_phase", "sampen_AP"), "COP sample entropy AP, TTS phase", "", 1, 2, ""),
    (("cop_entropy", "td2_tts_phase", "sampen_ML"), "COP sample entropy ML, TTS phase", "", 1, 2, ""),
    (("cop_zone", "outside_pct", "td2_tts_phase"), "COP outside quiet zone, TTS phase", "%", 1, 0, ""),
    (("emg", "EMG1", "td2", "pre150_pct"), "VL pre-activation, 150 ms before TD2", "% peak", 1, 0, ""),
    (("emg", "EMG2", "td2", "pre150_pct"), "BF pre-activation, 150 ms before TD2", "% peak", 1, 0, ""),
    (("cocontraction", "td2", "pre150", "cci_pct"), "VL-BF co-contraction, 150 ms before TD2", "%", 1, 0, ""),
    (("cocontraction", "td2", "post50", "cci_pct"), "VL-BF co-contraction, 0-50 ms after TD2", "%", 1, 0, ""),
]

TTS_ROWS = []
for k, lab in (("V", "vertical"), ("AP", "AP"), ("ML", "ML")):
    TTS_ROWS.append((("tts_short", f"tts_rov100ms_{k}_s"), f"TTS {lab}, range of variation (0.1 s windows)", "s", 1, 2,
                     "main method" if k == "V" else ""))
TTS_ROWS.append((("tts_short", "rv_tts_rov100ms_s"), "TTS resultant vector, range of variation", "s", 1, 2,
                 "√(AP² + ML² + V²)"))
for k, lab in (("V", "vertical"), ("AP", "AP"), ("ML", "ML")):
    for w in (200, 250):
        TTS_ROWS.append((("tts_short", f"tts_rov{w}ms_{k}_s"), f"TTS {lab}, range of variation ({w/1000:g} s windows)", "s", 1, 2,
                         "window sensitivity"))
for k, lab in (("V", "vertical"), ("AP", "AP"), ("ML", "ML")):
    for fac in ("1.5", "2", "3"):
        TTS_ROWS.append((("tts_short", f"tts_rms_x{fac}_{k}_s"), f"TTS {lab}, moving RMS below {fac}x quiet", "s", 1, 2,
                         "held for 0.5 s; threshold sensitivity" if fac != "2" else "held for 0.5 s"))

# Cycle-phase panel for the cycle-phase study: (path, label, unit, scale, decimals, why it matters across the cycle)
PANEL = [
    ((L, "td2_max_peak_BW"), "Landing peak vertical force", "BW", 1, 2, "harder landings at menses than at ovulation, after ACL reconstruction (Bell et al. 2014)"),
    ((L, "td2_impulse_50ms_BWs"), "Landing vertical impulse, 0-50 ms", "BW·s", 1, 3, "load absorbed just after contact"),
    ((L, "td2_lr_f20_80_BW_s"), "Landing loading rate, 20-80% of force", "BW/s", 1, 1, "landing hardness"),
    ((L, "time_to_lowest_com_s"), "Landing absorption time", "ms", 1000, 0, "absorption strategy"),
    ((L, "landing_com_depression_m"), "COM lowering, landing", "cm", 100, 1, "absorption strategy"),
    ((L, "landing_stiffness_BW_m"), "Landing stiffness", "BW/m", 1, 1, "absorption strategy"),
    (("kin", "fppa_change_from_td2_deg"), "Knee FPPA change after TD2", "deg", 1, 1, "more valgus when knee laxity rises across the cycle (Shultz et al. 2012)"),
    (("emg", "EMG1", "td2", "pre150_pct"), "VL pre-activation, TD2", "% peak", 1, 0, "preparation before contact"),
    (("emg", "EMG2", "td2", "pre150_pct"), "BF pre-activation, TD2", "% peak", 1, 0, "hamstring timing differed between cycle phases (Dedrick et al. 2008)"),
    (("cocontraction", "td2", "pre150", "cci_pct"), "VL-BF co-contraction before TD2", "%", 1, 0, "EMG dominance across phases"),
    (("cocontraction", "td2", "post50", "cci_pct"), "VL-BF co-contraction 0-50 ms after TD2", "%", 1, 0, "EMG dominance across phases"),
    (("tts_short", "rv_tts_rov100ms_s"), "Time to stabilization, resultant", "s", 1, 2, "single-leg postural control did not change across the cycle (Hertel et al. 2006)"),
    (("dpsi_common", "DPSI"), "DPSI, common window", "", 1, 3, "dynamic stability"),
    (("cop_entropy", "td2_tts_phase", "sampen_AP"), "COP sample entropy AP, TTS phase", "", 1, 2, "post-landing recovery pattern"),
    (("cop_entropy", "td2_tts_phase", "sampen_ML"), "COP sample entropy ML, TTS phase", "", 1, 2, "post-landing recovery pattern"),
    ((R, "jump_height_ft_m"), "Jump height", "cm", 100, 1, "describes the population; comparable across studies"),
    ((R, "braking_time_s"), "Braking phase", "ms", 1000, 0, "temporal parameter"),
]


def _path_val(T, kin_row, path, sc):
    if path[0] == "kin":
        v = (kin_row or {}).get(path[1])
    else:
        v = rp._get(T, path)
    return v * sc if rp._num(v) else None


def key_rows(res, items, section):
    kin = (res.get("video") or {}).get("kinematics") or [{}] * len(res["trials"])
    rows = []
    for path, lab, unit, sc, dec, note in items:
        vals = [_path_val(T, k, path, sc) for T, k in zip(res["trials"], kin)]
        rows.append(rp._row(section, lab, unit, vals, dec, note))
    return rows


def cycle_panel(res) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Cycle-phase panel with within-session typical error and minimal detectable change.

    MDC95 = 1.96 * sqrt(2) * SD_within (= 2.77 SD). With three trials the SD is itself
    uncertain, so treat MDC as a planning value."""
    rows = key_rows(res, PANEL, "panel")
    df = pd.DataFrame(rows)
    df["mdc95"] = [2.77 * s if s is not None else None for s in df["sd"]]
    sc = session_code(res["meta"]["file"])
    summ = {"file": os.path.basename(res["meta"]["file"]), "participant_code": sc["code"], "session_code": sc["session"],
            "record_start_utc": res["meta"]["record_start_utc"],
            "n_trials": len(res["trials"]), "body_weight_N": res["body_weight"]["session_bw_N"]}
    for r in rows:
        key = re.sub(r"[^a-z0-9]+", "_", r["metric"].lower()).strip("_")
        summ[f"{key}_mean"] = r["mean"]
        summ[f"{key}_sd"] = r["sd"]
    return df, pd.DataFrame([summ])


def _common_rep(res, ser, out_dir):
    fig = lambda n: rp._img(os.path.join(out_dir, "figures", n)) if os.path.exists(os.path.join(out_dir, "figures", n)) else ""
    vid = res.get("video") or {}
    bw = res["body_weight"]
    g = lambda p, sc=1: rp._vals(res, p, sc)
    return fig, vid, bw, g


STUDY_REFS = [
    "Bell DR, et al. 2014. J Athl Train 49:154-62. doi:10.4085/1062-6050-49.2.01",
    "Dedrick GS, et al. 2008. J Electromyogr Kinesiol 18:68-78. doi:10.1016/j.jelekin.2006.09.004",
    "Dos'Santos T, et al. 2023. PLoS One 18:e0280800. doi:10.1371/journal.pone.0280800",
    "Hertel J, et al. 2006. Knee Surg Sports Traumatol Arthrosc 14:817-22. doi:10.1007/s00167-006-0047-4",
    "Okazaki M, et al. 2017. Orthop J Sports Med 5:2325967117724753. doi:10.1177/2325967117724753",
    "Shultz SJ, et al. 2012. Med Sci Sports Exerc 44:900-9. doi:10.1249/MSS.0b013e31823bfb25",
    "Stitelmann A, Allet L, Armand S, Tscholl P. 2024. J Clin Med 13:3407. doi:10.3390/jcm13123407",
    "Stitelmann A, et al. 2024. Int J Sports Phys Ther 19:1647-50. doi:10.26603/001c.126285",
    "Stitelmann A, Bruyneel AV, Enea C, Boisseau N. 2026. Sports Med 56:1937-53. doi:10.1007/s40279-026-02412-9",
]


def cited(body: str, refs: list[str]) -> list[str]:
    """References whose first-author surname and year both appear in the report text, sorted."""
    text = re.sub(r"<[^>]+>", " ", H.unescape(re.sub(r"<(script|style)\b.*?</\1>", " ", body, flags=re.S)))
    keep = []
    for r in refs:
        sur, y = r.split(" ")[0].rstrip(","), re.search(r"\b(19|20)\d\d\b", r)
        if re.search(re.escape(sur) + (r"[^;()]{0,60}?\(?" + y.group(0) if y else ""), text):
            keep.append(r)
    return sorted(set(keep), key=lambda r: r.lower())


def build_novel_html(res, ser, tables_, out_dir) -> str:
    tpl = open(os.path.join(os.path.dirname(__file__), "report_novel_template.html")).read()
    fig, vid, bw, g = _common_rep(res, ser, out_dir)
    df = tables_["metrics_by_trial"]
    n1 = [t["novel_xcom"] for t in res["trials"] if t.get("novel_xcom")]
    n1w = [d["window_s"][1] - d["window_s"][0] for d in n1]
    rep = {
        "%%N1SENT%%": rp.n1_sentence(res).replace("<b>New analyses.</b> ", ""),
        "%%T_N1%%": rp._metric_table(df, "n1"), "%%T_N2%%": rp._metric_table(df, "n2"),
        "%%F_N1%%": fig("novel_n1_xcom.png"), "%%F_N2%%": fig("novel_n2_stabilisation.png"),
        "%%N1WIN%%": f"{min(n1w):.1f}-{max(n1w):.1f}" if n1w else "-",
        "%%STANCE%%": rp._rng(g((L, "quiet_stance_s")), 1), "%%COMMON%%": f"{res['common_window_s']:.1f}",
        "%%TAU%%": rp._rng(g(("novel_tdpsi", "tau_s"), 1000), 0),
        "%%SHARE%%": f"{np.nanmin(g(('novel_tdpsi', 'dpsi_share_first_0.4s_pct'))):.0f}-"
                     f"{np.nanmax(g(('novel_tdpsi', 'dpsi_share_first_0.4s_pct'))):.0f}",
        "%%BW%%": f"{bw['session_bw_N']:.1f}", "%%START%%": res["meta"]["record_start_utc"][:19].replace("T", " ") + " UTC",
        "%%VERSION%%": res["meta"]["jumpkit_version"], **rp.session_fields(res),
    }
    for k, v in rep.items():
        tpl = tpl.replace(k, v)
    return tpl.replace("%%REFS%%", "".join(f"<li>{H.escape(r)}</li>" for r in cited(tpl, rp.REFERENCES + STUDY_REFS)))


# ------------------------------------------------------------------ session page (summary + detailed)
CARDS = [((R, "jump_height_ft_m"), "Jump height", "cm", 100, 1),
         ((L, "td2_max_peak_BW"), "Landing peak force", "BW", 1, 2),
         ((L, "td2_impulse_50ms_BWs"), "Landing impulse, 0-50 ms", "BW·s", 1, 3),
         ((L, "landing_stiffness_BW_m"), "Landing stiffness", "BW/m", 1, 1),
         (("tts_short", "rv_tts_rov100ms_s"), "TTS, resultant", "s", 1, 2),
         (("dpsi_common", "DPSI"), "DPSI", "", 1, 3),
         (("cop_entropy", "td2_tts_phase", "sampen_ML"), "COP entropy ML, TTS phase", "", 1, 2),
         (("cocontraction", "td2", "pre150", "cci_pct"), "VL-BF co-contraction before TD2", "%", 1, 0)]

ENTROPY_ROWS = [((("cop_entropy", w, f"{q}_{c}" if q == "sampen" else f"range_{c}_mm")),
                 f"{'Sample entropy' if q == 'sampen' else 'COP displacement'} {c}, {wl}", "" if q == "sampen" else "mm",
                 1, 2 if q == "sampen" else 0, "")
                for w, wl in (("td2_tts_phase", "TTS phase"), ("td2_after_tts", "after TTS"))
                for c in ("AP", "ML") for q in ("sampen", "range")]
ENTROPY_ROWS += [(("cop_entropy", "td2_tts_phase", f"sampen_{c}_{k}"), f"Sample entropy {c}, TTS phase, {lab}", "", 1, 2,
                  "sensitivity") for k, lab in (("r015", "r = 0.15 SD"), ("r025", "r = 0.25 SD"), ("200Hz", "200 Hz"),
                                                ("from20ms", "from TD2 + 20 ms"))
                 for c in ("AP", "ML")]
ZONE_ROWS = [(("cop_zone", "outside_pct", w), f"COP outside the quiet zone, {wl}", "%", 1, 0, "")
             for w, wl in (("td2_20_200ms", "TD2 + 20-200 ms"), ("td2_tts_phase", "TTS phase"), ("td2_after_tts", "after TTS"))]
COCON_ROWS = [(("cocontraction", ev, w, k), f"{ev.upper()}, {wl}: {kl}", u, 1, d, "")
              for ev in ("td1", "td2") for w, wl in (("pre150", "150 ms before"), ("post50", "0-50 ms after"))
              for k, kl, u, d in (("cci_pct", "co-contraction index", "%", 0), ("ratio_b_a", "BF:VL ratio", "", 2))]
DROP_ROWS = ("Ground contact time", "Flight time", "RSI", "RSR", "Effective drop height", "First force peak",
             "Time to first peak", "Loading rate, peak instantaneous", "Loading rate, 20-80% of time",
             "Vertical impulse, first 100 ms", "Peak braking GRF (AP minimum)", "Peak propulsive GRF (AP maximum)",
             "AP impulse", "Peak medial GRF (ML minimum)", "Peak lateral GRF (ML maximum)")
DROP_PARTS = ("if the delay were", "clipped samples", "time to envelope peak")


def _fig_block(src, alt, caption):
    return f"<figure><img class='fig' src='{src}' alt='{H.escape(alt)}'><figcaption>{caption}</figcaption></figure>"


def _ul(items):
    return "<ul class='res'>" + "".join(f"<li>{x}</li>" for x in items) + "</ul>"


def _cop_front_to_back(res, ser, key) -> bool:
    """True if, in every trial, the window's last COP sample is posterior to its first."""
    ok = []
    for T in res["trials"]:
        a, b = T["cop_windows_idx"][key]
        c = ser["cop_ap"][a:b]
        c = c[np.isfinite(c)]
        ok.append(c.size > 1 and c[-1] < c[0])
    return all(ok)


def _rng1(a, d):
    """Range as 'lo-hi', or one value when both round the same."""
    lo, hi = f"{np.nanmin(a):.{d}f}", f"{np.nanmax(a):.{d}f}"
    return lo if lo == hi else f"{lo}-{hi}"


def results_text(res, ser) -> dict:
    """Result sentences for each section, all computed from results.json."""
    g = lambda p, sc=1: rp._vals(res, p, sc)
    r_ = _rng1
    T = res["trials"]
    tn = lambda i: T[int(i)]["number"]
    out = {}
    jh, vtd = g((R, "jump_height_ft_m"), 100), g((R, "v_touchdown1_m_s"))
    brk, prp, cd = g((R, "braking_time_s"), 1000), g((R, "propulsive_time_s"), 1000), g((R, "com_depression_m"), 100)
    p1, i1, lr1 = g((R, "td1_max_peak_BW")), g((R, "td1_impulse_50ms_BWs")), g((R, "td1_lr_f20_80_BW_s"))
    st1, pw = g((R, "vertical_stiffness_BW_m")), g((R, "peak_power_W_kg"))
    out["rebound"] = _ul([
        f"Jump height was {r_(jh, 1)} cm. At TD1 the COM was moving down at {r_(-vtd, 2)} m/s.",
        f"Peak vertical force after TD1 was {r_(p1, 2)} BW. The vertical impulse in the first 50 ms was {r_(i1, 3)} BW&middot;s, "
        f"and the loading rate {r_(lr1, 1)} BW/s.",
        f"Braking lasted {r_(brk, 0)} ms and propulsion {r_(prp, 0)} ms. The COM lowered {r_(cd, 1)} cm.",
        f"Vertical stiffness was {r_(st1, 1)} BW/m, and peak COM power {r_(pw, 1)} W/kg."])
    p2, i2, lr2 = g((L, "td2_max_peak_BW")), g((L, "td2_impulse_50ms_BWs")), g((L, "td2_lr_f20_80_BW_s"))
    ab, cl, st2 = g((L, "time_to_lowest_com_s"), 1000), g((L, "landing_com_depression_m"), 100), g((L, "landing_stiffness_BW_m"))
    soft = int(np.nanargmin(st2))
    out["landing"] = _ul([
        f"Peak vertical force after TD2 was {r_(p2, 2)} BW. The vertical impulse in the first 50 ms was {r_(i2, 3)} BW&middot;s, "
        f"and the loading rate {r_(lr2, 1)} BW/s.",
        f"The COM reached its lowest point {r_(ab, 0)} ms after TD2, {r_(cl, 1)} cm below its touchdown height. Landing "
        f"stiffness was {r_(st2, 1)} BW/m.",
        f"Trial {tn(soft)} was the least stiff landing ({st2[soft]:.1f} BW/m), with the lowest peak force "
        f"({p2[soft]:.2f} BW) and the longest absorption ({ab[soft]:.0f} ms)."
        if soft == int(np.nanargmin(p2)) == int(np.nanargmax(ab)) else
        f"Trial {tn(soft)} was the least stiff landing ({st2[soft]:.1f} BW/m)."])
    tv, tap, tml, trv = (g(("tts_short", k)) for k in ("tts_rov100ms_V_s", "tts_rov100ms_AP_s", "tts_rov100ms_ML_s",
                                                         "rv_tts_rov100ms_s"))
    dp, vsi = g(("dpsi_common", "DPSI")), g(("dpsi_common", "VSI"))
    qs = g((L, "quiet_stance_s"))
    out["stab"] = _ul([
        f"Quiet stance after TD2 lasted {r_(qs, 2)} s before the step-off or the end of the record.",
        f"Time to stabilization was {r_(tv, 2)} s vertical, {r_(tap, 2)} s AP and {r_(tml, 2)} s ML. "
        f"The resultant TTS was {r_(trv, 2)} s.",
        f"DPSI over the first {res['common_window_s']:.1f} s was {r_(dp, 3)}. The vertical term made up "
        f"{r_(100 * vsi ** 2 / dp ** 2, 0)}% of DPSI&sup2;."])
    sp, sv, se_ = (g(("cop", "td2_dynamic_0.4s_to_end", k)) for k in ("path_mm", "mean_velocity_mm_s", "ellipse95_area_mm2"))
    z = {w: g(("cop_zone", "outside_pct", w)) for w in ("td2_20_200ms", "td2_tts_phase", "td2_after_tts")}
    ea, em = g(("cop_entropy", "td2_tts_phase", "sampen_AP")), g(("cop_entropy", "td2_tts_phase", "sampen_ML"))
    ea2, em2 = g(("cop_entropy", "td2_after_tts", "sampen_AP")), g(("cop_entropy", "td2_after_tts", "sampen_ML"))
    out["cop"] = _ul([
        f"In stance (TD2 + 0.4 s to the end), the COP travelled {r_(sp, 0)} mm at {r_(sv, 0)} mm/s, with a 95% ellipse of "
        f"{r_(se_, 0)} mm&sup2;.",
        f"The COP was outside the quiet-stance zone for {r_(z['td2_20_200ms'], 0)}% of the first 200 ms, "
        f"{r_(z['td2_tts_phase'], 0)}% of the TTS phase and {r_(z['td2_after_tts'], 0)}% after TTS.",
        f"COP sample entropy in the TTS phase was {r_(ea, 2)} AP and {r_(em, 2)} ML. After TTS it was {r_(ea2, 2)} AP and "
        f"{r_(em2, 2)} ML."])
    e = lambda m, ev, k, sc=1: g(("emg", m, ev, k), sc)
    cc = lambda ev, w, k="cci_pct": g(("cocontraction", ev, w, k))
    out["emg"] = _ul([
        f"In the 150 ms before TD2, VL was at {r_(e('EMG1', 'td2', 'pre150_pct'), 0)}% and BF at "
        f"{r_(e('EMG2', 'td2', 'pre150_pct'), 0)}% of their session peaks. In the 150 ms before TD1 they were at "
        f"{r_(e('EMG1', 'td1', 'pre150_pct'), 0)}% and {r_(e('EMG2', 'td1', 'pre150_pct'), 0)}%.",
        f"In the first 50 ms after TD2, VL was at {r_(e('EMG1', 'td2', 'post50_pct'), 0)}% and BF at "
        f"{r_(e('EMG2', 'td2', 'post50_pct'), 0)}%.",
        f"VL-BF co-contraction was {r_(cc('td2', 'pre150'), 0)}% before TD2 and {r_(cc('td2', 'post50'), 0)}% in the first "
        f"50 ms after it. Before TD1 it was {r_(cc('td1', 'pre150'), 0)}%."])
    kin = (res.get("video") or {}).get("kinematics") or []
    items = []
    if kin:
        a = [k.get("fppa_at_td2_deg") for k in kin]
        c = [k.get("fppa_change_from_td2_deg") for k in kin]
        items.append(f"Knee FPPA (ASIS, knee, ankle) in the first frame after TD2 was {r_(np.array(a, float), 1)}&deg;. "
                     f"Its largest change in the next 0.5 s was " + ", ".join(f"{x:+.1f}&deg;" for x in c) + " in trials "
                     + ", ".join(str(t["number"]) for t in T) + " (positive = towards valgus).")
    out["video"] = _ul(items)
    out["summary"] = _ul([
        f"<b>Landing load.</b> Peak force {r_(p2, 2)} BW, impulse in the first 50 ms {r_(i2, 3)} BW&middot;s, "
        f"stiffness {r_(st2, 1)} BW/m.",
        f"<b>Absorption.</b> COM lowest {r_(ab, 0)} ms after TD2, {r_(cl, 1)} cm down.",
        f"<b>Recovery.</b> TTS {r_(tv, 2)} s vertical, {r_(tap, 2)} s AP, {r_(tml, 2)} s ML. COP outside the quiet zone for "
        f"{r_(z['td2_tts_phase'], 0)}% of the TTS phase. COP entropy {r_(ea, 2)} AP, {r_(em, 2)} ML.",
        f"<b>Muscles.</b> VL-BF co-contraction {r_(cc('td2', 'pre150'), 0)}% before TD2 and {r_(cc('td2', 'post50'), 0)}% "
        f"in the first 50 ms.",
        f"<b>Jump.</b> Height {r_(jh, 1)} cm."])
    return out


SUMMARY_KEY = KEY[:16] + TTS_ROWS[:3] + KEY[16:]


def build_session_html(res, ser, tables_, out_dir) -> str:
    """One page with a Summary / Detailed toggle. The same file prints both PDFs (#summary, #detailed)."""
    import plotly.offline as po
    tpl = open(os.path.join(os.path.dirname(__file__), "report_session_template.html")).read()
    fig, vid, bw, g = _common_rep(res, ser, out_dir)
    T = res["trials"]
    df = tables_["metrics_by_trial"]
    df = df[~df["metric"].isin(DROP_ROWS) & ~df["metric"].str.contains("|".join(DROP_PARTS))]
    txt = results_text(res, ser)
    mp4 = os.path.join(out_dir, vid["mp4"]) if vid.get("mp4") else None
    video_src = ("data:video/mp4;base64," + base64.b64encode(open(mp4, "rb").read()).decode()) if mp4 else ""
    cards = "".join(f"<div class='card'><div class='cv'>{np.nanmean(g(p, sc)):.{d}f} {H.escape(u)}</div>"
                    f"<div class='cl'>{H.escape(lab)}</div></div>" for p, lab, u, sc, d in CARDS)
    key = pd.DataFrame(key_rows(res, SUMMARY_KEY, "key"))
    tts = pd.DataFrame(key_rows(res, TTS_ROWS, "tts"))
    ent = pd.DataFrame(key_rows(res, ENTROPY_ROWS, "ent"))
    zon = pd.DataFrame(key_rows(res, ZONE_ROWS, "zone"))
    coc = pd.DataFrame(key_rows(res, COCON_ROWS, "cocon"))
    end = lambda t: "" if t["step_off_observed"] else " The force record ends during this stance."
    tl = "".join(_fig_block(fig(f"trial{t['number']}_timeline.jpg"), f"Trial {t['number']} timeline",
                            f"<span class='s'>Trial {t['number']}: video frame at each force event, with EMG bars "
                            f"(E1 = EMG1, E2 = EMG2) and the knee angle lines (teal).{end(t)}</span><span class='d'>Trial {t['number']}. Top: the video frame at "
                            f"TD1, the lowest COM of contact 1, TO2, TD2, the lowest COM of the landing, and the end of quiet stance. "
                            f"The label above each frame gives its time from the event. Orange lines: stance-leg pose. Teal lines: "
                            f"the ASIS-knee and knee-ankle lines that the knee FPPA is measured from, with the ASIS marker "
                            f"(yellow dot) and the angle next to the knee (valgus +). Bars on each "
                            f"frame: EMG1 (E1, green) and EMG2 (E2, magenta) at that moment, % of session peak. Grey connectors link "
                            f"each frame to its event on the force trace. Middle: vertical force. Bottom: EMG envelopes. Dotted lines: "
                            f"events (red) and lowest COM (green). Thin grey lines: frame times.{end(t)}</span>")
                 for t in T)
    panels = "".join(_fig_block(fig(f"trial{t['number']}_panel.png"), f"Trial {t['number']} panel",
                                f"Trial {t['number']}, all signals from 0.3 s before TD1 to the end of stance. From top: vertical "
                                f"force with 1 BW; COM velocity (solid) and displacement (dashed); AP and ML force; COP AP and ML, each "
                                f"minus its mean; EMG envelopes with the 150 ms before each touchdown shaded. Dashed lines: TD1 and TD2 "
                                f"(red), TO2 (purple), end of quiet stance (grey). Dotted green lines: lowest COM. The scales are the "
                                f"same in all three trials.") for t in T)
    mt = lambda sec: rp._metric_table(df, sec, defs=False)
    rep = {
        "%%CODE%%": session_code(res["meta"]["file"])["code"], "%%FILE%%": os.path.basename(res["meta"]["file"]),
        "%%START%%": res["meta"]["record_start_utc"][:10], "%%NTRIALS%%": str(len(T)),
        "%%BW%%": f"{bw['session_bw_N']:.1f}", "%%MASS%%": f"{bw['session_mass_kg']:.1f}",
        "%%VERSION%%": res["meta"]["jumpkit_version"], "%%CARDS%%": cards, "%%FINDINGS%%": txt["summary"],
        "%%GLOSSARY%%": glossary_html(res), "%%T_KEY%%": rp._metric_table(key, "key", defs=False),
        "%%T_EVENTS%%": rp._simple_table(tables_["events"], {c: 3 for c in tables_["events"].columns}),
        "%%TXT_REBOUND%%": txt["rebound"], "%%TXT_LANDING%%": txt["landing"], "%%TXT_STAB%%": txt["stab"],
        "%%TXT_COP%%": txt["cop"], "%%TXT_EMG%%": txt["emg"], "%%TXT_VIDEO%%": txt["video"],
        "%%T_REBOUND%%": mt("rebound"), "%%T_LANDING%%": mt("landing"), "%%T_STAB%%": mt("stability"),
        "%%T_TTS%%": rp._metric_table(tts, "tts", defs=False), "%%T_EMG1%%": mt("emg_EMG1"), "%%T_EMG2%%": mt("emg_EMG2"),
        "%%T_KIN%%": mt("kin"), "%%T_COP%%": rp._simple_table(tables_["cop_summary"][[c for c in tables_["cop_summary"].columns
                                                               if not c.startswith("TD1")]]),
        "%%TIMELINES%%": tl, "%%PANELS%%": panels,
        "%%F_OVERVIEW%%": fig("overview_force.png"), "%%F_PHASES%%": fig("res_phases.png"),
        "%%F_CONTACT%%": fig("res_contact_overlay.png"), "%%F_COM%%": fig("res_com_overlay.png"),
        "%%F_LOOPS%%": fig("res_force_com_loops.png"), "%%F_LOADING%%": fig("res_loading.png"),
        "%%F_TTS%%": fig("res_tts_curves.png"), "%%F_TTSM%%": fig("res_tts_methods.png"), "%%F_DPSI%%": fig("res_dpsi.png"),
        "%%F_ENTROPY%%": fig("res_cop_entropy.png"), "%%F_COCON%%": fig("res_cocontraction.png"),
        "%%T_ENTROPY%%": rp._metric_table(ent, "ent", defs=False), "%%T_ZONE%%": rp._metric_table(zon, "zone", defs=False),
        "%%T_COCON%%": rp._metric_table(coc, "cocon", defs=False),
        "%%F_COPSTANCE%%": fig("res_cop_stance.png"), "%%F_HEAT%%": fig("cop_zone_heatmaps.png"),
        "%%F_PLATE%%": fig("cop_paths_plate.png"), "%%F_COPBARS%%": fig("res_cop_bars.png"),
        "%%F_EMGO%%": fig("res_emg_overlay.png"), "%%F_EMGB%%": fig("res_emg_bars.png"), "%%F_FPPA%%": fig("res_fppa.png"),
        "%%F_SPREAD%%": fig("res_consistency.png"), "%%COMMON%%": f"{res['common_window_s']:.1f}",
        "%%HEXT%%": (lambda x: f"{x[1]-x[0]:.0f} &times; {x[3]-x[2]:.0f}")(res["heatmaps"]["zone"]["extent_mm"]),
        "%%HBIN%%": f"{res['heatmaps']['zone']['bin_mm']:g}",
        "%%VIDEO%%": video_src, "%%DATA%%": rp._series_json(res, ser), **rp.session_fields(res),
    }
    tpl = rp.video_blocks(tpl, bool(vid))
    for k, v in rep.items():
        if k != "%%PLOTLY%%":
            tpl = tpl.replace(k, v)
    return tpl.replace("%%PLOTLY%%", po.get_plotlyjs())


# ------------------------------------------------------------------ terms and abbreviations
def glossary(res) -> list:
    """(group, [(term, meaning)]) for the detailed view. Meanings only; the methods are in the feature manifest."""
    bw = res["body_weight"]["session_bw_N"]
    leg = "right" if res["meta"]["stance_leg"].upper() == "R" else "left"
    return [
        ("Events and phases", [
            ("TD1", "first touchdown, landing from the box"), ("TO2", "rebound take-off"),
            ("TD2", "second touchdown, the landing that is held"), ("Contact 1", "TD1 to TO2"),
            ("Braking phase", "TD1 to the lowest COM point"), ("Propulsive phase", "lowest COM point to TO2"),
            ("Flight", "TO2 to TD2"), ("Absorption phase", "TD2 to the lowest COM point"),
            ("Quiet stance", "single-leg stance after TD2")]),
        ("Body and force", [
            ("BW", f"body weight ({bw:.1f} N); forces in BW are multiples of it"),
            ("GRF", "ground reaction force"), ("Fz", "vertical GRF"),
            ("AP", "anterior-posterior (forward +)"), ("ML", f"medial-lateral (lateral, towards the {leg}, +)"),
            ("COM", "centre of mass"), ("COP", "centre of pressure")]),
        ("Jump and landing", [
            ("Jump height", "height of the rebound jump"),
            ("Peak vertical force", "largest vertical force after touchdown"),
            ("Vertical impulse, 0-50 ms", "vertical force summed over the first 50 ms: the load absorbed just after contact"),
            ("Net impulse", "force above body weight, summed over a phase"),
            ("COM lowering", "how far the COM drops after touchdown"),
            ("Stiffness", "peak vertical force divided by the largest COM lowering"),
            ("Peak COM power", "largest power at the COM, per kg"),
            ("First force peak", "first clear force peak after touchdown"),
            ("Loading rate", "slope of the force between 20% and 80% of the first force peak")]),
        ("Stability", [
            ("TTS", "time to stabilization after TD2"), ("Resultant TTS", "TTS combined over the three directions"),
            ("TTS phase", "TD2 + 20 ms until all three directions have settled"),
            ("DPSI", "dynamic postural stability index (higher = less stable)"),
            ("APSI, MLSI, VSI", "the AP, ML and vertical parts of DPSI")]),
        ("Centre of pressure", [
            ("Path length", "distance the COP travels"), ("Mean velocity", "average COP speed"),
            ("Net displacement", "distance from the first to the last COP point"),
            ("AP range, ML range", "spread of the COP in each direction"),
            ("RMS distance", "typical distance from the mean COP position"),
            ("95% ellipse area", "area that holds 95% of COP points"),
            ("Dwell map", "heatmap of where the COP spent its time"),
            ("Quiet-stance zone", "95% ellipse of quiet-stance COP (acceptable zone); outside it is the risk zone"),
            ("Sample entropy", "how unpredictable the COP pattern is: low = regular, high = irregular; not better or worse balance")]),
        ("Muscle activity and video", [
            ("EMG", "electromyography, a muscle's electrical activity"),
            ("EMG1, VL", f"vastus lateralis, {leg} thigh"),
            ("EMG2, BF", f"biceps femoris, {leg} thigh"),
            ("Co-contraction index", "share of VL and BF activity the two muscles have in common (100% = equal)"),
            ("BF:VL ratio", "BF activity divided by VL activity, both as % of session peak"),
            ("% session peak", "share of the channel's largest value in the session"),
            ("Pre-activation", "EMG in the 100 or 150 ms before contact"),
            ("30-60 ms after contact", "early EMG response after touchdown"),
            ("FPPA", "frontal-plane projection angle of the knee from ASIS, knee and ankle (valgus +)"),
            ("ASIS", "anterior superior iliac spine; the yellow marker on the hip"),
            ("Valgus, varus", "knee inside or outside the hip-ankle line")]),
        ("Statistics and units", [
            ("SD", "standard deviation of the three trials"), ("CV", "coefficient of variation, SD as % of the mean"),
            ("n", "trials with a value, when fewer than three"), ("BW·s, BW/s, BW/m", "impulse, loading rate and stiffness in body weights"),
            ("W/kg", "watts per kg of body mass"), ("N, N·s", "newtons, newton-seconds")]),
    ]


def glossary_html(res) -> str:
    return "".join(f"<h3>{H.escape(grp)}</h3><div class='abbr'>"
                   + "".join(f"<div><b>{H.escape(t)}</b>: {H.escape(d)}</div>" for t, d in items) + "</div>"
                   for grp, items in glossary(res))
