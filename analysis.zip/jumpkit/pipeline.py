"""End-to-end analysis of one LabChart session of single-leg drop vertical jumps.

analyse() returns one nested dict of results plus the time series the report plots.
Axis convention after the plate frame is mapped to the body (see body_axes):
AP = anterior positive, ML = lateral positive (towards the stance-leg side),
vertical = up. Forces are ground reaction forces on the body.
"""
from __future__ import annotations

import json
import platform
from dataclasses import asdict

import numpy as np

from . import __version__
from . import acc as accmod
from . import entropy as entmod
from . import emg as emgmod
from . import kinetics as kin
from . import novel
from . import stability as stab
from .adicht import read_adicht
from .events import DetectParams, detect_drop_jumps, threshold_sensitivity
from .forceplate import build_plate, lab_tare_check
from .sync import trigno_delay

G = kin.G
COP_MASK_S = 0.020        # COP is masked for 20 ms after each touchdown (impact transient)
MIN_STANCE_S = 1.5        # shorter stances skip body-weight, stability and N1/N2
ENTROPY_START_S = 0.150   # SampEn TTS-phase window starts here: the landing spike before it sets a wide r (0.2 SD)


def _f(x):
    """JSON-safe floats."""
    if isinstance(x, dict):
        return {str(k): _f(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_f(v) for v in x]
    if isinstance(x, (np.floating, float)):
        return None if not np.isfinite(x) else float(x)
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, np.bool_):
        return bool(x)
    if isinstance(x, np.ndarray):
        return _f(x.tolist())
    return x


def body_axes(P, stance_leg: str) -> dict:
    """Map the Kistler plate frame to body axes.

    Kistler reports the action force of the foot on the plate (z down). In this setup the
    participant faces -x (checked three ways: the braking impulse at TD1, the forefoot-to-
    heel COP path at TD1, and the foot positions seen in the video), so:
      GRF anterior = Fx, GRF towards the participant's right = Fy,
      COP anterior = -COPx, COP towards the participant's right = -COPy.
    Lateral = the stance-leg side.
    """
    lat = 1.0 if stance_leg.upper() == "R" else -1.0
    return {"F_ap": P.Fx, "F_ml": lat * P.Fy, "cop_ap": -P.COPx_mm, "cop_ml": -lat * P.COPy_mm,
            "lateral_sign": lat}


def _stance_ends(Fz, fs, trials, bw):
    return [stab.stance_end(Fz, fs, tr.td2, tr.off, bw) for tr in trials]


def analyse(adicht_path: str, cfg: dict) -> tuple[dict, dict]:
    R = read_adicht(adicht_path)
    rec = R[cfg["record"] - 1]
    out: dict = {"meta": {
        "jumpkit_version": __version__, "python": platform.python_version(),
        "file": adicht_path, "record": cfg["record"], "n_records": len(R),
        "record_start_utc": rec.start_utc.isoformat(),
        "record_starts_utc": [r.start_utc.isoformat() for r in R],
        "reader_warnings": [w for r in R for w in r.warnings],
        "channels": {k: {"fs": c.fs, "n": len(c.counts)} for k, c in rec.channels.items()},
        "stance_leg": cfg["stance_leg"],
    }}
    qc: dict = {}
    qc["lab_tare_check_record1"] = lab_tare_check(R[0], cfg)

    P = build_plate(rec, cfg)
    fs = P.fs
    qc["plate"] = {"noise_sd_N": P.noise_sd_N, "pkres_N": P.pkres_N, "cop_min_N": P.cop_min_N,
                   "drift_N": P.drift_N, "n_zero_anchors": len(P.anchors),
                   "anchor_times_s": [a[0] for a in P.anchors],
                   "fz_baseline_range_N": float(np.ptp([2 * sum(a[1][k] for k in ("fz1", "fz2", "fz3", "fz4"))
                                                         for a in P.anchors]))}
    params = DetectParams()
    trials, det = detect_drop_jumps(P.Fz, fs, P.noise_sd_N, params, pkres_N=P.pkres_N)
    qc["detection"] = {**{k: v for k, v in det.items() if k != "unpaired_bouts"},
                       "threshold_set_by": ("5 N floor" if det["threshold_N"] == params.fixed_N
                                            else "noise (5 SD or peak residual)"),
                       "unpaired_bouts": [[int(a), int(b)] for a, b in det["unpaired_bouts"]],
                       "params": asdict(params)}
    qc["threshold_sensitivity"] = threshold_sensitivity(P.Fz, fs, P.noise_sd_N, trials)
    ax = body_axes(P, cfg["stance_leg"])
    F_ap, F_ml = ax["F_ap"], ax["F_ml"]
    cop_ap, cop_ml = ax["cop_ap"].copy(), ax["cop_ml"].copy()
    nmask = int(round(COP_MASK_S * fs))
    for tr in trials:
        for td in (tr.td1, tr.td2):
            cop_ap[td:td + nmask] = np.nan
            cop_ml[td:td + nmask] = np.nan
    cop_ap_s, cop_ml_s = stab.cop_smooth(cop_ap, fs), stab.cop_smooth(cop_ml, fs)

    # ---------------- body weight: joint estimate, two passes (stance end depends on BW)
    loaded = P.Fz[P.Fz > 100]
    bw = float(np.median(loaded)) if loaded.size else 600.0
    for _ in range(2):
        ses = _stance_ends(P.Fz, fs, trials, bw)
        joint = []
        for tr, se in zip(trials, ses):
            ft = (tr.td2 - tr.to2) / fs
            joint.append(kin.body_weight_joint(P.Fz, fs, tr.td2, se, ft)
                         if (se - tr.td2) / fs >= MIN_STANCE_S else float("nan"))
        if np.isfinite(joint).any():
            bw = float(np.nanmean(joint))
    ses = _stance_ends(P.Fz, fs, trials, bw)
    bw_rows = []
    for tr, se, j in zip(trials, ses, joint):
        q = kin.body_weight_quiet(P.Fz, fs, tr.td2, se)
        bw_rows.append({"trial": tr.number, "bw_joint_N": j, "bw_quiet_N": q["bw_N"], "quiet_sd_N": q["sd_N"],
                        "quiet_window_s": [(q["start"] - tr.td2) / fs, (q["end"] - tr.td2) / fs],
                        "flag": q["flag"]})
    m = bw / G
    bw_quiet = float(np.nanmean([b["bw_quiet_N"] for b in bw_rows]))
    out["body_weight"] = {"session_bw_N": bw, "session_mass_kg": m, "session_bw_quiet_N": bw_quiet,
                          "per_trial": bw_rows,
                          "method": "mean of per-trial joint estimates: zero mean COM velocity over the "
                                    "last 1 s of quiet stance, with v_TD2 = -g FT/2"}
    stance_len = [(se - tr.td2) / fs for tr, se in zip(trials, ses) if (se - tr.td2) / fs >= MIN_STANCE_S]
    common_s = float(np.floor(10 * min(stance_len)) / 10) if stance_len else 0.0
    out["common_window_s"] = common_s

    # ---------------- Trigno streams and their delay
    tg = cfg["trigno"]
    acc_ch = {name: rec.channels[int(k)].counts * tg["acc_g_per_count"] for k, name in tg["acc"].items()}
    fa = rec.channels[int(next(iter(tg["acc"])))].fs
    acc1 = [acc_ch["ACC1_X"], acc_ch["ACC1_Y"], acc_ch["ACC1_Z"]]
    acc2 = [acc_ch["ACC2_X"], acc_ch["ACC2_Y"], acc_ch["ACC2_Z"]]
    tds = [tr.td1 for tr in trials] + [tr.td2 for tr in trials]
    d1 = trigno_delay(acc1, fa, P.Fz, fs, tds)
    d2 = trigno_delay(acc2, fa, P.Fz, fs, tds)
    delay = float(cfg.get("trigno_delay_s", d1["median_event_lag_s"]))
    lags = [p["lag_s"] for p in d1["per_event"] + d2["per_event"]]
    qc["trigno_delay"] = {"ACC1": {k: v for k, v in d1.items() if k not in ("lags_s", "r")},
                          "ACC2": {k: v for k, v in d2.items() if k not in ("lags_s", "r")},
                          "applied_s": delay, "uncertainty_s": 0.030,
                          "per_event_range_s": [float(min(lags)), float(max(lags))],
                          "note": "Delsys documents 48 ms for the legacy Trigno; the data agree within "
                                  "about +/-30 ms, and the two sensors may differ. Applied to EMG and accelerometer."}
    ta = np.arange(len(acc1[0])) / fa - delay

    emg_ch = {v["name"]: rec.channels[int(k)].counts * v["mV_per_count"] for k, v in tg["emg"].items()}
    fe = rec.channels[int(next(iter(tg["emg"])))].fs
    te = np.arange(len(next(iter(emg_ch.values())))) / fe - delay
    emg_proc = {k: emgmod.envelope(x, fe) for k, x in emg_ch.items()}
    qc["emg_clipping_pct"] = {k: 100 * emgmod.clip_fraction(x, tg["emg_range_mV"]) for k, x in emg_ch.items()}

    grav = {}
    for name, axes in (("ACC1", acc1), ("ACC2", acc2)):
        vals = []
        for b in bw_rows:
            tr = trials[b["trial"] - 1]
            a0, a1 = tr.td2 / fs + b["quiet_window_s"][0], tr.td2 / fs + b["quiet_window_s"][1]
            mk = (ta >= a0) & (ta < a1)
            if mk.any():
                vals.append(float(np.linalg.norm([x[mk].mean() for x in axes])))
        grav[name] = {"quiet_stance_gravity_g": vals, "mean_g": float(np.mean(vals)) if vals else float("nan")}
    qc["acc_gravity"] = grav

    def e_idx(t_force, d=delay):
        return int(np.clip(round((t_force + d) * fe), 0, len(te) - 1))
    norm, norm_rect = {}, {}
    w50 = int(round(0.05 * fe))
    for k, p in emg_proc.items():
        mov = np.convolve(p["rect"], np.ones(w50) / w50, mode="same")
        segs = [(p["env"][e_idx(tr.td1 / fs - 0.5):e_idx(tr.off / fs)], mov[e_idx(tr.td1 / fs - 0.5):e_idx(tr.off / fs)])
                for tr in trials]
        norm[k] = float(max(a.max() for a, _ in segs if a.size))
        norm_rect[k] = float(max(b.max() for _, b in segs if b.size))
    out["emg_norm_mV"] = {"envelope_peak": norm, "rectified_50ms_peak": norm_rect}
    emg_sm = {k: emgmod.smoothed(p["rect"], fe, norm_rect[k]) for k, p in emg_proc.items()}
    # smoothing sensitivity for co-contraction (main: 25 ms)
    emg_sm_alt = {w: {k: emgmod.smoothed(p["rect"], fe, norm_rect[k], w / 1000) for k, p in emg_proc.items()}
                  for w in (15, 50)}

    # ---------------- per-trial analysis
    series = {"fs": fs, "t": P.t, "Fz": P.Fz, "F_ap": F_ap, "F_ml": F_ml, "cop_ap": cop_ap_s,
              "cop_ml": cop_ml_s, "fe": fe, "te": te, "fa": fa, "ta": ta,
              "emg_env": {k: p["env"] / norm[k] for k, p in emg_proc.items()}, "emg_sm": emg_sm,
              "emg_raw": emg_ch, "acc": {**{f"ACC1_{c}": a for c, a in zip("XYZ", acc1)},
                                         **{f"ACC2_{c}": a for c, a in zip("XYZ", acc2)}},
              "trials": [],
              "delay_curves": {"ACC1": (d1["lags_s"], d1["r"]), "ACC2": (d2["lags_s"], d2["r"])}}
    out["trials"] = []
    for tr, se in zip(trials, ses):
        ft = (tr.td2 - tr.to2) / fs
        long_enough = (se - tr.td2) / fs >= MIN_STANCE_S
        T: dict = {"number": tr.number, "flags": list(tr.flags),
                   "events_idx": {"td1": tr.td1, "to2": tr.to2, "td2": tr.td2, "stance_end": se,
                                  "off": tr.off},
                   "events_s": {"td1": tr.td1 / fs, "to2": tr.to2 / fs, "td2": tr.td2 / fs,
                                "stance_end": se / fs, "off": tr.off / fs},
                   "step_off_observed": tr.off_observed}
        if not long_enough:
            T["flags"].append("stance shorter than 1.5 s: stability, N1 and N2 skipped")
        dj, djc = kin.drop_jump(P.Fz, fs, tr, bw, F_ap, F_ml)
        ld, ldc = kin.landing(P.Fz, fs, tr, bw, ft, F_ap, F_ml, se)
        T["rebound"] = dj
        T["landing"] = ld
        if long_enough:
            T["impulse_momentum"] = kin.backward_velocity(P.Fz, fs, tr, bw, se)
            T["impulse_momentum"]["jump_height_im_quiet_bw_m"] = \
                kin.backward_velocity(P.Fz, fs, tr, bw_quiet, se)["jump_height_im_m"]
            T["impulse_momentum"]["note"] = ("not independent of flight time: the joint BW is set so that "
                                             "the backward route returns -g FT/2; it checks BW consistency")
        else:
            T["impulse_momentum"] = {}
        T["events_s"]["td1_lowest_com"] = (tr.td1 + djc["i_lowest"]) / fs
        T["events_s"]["td2_lowest_com"] = (tr.td2 + ldc["i_lowest"]) / fs

        # body-weight sensitivity: the same metrics with the quiet-stance BW
        dj_q, _ = kin.drop_jump(P.Fz, fs, tr, bw_quiet, F_ap, F_ml)
        ld_q, _ = kin.landing(P.Fz, fs, tr, bw_quiet, ft, F_ap, F_ml, se)
        T["bw_sensitivity"] = {k: {"joint": dj[k], "quiet": dj_q[k]} for k in
                               ("v_touchdown1_m_s", "effective_drop_height_m", "com_depression_m",
                                "vertical_stiffness_BW_m", "braking_time_s")}
        T["bw_sensitivity"].update({k: {"joint": ld[k], "quiet": ld_q[k]} for k in
                                    ("time_to_lowest_com_s", "landing_com_depression_m", "landing_stiffness_BW_m")})

        # stability (DPSI on the common window and on the available window; TTS kept but flagged)
        ce = tr.td2 + int(round(common_s * fs))
        if long_enough:
            T["dpsi_common"] = stab.dpsi(F_ap, F_ml, P.Fz, fs, tr.td2, ce, bw, dur_s=common_s)
            T["dpsi"] = stab.dpsi(F_ap, F_ml, P.Fz, fs, tr.td2, se, bw)
            T["tts"] = stab.tts_all(F_ap, F_ml, P.Fz, fs, tr.td2, ce, bw)
            T["tts"]["note"] = ("not interpretable: needs >= 10 s of stance; values follow the window length "
                                "(sequential average) or fall at the force peak (polynomial)")
        win = {"td1_20_100ms": (tr.td1 + nmask, tr.td1 + int(0.1 * fs)),
               "td1_20_200ms": (tr.td1 + nmask, tr.td1 + int(0.2 * fs)),
               "td1_contact": (tr.td1 + nmask, tr.to2),
               "td2_20_100ms": (tr.td2 + nmask, tr.td2 + int(0.1 * fs)),
               "td2_20_200ms": (tr.td2 + nmask, tr.td2 + int(0.2 * fs)),
               "td2_dynamic_0.4s_to_end": (tr.td2 + int(0.4 * fs), se),
               "td2_full_to_end": (tr.td2 + nmask, se)}
        T["cop"] = {k: stab.cop_window(cop_ml_s[a:b], cop_ap_s[a:b], fs) for k, (a, b) in win.items()}
        T["cop_windows_idx"] = win

        # EMG at the applied delay, plus +/-20 ms sensitivity for pre-activation
        em = {}
        for k, p in emg_proc.items():
            em[k] = {}
            for evn, ev in (("td1", tr.td1), ("td2", tr.td2)):
                i = e_idx(ev / fs)
                r = emgmod.landing_emg(p["rect"], p["env"], fe, i, norm[k], norm_rect[k])
                seg = emg_ch[k][max(0, i - int(0.15 * fe)):i + int(0.2 * fe)]
                r["clipped_pct_window"] = 100 * emgmod.clip_fraction(seg, tg["emg_range_mV"])
                for dd in (-0.030, 0.030):
                    j = e_idx(ev / fs, delay + dd)
                    r[f"pre150_pct_delay{int(round((delay + dd) * 1000))}ms"] = \
                        100 * emgmod.window_mean(p["rect"], fe, j, -0.150, 0) / norm_rect[k]
                em[k][evn] = r
        T["emg"] = em
        # VL (EMG1) - BF (EMG2) co-contraction before and just after each touchdown
        if {"EMG1", "EMG2"} <= set(emg_sm):
            T["cocontraction"] = {
                evn: {w: emgmod.cocontraction(emg_sm["EMG1"], emg_sm["EMG2"], fe, e_idx(ev / fs), a, b)
                      for w, (a, b) in (("pre150", (-0.150, 0.0)), ("post50", (0.0, 0.050)))}
                for evn, ev in (("td1", tr.td1), ("td2", tr.td2))}
            # sensitivity (full report only): Trigno delay +/-30 ms and 15 or 50 ms smoothing
            sens = {}
            for evn, ev in (("td1", tr.td1), ("td2", tr.td2)):
                for w, (a, b) in (("pre150", (-0.150, 0.0)), ("post50", (0.0, 0.050))):
                    for dd in (-0.030, 0.030):
                        sens[f"{evn}_{w}_delay{int(round((delay + dd) * 1000))}ms"] = emgmod.cocontraction(
                            emg_sm["EMG1"], emg_sm["EMG2"], fe, e_idx(ev / fs, delay + dd), a, b)["cci_pct"]
                    for sm, E in emg_sm_alt.items():
                        sens[f"{evn}_{w}_smooth{sm}ms"] = emgmod.cocontraction(
                            E["EMG1"], E["EMG2"], fe, e_idx(ev / fs), a, b)["cci_pct"]
            T["cocontraction_sensitivity"] = sens

        # accelerometer: clipping only (peaks are capped by the range on every axis)
        A = {}
        for name, axes in (("ACC1", acc1), ("ACC2", acc2)):
            res = accmod.resultant(*axes)
            A[name] = {evn: accmod.impact_peak(res, axes, ta, ev / fs, 0.15, tg["acc_range_g"])
                       for evn, ev in (("td1", tr.td1), ("td2", tr.td2))}
        T["acc"] = A

        S = {"number": tr.number, "td1": tr.td1, "to2": tr.to2, "td2": tr.td2, "se": se, "off": tr.off,
             "v_contact": djc["v"], "z_contact": djc["z"], "v_land": ldc["v"], "z_land": ldc["z"],
             "i_low1": djc["i_lowest"], "i_low2": ldc["i_lowest"]}
        if long_enough:
            # N1: XcoM margin, 0.4 s after TD2 to 0.4 s before the end of quiet stance
            a, b = tr.td2 + int(0.4 * fs), se - int(0.4 * fs)
            n1 = novel.xcom_analysis(F_ap, F_ml, cop_ap_s / 1000, cop_ml_s / 1000, fs, m, a, b, tr.td2, se)
            T["novel_xcom"] = {"window_s": [(a - tr.td2) / fs, (b - tr.td2) / fs],
                               "envelope_ap_mm": [v * 1000 for v in n1["envelope"]["ap"]],
                               "envelope_ml_mm": [v * 1000 for v in n1["envelope"]["ml"]],
                               "by_l": {str(l): {k: v for k, v in d.items() if k not in ("ap", "ml")}
                                        for l, d in n1["by_l"].items()}}
            # N2: continuous stabilisation curve on the common window, with cut-off sensitivity
            sc = novel.stabilisation_curve(F_ap, F_ml, P.Fz, fs, tr.td2, ce, bw)
            ipk = int(round(ld["td2_t_first_peak_s"] * fs))        # fit from the impact peak
            fit = novel.recovery_fit(sc["t"], sc["s"], fs, i0=ipk)
            sens = {}
            for fc in (5.0, 20.0, 40.0):
                sc_ = novel.stabilisation_curve(F_ap, F_ml, P.Fz, fs, tr.td2, ce, bw, fc=fc)
                sens[f"tau_fc{int(fc)}Hz_s"] = novel.recovery_fit(sc_["t"], sc_["s"], fs, n_boot=0, i0=ipk)["tau_s"]
            il = ldc["i_lowest"]
            fit_h = novel.recovery_fit(sc["t"][il:] - sc["t"][il], sc["s_horizontal"][il:], fs, n_boot=0)
            T["novel_tdpsi"] = {"quiet_level": sc["quiet_level"], "tau_s": fit["tau_s"],
                                "tau_ci95_s": fit["tau_ci95_s"], "A": fit["A"], "C": fit["C"],
                                "r2": fit["r2"], "t_peak_s": fit["t_peak_s"], "t95_s": fit["t95_s"],
                                "t_within_2x_quiet_s": novel.stays_below(sc["s_norm"], fs, 2.0),
                                "dpsi_share_first_0.4s_pct": novel.dpsi_share(sc["s"], fs, dur_s=common_s),
                                "tau_horizontal_from_lowest_com_s": fit_h["tau_s"],
                                "r2_horizontal": fit_h["r2"], **sens,
                                "window_s": common_s, "filter_hz": 10.0}
            S.update({"xcom": n1, "stab": sc, "stab_fit": fit})
        out["trials"].append(T)
        series["trials"].append(S)
    # short-stance TTS with the pooled quiet-stance reference of this session
    long_tr = [(tr, se) for tr, se in zip(trials, ses) if (se - tr.td2) / fs >= MIN_STANCE_S]
    if long_tr:
        refs = stab.short_stance_refs(F_ap, F_ml, P.Fz, fs, bw, [se for _, se in long_tr])
        out["tts_reference"] = {"rms_N": refs["rms"], "rov_mean_N": {str(k): v for k, v in refs["rov"].items()},
                                "source": "last 1 s of quiet stance, pooled over the session's trials"}
        for T, (tr, se) in zip(out["trials"], zip(trials, ses)):
            if (se - tr.td2) / fs >= MIN_STANCE_S:
                T["tts_short"] = stab.tts_short_stance(F_ap, F_ml, P.Fz, fs, tr.td2, se, bw, refs)
    # TTS phase (TD2 + 20 ms until all three directions have settled) and the stance after it:
    # COP sample entropy, COP displacement and time outside the pooled quiet-stance zone
    if long_tr:
        zone = stab.quiet_zone(cop_ml_s, cop_ap_s, fs, [se for _, se in long_tr])
        out["cop_quiet_zone"] = {**{k: v for k, v in zone.items() if k != "cov"}, "cov": zone["cov"].tolist(),
                                 "source": "95% ellipse of the last 1 s of every stance, pooled, each about its own mean"}
        for T, S, (tr, se) in zip(out["trials"], series["trials"], zip(trials, ses)):
            v = [(T.get("tts_short") or {}).get(f"tts_rov100ms_{k}_s", np.nan) for k in ("V", "AP", "ML")]
            if not np.all(np.isfinite(v)):
                continue
            t_set = min(tr.td2 + int(round(max(v) * fs)), se - int(0.5 * fs))
            wins = {"td2_20_200ms": T["cop_windows_idx"]["td2_20_200ms"], "td2_tts_phase": (tr.td2 + nmask, t_set),
                    "td2_after_tts": (t_set, se)}
            for k in ("td2_tts_phase", "td2_after_tts"):
                a, b = wins[k]
                T["cop"][k] = stab.cop_window(cop_ml_s[a:b], cop_ap_s[a:b], fs)
                T["cop_windows_idx"][k] = (a, b)
            # entropy: the TTS phase starts at TD2 + 150 ms, after the landing spike (TD2 + 20 ms kept as sensitivity)
            n0 = min(int(round(ENTROPY_START_S * fs)), t_set - tr.td2)
            ewins = {"td2_tts_phase": (tr.td2 + n0, t_set), "td2_after_tts": (t_set, se)}
            ent = {k: entmod.cop_entropy(cop_ml_s[a:b], cop_ap_s[a:b], fs) for k, (a, b) in ewins.items()}
            a, b = ewins["td2_tts_phase"]
            for lab, kw in (("r015", {"r": 0.15}), ("r025", {"r": 0.25}), ("200Hz", {"fs_out": 200.0})):
                e2 = entmod.cop_entropy(cop_ml_s[a:b], cop_ap_s[a:b], fs, **kw)
                ent["td2_tts_phase"].update({f"sampen_{c}_{lab}": e2[f"sampen_{c}"] for c in ("AP", "ML")})
            a, b = wins["td2_tts_phase"]
            e2 = entmod.cop_entropy(cop_ml_s[a:b], cop_ap_s[a:b], fs)
            ent["td2_tts_phase"].update({f"sampen_{c}_from20ms": e2[f"sampen_{c}"] for c in ("AP", "ML")})
            T["cop_entropy"] = {**ent, "tts_phase_s": [n0 / fs, (t_set - tr.td2) / fs]}
            centre = stab.quiet_centre(cop_ml_s, cop_ap_s, fs, se)
            T["cop_zone"] = {"centre_mm": list(centre),
                             "outside_pct": {k: stab.pct_outside_zone(cop_ml_s[a:b], cop_ap_s[a:b], centre, zone)
                                             for k, (a, b) in wins.items()}}
            S["cop_zone_centre"] = centre
        # sensitivity (full report only): 0.5 s and 1.5 s quiet windows for the zone and its centre
        for qs in (0.5, 1.5):
            z_ = stab.quiet_zone(cop_ml_s, cop_ap_s, fs, [se for _, se in long_tr], quiet_s=qs)
            for T, (tr, se) in zip(out["trials"], zip(trials, ses)):
                if "cop_zone" not in T:
                    continue
                c_ = stab.quiet_centre(cop_ml_s, cop_ap_s, fs, se, quiet_s=qs)
                wins = {k: T["cop_windows_idx"][k] for k in ("td2_20_200ms", "td2_tts_phase", "td2_after_tts")}
                T.setdefault("cop_zone_sensitivity", {})[f"quiet_{qs:g}s"] = {
                    k: stab.pct_outside_zone(cop_ml_s[a:b], cop_ap_s[a:b], c_, z_) for k, (a, b) in wins.items()}
        series["cop_zone"] = zone
    # N2: time within 2x of one shared quiet level (trial 2's own quiet level is 2x higher)
    lv = [S["stab"]["quiet_level"] for S in series["trials"] if "stab" in S]
    if lv:
        shared = float(np.mean(lv))
        out["n2_shared_quiet_level"] = shared
        for T, S in zip(out["trials"], series["trials"]):
            if "stab" in S:
                T["novel_tdpsi"]["t_within_2x_shared_s"] = novel.stays_below(S["stab"]["s"] / shared, fs, 2.0)
    out["qc"] = qc
    return _f(out), series


def save_json(obj: dict, path: str) -> None:
    with open(path, "w") as f:
        json.dump(obj, f, indent=1)
