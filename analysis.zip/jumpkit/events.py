"""Contact and flight events for drop jumps, single-leg drop vertical jumps and CMJs.

Detection runs on the zeroed, unfiltered vertical force (filtering smears the edges).
1. A sample is in contact when Fz exceeds the detection threshold max(k_sd * SD, PkRes),
   where SD and PkRes (peak absolute residual) come from the unloaded plate (McMahon et al.
   2018; Smith et al. 2024). A floor (fixed_N) guards against a near-zero threshold.
   Short spikes and gaps are removed (debounce).
2. Each edge is refined to the noise floor: touchdown moves back to the last sample at or
   below 2 SD, and take-off moves forward to the first sample at or below 2 SD. This
   removes most of the delay that a threshold adds to every event (delay = F_th / slope).
3. Contact bouts are paired into trials by their durations.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .signals import bouts


@dataclass
class DetectParams:
    fixed_N: float = 5.0           # floor for the threshold
    k_sd: float = 5.0              # noise part: k_sd * SD of unloaded Fz
    refine_k_sd: float = 2.0       # edge refinement level
    max_refine_s: float = 0.030    # largest allowed edge shift
    min_contact_s: float = 0.030   # shorter loaded runs are spikes
    min_flight_s: float = 0.050    # shorter unloaded gaps are dropouts
    dj_contact_s: tuple = (0.10, 1.20)   # first contact of a drop jump
    dj_flight_s: tuple = (0.10, 1.00)    # rebound flight
    min_landing_s: float = 0.50          # second contact must last at least this long
    min_pre_unloaded_s: float = 0.30     # the plate must be empty before a trial


@dataclass
class Trial:
    number: int
    td1: int                 # first touchdown (sample index)
    to2: int                 # rebound take-off
    td2: int                 # second touchdown
    off: int                 # step-off at the end of the landing stance, or last sample
    off_observed: bool       # False when the record ends before the step-off
    threshold_N: float
    flags: list = field(default_factory=list)


def _clean(mask: np.ndarray, fs: float, p: DetectParams) -> np.ndarray:
    m = mask.copy()
    for s, e in bouts(~m):                       # close short gaps (not at the edges)
        if s > 0 and e < m.size and (e - s) / fs < p.min_flight_s:
            m[s:e] = True
    for s, e in bouts(m):                        # remove short spikes
        if (e - s) / fs < p.min_contact_s:
            m[s:e] = False
    return m


def refine_edges(Fz: np.ndarray, s: int, e: int, floor_N: float, max_shift: int,
                 lo: int = 0, hi: int | None = None) -> tuple[int, int]:
    """Move a contact bout's edges out to the noise floor, by at most max_shift samples
    and never past the neighbouring bouts (lo, hi)."""
    hi = Fz.size if hi is None else hi
    i = s
    while i > max(lo, s - max_shift) and Fz[i - 1] > floor_N:
        i -= 1
    j = e
    while j < min(hi, e + max_shift) and Fz[j] > floor_N:
        j += 1
    return i, j


def contact_bouts(Fz: np.ndarray, fs: float, noise_sd: float, p: DetectParams | None = None,
                  thr_N: float | None = None, pkres_N: float = 0.0) -> tuple[list, float]:
    p = p or DetectParams()
    thr = thr_N if thr_N is not None else max(p.fixed_N, p.k_sd * noise_sd, pkres_N)
    m = _clean(Fz > thr, fs, p)
    floor = p.refine_k_sd * noise_sd
    bb = bouts(m)
    ms = int(round(p.max_refine_s * fs))
    out = []
    for k, (s, e) in enumerate(bb):
        lo = bb[k - 1][1] if k > 0 else 0
        hi = bb[k + 1][0] if k + 1 < len(bb) else Fz.size
        out.append(refine_edges(Fz, s, e, floor, ms, lo, hi))
    return out, thr


def detect_drop_jumps(Fz: np.ndarray, fs: float, noise_sd: float, p: DetectParams | None = None,
                      thr_N: float | None = None, pkres_N: float = 0.0) -> tuple[list[Trial], dict]:
    """Find drop-jump trials: empty plate, contact 1, flight, contact 2 (landing stance)."""
    p = p or DetectParams()
    cb, thr = contact_bouts(Fz, fs, noise_sd, p, thr_N, pkres_N)
    trials, used = [], set()
    for k in range(len(cb) - 1):
        (s1, e1), (s2, e2) = cb[k], cb[k + 1]
        ct, ft, land = (e1 - s1) / fs, (s2 - e1) / fs, (e2 - s2) / fs
        pre = s1 / fs if k == 0 else (s1 - cb[k - 1][1]) / fs
        if not (p.dj_contact_s[0] <= ct <= p.dj_contact_s[1]):
            continue
        if not (p.dj_flight_s[0] <= ft <= p.dj_flight_s[1]):
            continue
        if land < p.min_landing_s or pre < p.min_pre_unloaded_s or k in used:
            continue
        flags = []
        observed = e2 < Fz.size
        if not observed:
            flags.append("record_ends_during_landing_stance")
        trials.append(Trial(number=len(trials) + 1, td1=s1, to2=e1, td2=s2, off=min(e2, Fz.size - 1),
                            off_observed=observed, threshold_N=thr, flags=flags))
        used.update({k, k + 1})
    info = {"threshold_N": thr, "noise_sd_N": noise_sd, "pkres_N": pkres_N, "n_contact_bouts": len(cb),
            "unpaired_bouts": [b for i, b in enumerate(cb) if i not in used]}
    return trials, info


def threshold_sensitivity(Fz: np.ndarray, fs: float, noise_sd: float, trials: list,
                          thresholds=(5.0, 10.0, 20.0, 50.0)) -> list[dict]:
    """Contact and flight time of each detected trial at fixed thresholds, without edge
    refinement. Bouts are matched to trials by the nearest first touchdown."""
    rows = []
    for thr in thresholds:
        m = _clean(Fz > thr, fs, DetectParams())
        cb = bouts(m)
        for tr in trials:
            k = int(np.argmin([abs(s - tr.td1) for s, _ in cb]))
            if k + 1 >= len(cb) or abs(cb[k][0] - tr.td1) > 0.1 * fs:
                continue
            (s1, e1), (s2, _e2) = cb[k], cb[k + 1]
            rows.append({"trial": tr.number, "threshold_N": thr, "td1_s": s1 / fs,
                         "contact_ms": 1000 * (e1 - s1) / fs, "flight_ms": 1000 * (s2 - e1) / fs})
    return rows
