"""Standardised centre-of-pressure (COP) heatmaps.

The legacy heatmaps used a different axis range, bin size and colour scale for every
trial, so two maps could not be compared by eye. Here every panel uses:
- the same physical extent in mm, set in config, not taken from the data,
- the same square bin size, equal axis scaling and the same panel size,
- dwell time as a percentage of the window duration (Gaussian smoothing of 1 bin),
- one colour scale per column (the same window type in every trial), or one for the whole
  figure (shared="all"). Empty bins are white.
Orientation: top view, ML on x (lateral to the right), AP on y (anterior up). The
front-facing video is the mirror image of this view in ML.
"""
from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Ellipse
from scipy.ndimage import gaussian_filter

from .signals import ellipse95

CMAP = plt.get_cmap("viridis_r").with_extremes(bad="white")


def dwell_map(ml: np.ndarray, ap: np.ndarray, extent: tuple, bin_mm: float = 2.0,
              smooth_bins: float = 1.0) -> np.ndarray:
    """2-D histogram of COP samples as % of window time per bin (NaN samples dropped)."""
    ok = np.isfinite(ml) & np.isfinite(ap)
    x0, x1, y0, y1 = extent
    nx, ny = int(round((x1 - x0) / bin_mm)), int(round((y1 - y0) / bin_mm))
    H, _, _ = np.histogram2d(ap[ok], ml[ok], bins=[ny, nx], range=[[y0, y1], [x0, x1]])
    H = 100.0 * H / max(ok.sum(), 1)
    return gaussian_filter(H, smooth_bins) if smooth_bins else H


def common_extent(points: list, margin_mm: float = 10.0, step_mm: float = 10.0) -> tuple:
    """One square-binned extent that holds every (ml, ap) array in points."""
    ml = np.concatenate([p[0][np.isfinite(p[0])] for p in points] + [np.zeros(1)])
    ap = np.concatenate([p[1][np.isfinite(p[1])] for p in points] + [np.zeros(1)])
    lo = lambda v: np.floor((v.min() - margin_mm) / step_mm) * step_mm
    hi = lambda v: np.ceil((v.max() + margin_mm) / step_mm) * step_mm
    return (lo(ml), hi(ml), lo(ap), hi(ap))


def draw(ax, ml, ap, extent, vmax, title="", ellipse=False, bin_mm=2.0, path=True):
    H = dwell_map(ml, ap, extent, bin_mm)
    H = np.ma.masked_less_equal(H, 0.002 * max(vmax, 1e-9))
    im = ax.imshow(H, origin="lower", extent=extent, cmap=CMAP, vmin=0, vmax=vmax,
                   interpolation="nearest", aspect="equal")
    ok = np.isfinite(ml) & np.isfinite(ap)
    if path and ok.any():
        ax.plot(ml[ok], ap[ok], color="#dc2626", lw=0.5, alpha=0.5)
        ax.plot(ml[ok][0], ap[ok][0], "o", ms=5, mfc="#16a34a", mec="black", mew=0.6)
        ax.plot(ml[ok][-1], ap[ok][-1], "s", ms=5, mfc="#dc2626", mec="black", mew=0.6)
    if ellipse and ok.sum() > 5:
        e = ellipse95(ml, ap)
        ax.add_patch(Ellipse((e["cx"], e["cy"]), 2 * e["semi_major_mm"], 2 * e["semi_minor_mm"],
                             angle=e["angle_deg"], fill=False, ec="#dc2626", lw=1.1, ls="--"))
    ax.set_xlim(extent[0], extent[1])
    ax.set_ylim(extent[2], extent[3])
    ax.set_title(title, fontsize=9)
    ax.tick_params(labelsize=8)
    ax.set_facecolor("white")
    return im


def heatmap_grid(panels: list, out_path: str, col_titles: list, row_titles: list,
                 extent: tuple, bin_mm: float = 2.0, panel_in: float = 2.6,
                 suptitle: str = "", ellipse_cols=(), shared: str = "column", zone: dict | None = None,
                 notes: list | None = None) -> dict:
    """panels[r][c] = (ml, ap). One extent; one colour scale per column (or for all).

    zone: optional ellipse (semi_major_mm, semi_minor_mm, angle_deg) drawn at (0, 0) on every
    panel as the acceptable zone. notes[r][c]: optional text in each panel's lower-right corner.
    """
    nr, nc = len(panels), len(panels[0])
    vmax = []
    for c in range(nc):
        v = [dwell_map(panels[r][c][0], panels[r][c][1], extent, bin_mm).max() for r in range(nr)]
        vmax.append(float(np.nanmax(v)) if v and np.nanmax(v) > 0 else 1.0)
    if shared == "all":
        vmax = [max(vmax)] * nc
    w = extent[1] - extent[0]
    h = extent[3] - extent[2]
    fig, axes = plt.subplots(nr, nc, figsize=(panel_in * nc + 1.2, panel_in * nr * h / w + 0.9),
                             squeeze=False, constrained_layout=True)
    ims = []
    for r in range(nr):
        for c in range(nc):
            ml, ap = panels[r][c]
            im = draw(axes[r][c], ml, ap, extent, vmax[c],
                      title=f"{row_titles[r]} | {col_titles[c]}", ellipse=c in ellipse_cols,
                      bin_mm=bin_mm)
            if zone:
                axes[r][c].add_patch(Ellipse((0, 0), 2 * zone["semi_major_mm"], 2 * zone["semi_minor_mm"],
                                             angle=zone["angle_deg"], fill=False, ec="#0f766e", lw=1.6))
            if notes and notes[r][c]:
                axes[r][c].text(0.97, 0.03, notes[r][c], transform=axes[r][c].transAxes, ha="right", va="bottom",
                                fontsize=7.5, bbox={"fc": "white", "ec": "#9ca3af", "lw": 0.5, "pad": 1.5})
            if r == nr - 1:
                axes[r][c].set_xlabel("ML (mm), lateral →", fontsize=8)
            if c == 0:
                axes[r][c].set_ylabel("AP (mm), anterior ↑", fontsize=8)
            ims.append(im)
    for c in range(nc):
        cb = fig.colorbar(ims[(nr - 1) * nc + c], ax=[axes[r][c] for r in range(nr)],
                          shrink=0.6, location="bottom", pad=0.02)
        cb.set_label(f"% of window per {bin_mm:g} mm bin", fontsize=8)
        cb.ax.tick_params(labelsize=8)
    if suptitle:
        fig.suptitle(suptitle, fontsize=10)
    key = [Line2D([], [], color="#dc2626", lw=0.8, alpha=0.6, label="COP path"),
           Line2D([], [], ls="", marker="o", ms=6, mfc="#16a34a", mec="black", label="start of window"),
           Line2D([], [], ls="", marker="s", ms=6, mfc="#dc2626", mec="black", label="end of window"),
           plt.Rectangle((0, 0), 1, 1, fc="white", ec="#9ca3af", label="white: no COP samples")]
    if ellipse_cols:
        key.append(Line2D([], [], color="#dc2626", ls="--", lw=1.1, label="95% confidence ellipse"))
    if zone:
        key.append(Line2D([], [], color="#0f766e", lw=1.6, label="acceptable zone (quiet stance, 95%)"))
    fig.legend(handles=key, loc="outside lower center", ncol=len(key) if nc >= 4 else 3, fontsize=8, frameon=False)
    fig.savefig(out_path, dpi=160)
    plt.close(fig)
    return {"extent_mm": extent, "vmax_pct": vmax, "bin_mm": bin_mm, "shared": shared}
