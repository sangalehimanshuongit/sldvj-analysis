"""Trigno accelerometer: gravity check, impact timing and clock alignment.

The legacy Trigno accelerometer saturates at about +/-1.5 g, so peak impact values are
lower bounds. The impact onset is still sharp. It gives an independent check of the
time alignment between the Trigno stream and the PowerLab force stream.
"""
from __future__ import annotations

import numpy as np

from .signals import bouts


def resultant(ax: np.ndarray, ay: np.ndarray, az: np.ndarray) -> np.ndarray:
    return np.sqrt(ax ** 2 + ay ** 2 + az ** 2)


def gravity_check(a_res: np.ndarray, quiet_mask: np.ndarray) -> dict:
    q = a_res[quiet_mask]
    return {"quiet_mean_g": float(np.mean(q)), "quiet_sd_g": float(np.std(q))}


def clipped(a: np.ndarray, range_g: float = 1.5, frac: float = 0.98) -> np.ndarray:
    return np.abs(a) >= frac * range_g


def impact_onset(a_res: np.ndarray, t: np.ndarray, t_ref: float, search_s: float = 0.25,
                 base_s: float = 0.3, k_sd: float = 6.0) -> float:
    """First time near t_ref where |a - baseline| leaves the baseline band.

    Searches [t_ref - search_s, t_ref + search_s]. The baseline is taken just before.
    """
    a = np.searchsorted(t, t_ref - search_s - base_s)
    b = np.searchsorted(t, t_ref - search_s)
    c = np.searchsorted(t, t_ref + search_s)
    if b - a < 5:
        return float("nan")
    base = a_res[a:b]
    mu, sd = float(np.median(base)), float(np.std(base))
    dev = np.abs(a_res[b:c] - mu) > max(k_sd * sd, 0.25)
    runs = [s for s, e in bouts(dev) if e - s >= 2]
    return float(t[b + runs[0]]) if runs else float("nan")


def impact_peak(a_res: np.ndarray, axes: list, t: np.ndarray, t0: float, dur_s: float = 0.15,
                range_g: float = 1.5) -> dict:
    """Peak resultant after t0, and how many samples had any axis at the range limit."""
    a = np.searchsorted(t, t0)
    b = np.searchsorted(t, t0 + dur_s)
    seg = a_res[a:b]
    if seg.size == 0:
        return {"peak_g": float("nan"), "clipped_samples": 0, "t_peak_s": float("nan")}
    clip = np.zeros(b - a, bool)
    for ax in axes:
        clip |= clipped(ax[a:b], range_g)
    return {"peak_g": float(seg.max()), "clipped_samples": int(clip.sum()),
            "t_peak_s": float(t[a + int(np.argmax(seg))] - t0)}
