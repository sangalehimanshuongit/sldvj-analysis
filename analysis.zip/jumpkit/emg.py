"""Surface EMG around landings (Delsys Trigno through LabChart).

Processing: remove the mean, band-pass 20-450 Hz (4th-order Butterworth, zero lag),
full-wave rectify, then a 6 Hz low-pass linear envelope. Amplitudes are normalised to
the peak envelope across all trials (peak-dynamic normalisation, as no MVC was recorded).
onset_before (TKEO, Li et al. 2007; Solnik et al. 2010) is kept for tasks with a true rest
baseline. It is not used for drop jumps (see landing_emg).
"""
from __future__ import annotations

import numpy as np

from .signals import bandpass, bouts, lowpass


def clip_fraction(x_mV: np.ndarray, range_mV: float, frac: float = 0.995) -> float:
    return float(np.mean(np.abs(x_mV) >= frac * range_mV))


def envelope(x_mV: np.ndarray, fs: float, lo: float = 20.0, hi: float = 450.0,
             fc_env: float = 6.0) -> dict:
    x = np.asarray(x_mV, float) - np.mean(x_mV)
    bp = bandpass(x, fs, lo, hi)
    rect = np.abs(bp)
    env = lowpass(rect, fs, fc_env)
    tk = np.zeros_like(bp)
    tk[1:-1] = bp[1:-1] ** 2 - bp[:-2] * bp[2:]
    tk_env = lowpass(np.abs(tk), fs, 50.0)
    return {"bp": bp, "rect": rect, "env": env, "tkeo": tk_env}


def onset_before(tkeo: np.ndarray, fs: float, ref: int, search_s: float = 0.5,
                 base_s: float = 0.2, k_sd: float = 8.0, hold_s: float = 0.025) -> dict:
    """Last onset before index ref (e.g. touchdown).

    Baseline = the quietest base_s window in the search_s + base_s period before ref.
    Onset = start of the run that is above mean + k_sd * SD for at least hold_s and is
    still above at ref (or the latest such run before ref).
    """
    w = int(round(base_s * fs))
    a = max(0, ref - int(round((search_s + base_s) * fs)))
    seg = tkeo[a:ref]
    if seg.size < 2 * w:
        return {"onset_idx": None}
    starts = range(0, seg.size - w, max(1, w // 4))
    j = min(starts, key=lambda i: np.mean(seg[i:i + w]))
    mu, sd = float(np.mean(seg[j:j + w])), float(np.std(seg[j:j + w]))
    thr = mu + k_sd * sd
    hold = int(round(hold_s * fs))
    runs = [(s, e) for s, e in bouts(seg > thr) if e - s >= hold and s > j + w]
    if not runs:
        return {"onset_idx": None, "threshold": thr}
    s, _ = runs[-1]
    # merge back across short sub-threshold dips (< hold) into earlier runs
    for s2, e2 in reversed(runs[:-1]):
        if s - e2 < hold:
            s = s2
        else:
            break
    return {"onset_idx": a + s, "threshold": thr, "baseline_mean": mu, "baseline_sd": sd}


def window_mean(env: np.ndarray, fs: float, ref: int, t0: float, t1: float) -> float:
    a, b = ref + int(round(t0 * fs)), ref + int(round(t1 * fs))
    a, b = max(0, a), min(len(env), b)
    return float(np.mean(env[a:b])) if b > a else float("nan")


def landing_emg(rect: np.ndarray, env: np.ndarray, fs: float, td: int, norm: float, norm_rect: float,
                pre_s=(0.100, 0.150), post_s: float = 0.200) -> dict:
    """Window means and peak around one touchdown (td in EMG samples).

    Window means use the rectified band-passed signal, because a zero-lag 6 Hz envelope
    smears the landing burst back into the pre-activation window and cannot resolve the
    30-60 ms window. Window means are % of the peak 50 ms moving mean of the rectified signal
    (norm_rect); the envelope peak is % of the peak envelope (norm). Both peaks are taken over
    all trials of the session.
    Onsets are not reported: the muscle is already active on the box before TD1, and the
    TD2 search would run through contact 1, so neither has a rest baseline.
    """
    seg = env[td:td + int(round(post_s * fs))]
    ipk = int(np.argmax(seg)) if seg.size else 0
    return {
        f"pre{int(pre_s[0]*1000)}_pct": 100 * window_mean(rect, fs, td, -pre_s[0], 0) / norm_rect,
        f"pre{int(pre_s[1]*1000)}_pct": 100 * window_mean(rect, fs, td, -pre_s[1], 0) / norm_rect,
        "slr_30_60ms_pct": 100 * window_mean(rect, fs, td, 0.030, 0.060) / norm_rect,
        "post50_pct": 100 * window_mean(rect, fs, td, 0, 0.050) / norm_rect,
        f"post{int(post_s*1000)}_pct": 100 * window_mean(rect, fs, td, 0, post_s) / norm_rect,
        "peak_post_pct": 100 * float(seg[ipk]) / norm if seg.size else float("nan"),
        "t_peak_post_s": ipk / fs,
    }


def smoothed(rect: np.ndarray, fs: float, norm_rect: float, win_s: float = 0.025) -> np.ndarray:
    """Rectified EMG, centred moving mean over win_s, as a fraction of norm_rect."""
    w = max(1, int(round(win_s * fs)))
    return np.convolve(rect, np.ones(w) / w, mode="same") / norm_rect


def cocontraction(a: np.ndarray, b: np.ndarray, fs: float, td: int, t0: float, t1: float) -> dict:
    """Co-contraction of two normalised EMG signals in [td + t0, td + t1) (EMG samples).

    CCI = 200 * sum(min(a, b)) / sum(a + b) (%), the common area over the total area
    (Falconer & Winter 1985): 100% = equal activity, 0% = only one muscle active.
    ratio_b_a = mean(b) / mean(a).
    """
    i, j = max(0, td + int(round(t0 * fs))), min(len(a), td + int(round(t1 * fs)))
    x, y = a[i:j], b[i:j]
    tot = float(np.sum(x + y))
    if x.size == 0 or tot <= 0:
        return {"cci_pct": float("nan"), "ratio_b_a": float("nan")}
    return {"cci_pct": 200.0 * float(np.sum(np.minimum(x, y))) / tot,
            "ratio_b_a": float(np.mean(y) / np.mean(x)) if np.mean(x) > 0 else float("nan")}
