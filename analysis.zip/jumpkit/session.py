"""Per-session settings: config overrides, output names and the video offset from metadata.

The config file holds lab-wide values at the top level and session values under
"sessions", keyed by the .adicht file stem (for example "sdvj_1234_AB"). Session values
override the top level. Command-line values override both.
"""
from __future__ import annotations

import copy
import json
import os
import re
import subprocess
from datetime import datetime

SESSION_KEYS = ("record", "stance_leg", "video", "video_coarse_offset_s", "pose_roi", "drop_box_height_m")


def file_stem(path: str) -> str:
    return os.path.splitext(os.path.basename(path))[0]


def load_config(path: str, adicht: str | None = None, overrides: dict | None = None) -> dict:
    """Merge the lab-wide config, the session block for this file and any overrides (None is skipped)."""
    base = json.load(open(path))
    sessions = base.pop("sessions", {})
    cfg = copy.deepcopy(base)
    if adicht:
        cfg.update(copy.deepcopy(sessions.get(file_stem(adicht), {})))
    cfg.update({k: v for k, v in (overrides or {}).items() if v is not None})
    for k in ("record", "stance_leg"):
        if k not in cfg:
            raise KeyError(f"'{k}' is not set for {file_stem(adicht or '')}: add it under 'sessions' or pass it.")
    cfg["stance_leg"] = str(cfg["stance_leg"]).upper()
    return cfg


def session_code(path: str) -> dict:
    """Parse 'sdvj_1234_AB.adicht' into task, participant code and session code.

    The session code stays a raw label. The analyst is blind to the cycle phase, so it is never interpreted.
    """
    m = re.match(r"(?P<task>[a-z]+)_(?P<id>\d+)_(?P<session>[A-Za-z0-9]+)", os.path.basename(path))
    if not m:
        return {"task": "", "code": "", "session": ""}
    return {"task": m["task"], "code": m["id"], "session": m["session"]}


def suffix(path: str) -> str:
    """Output-name suffix, '<session>_<participant>' (AB_1234), or the file stem if the name does not parse."""
    sc = session_code(path)
    return f"{sc['session']}_{sc['code']}" if sc["code"] else re.sub(r"[^A-Za-z0-9]+", "_", file_stem(path))


def video_creation_utc(video_path: str) -> datetime | None:
    """Container creation time (ffprobe format tag), or None if the file has none."""
    from .video import _tool
    try:
        out = subprocess.run([_tool("ffprobe"), "-v", "error", "-show_entries", "format_tags=creation_time",
                              "-of", "json", video_path], capture_output=True, text=True, check=True).stdout
        s = json.loads(out).get("format", {}).get("tags", {}).get("creation_time")
    except (subprocess.CalledProcessError, FileNotFoundError, ValueError):
        return None
    return datetime.fromisoformat(s.replace("Z", "+00:00")) if s else None


def coarse_video_offset_s(video_path: str, record_start_utc: str) -> float | None:
    """video_time = force_time + offset, from the record start minus the video creation time.

    Both clocks are the lab PC's. The result is only a starting point: the run refines it by
    cross-correlation and foot-contact transitions."""
    v = video_creation_utc(video_path)
    if v is None:
        return None
    return round((datetime.fromisoformat(record_start_utc) - v).total_seconds(), 3)
