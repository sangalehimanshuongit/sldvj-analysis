"""Sample entropy of the centre of pressure (COP) after landing.

SampEn(m, r) = -ln(A / B): B counts pairs of length-m templates within r (Chebyshev
distance, self-matches excluded), A the same pairs extended to m + 1 (Richman & Moorman
2000). It is computed on COP velocity, as Ramdani et al. (2009) advise for postural sway,
at 100 Hz (the COP is already low-passed at 20 Hz), with m = 2 and r = 0.2 x SD of the window.
Low SampEn = a more regular, predictable pattern; high = a less predictable one. It does not
mean better or worse balance (Stergiou & Decker 2011).
"""
from __future__ import annotations

import numpy as np


def sample_entropy(x: np.ndarray, m: int = 2, r: float = 0.2) -> float:
    """SampEn of x with tolerance r x SD(x). NaN if x is too short or no template matches."""
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    n = x.size
    if n < m + 10:
        return float("nan")
    tol = r * np.std(x)
    if tol <= 0:
        return float("nan")

    def count(mm):
        t = np.lib.stride_tricks.sliding_window_view(x, mm)[: n - m]      # same n - m templates for m and m + 1
        d = np.max(np.abs(t[:, None, :] - t[None, :, :]), axis=2)
        return (np.sum(d <= tol) - len(t)) / 2

    b, a = count(m), count(m + 1)
    return float(-np.log(a / b)) if a > 0 and b > 0 else float("nan")


def cop_velocity(cop_mm: np.ndarray, fs: float, fs_out: float = 100.0) -> np.ndarray:
    """COP velocity (mm/s) at fs_out from a low-passed COP sampled at fs."""
    k = max(1, int(round(fs / fs_out)))
    c = cop_mm[::k]
    return np.diff(c) * (fs / k)


def cop_entropy(ml_mm: np.ndarray, ap_mm: np.ndarray, fs: float, m: int = 2, r: float = 0.2,
                fs_out: float = 100.0) -> dict:
    """SampEn of AP and ML COP velocity, and the AP and ML displacement (range) in the same window."""
    out = {}
    for k, c in (("AP", ap_mm), ("ML", ml_mm)):
        ok = c[np.isfinite(c)]
        v = cop_velocity(ok, fs, fs_out)
        out[f"sampen_{k}"] = sample_entropy(v, m, r)
        out[f"range_{k}_mm"] = float(np.ptp(ok)) if ok.size else float("nan")
        out[f"n_{k}"] = int(v.size)
    return out
