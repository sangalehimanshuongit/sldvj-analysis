"""Extra figures for the results-only report: trial overlays, COM, loading, stability,
COP, EMG and video kinematics. Same style as figures.py; every figure carries its own key.

Trial colours: trial 1 blue, trial 2 green, trial 3 orange (figures.TRIAL_COLOURS).
Times are seconds from the event named on the x axis. Forces are in body weights (BW).
"""
from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

from .figures import C, EV_STYLE, tcol
from .signals import lowpass
from .stability import rov_curve

MK = {"first": "o", "max": "D", "low": "X", "to": "|"}


def _trial_handles(res, dots=False, bars=False):
    if bars:
        return [Patch(fc=tcol(k), ec="black", lw=0.5, label=f"Trial {T['number']}") for k, T in enumerate(res["trials"])]
    if dots:
        return [Line2D([], [], ls="", marker="o", mfc=tcol(k), mec="black", ms=7, label=f"Trial {T['number']}")
                for k, T in enumerate(res["trials"])]
    return [Line2D([], [], color=tcol(k), lw=1.6, label=f"Trial {T['number']}") for k, T in enumerate(res["trials"])]


def _marker_handles(items):
    return [Line2D([], [], ls="", marker=m, ms=7 if m != "|" else 10, mfc="white", mec="black", mew=1.2, label=lab)
            for m, lab in items]


def _save(fig, path, handles=None, ncol=None, title=None):
    if handles:
        fig.legend(handles=handles, loc="lower center", ncol=ncol or len(handles), fontsize=8, frameon=False,
                   title=title, title_fontsize=8)
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def contact_overlay(ser, res, path):
    """Fz of the three trials aligned at TD1 (contact 1) and TD2 (landing); bottom row: first 150 ms,
    with the 0-50 ms window (impulse) shaded."""
    fs, Fz = ser["fs"], ser["Fz"]
    bw = res["body_weight"]["session_bw_N"]
    fig, ax = plt.subplots(2, 2, figsize=(11, 7))
    spec = [("td1", "rebound", None, "Contact 1 (drop landing and rebound), aligned at TD1"),
            ("td2", "landing", 0.9, "Landing after the rebound, first 0.9 s, aligned at TD2")]
    for j, (ev, sec, dur, title) in enumerate(spec):
        ax[1][j].axvspan(0, 0.05, color="#fde68a", alpha=0.55, lw=0)
        for k, (T, S) in enumerate(zip(res["trials"], ser["trials"])):
            i0 = S[ev]
            end = S["to2"] + 1 if dur is None else i0 + int(dur * fs)
            seg = Fz[i0 - int(0.02 * fs):end] / bw
            t = np.arange(seg.size) / fs - 0.02
            t2 = T[sec][f"{ev}_t_max_peak_s"]
            tl = T["events_s"][f"{ev}_lowest_com"] - T["events_s"][ev]
            for a, lim in ((ax[0][j], None), (ax[1][j], 0.15)):
                a.plot(t, seg, color=tcol(k), lw=1.1)
                a.plot(t2, Fz[i0 + int(round(t2 * fs))] / bw, MK["max"], mfc=tcol(k), mec="black", ms=7)
                if lim is None:
                    a.plot(tl, Fz[i0 + int(round(tl * fs))] / bw, MK["low"], mfc=tcol(k), mec="black", ms=8)
                    if ev == "td1":
                        a.plot((S["to2"] - i0) / fs, 0, MK["to"], color=tcol(k), ms=14, mew=2)
        for a in ax[:, j]:
            a.axhline(1, color="#9ca3af", lw=0.7)
            a.set_ylabel("Vertical GRF (BW)")
        ax[0][j].set_title(title, fontsize=9.5)
        ax[0][j].set_xlabel(f"Time from {ev.upper()} (s)")
        ax[1][j].set_xlim(-0.02, 0.15)
        ax[1][j].set_title(f"First 150 ms after {ev.upper()}", fontsize=9.5)
        ax[1][j].set_xlabel(f"Time from {ev.upper()} (s)")
    hd = _trial_handles(res) + [Line2D([], [], color="#9ca3af", lw=0.7, label="1 BW"),
                                Patch(fc="#fde68a", alpha=0.55, label="0-50 ms: vertical impulse window")] + _marker_handles(
        [(MK["max"], "peak vertical force"), (MK["low"], "lowest COM"), (MK["to"], "take-off (TO2)")])
    fig.tight_layout(rect=(0, 0.06, 1, 1))
    _save(fig, path, hd, ncol=7)


def com_overlay(ser, res, path):
    """COM vertical velocity and displacement from impulse-momentum, contact 1 and landing."""
    fs = ser["fs"]
    fig, ax = plt.subplots(2, 2, figsize=(11, 6.4), sharex="col")
    for k, (T, S) in enumerate(zip(res["trials"], ser["trials"])):
        for j, (v, z, il, extra) in enumerate(((S["v_contact"], S["z_contact"], S["i_low1"], None),
                                               (S["v_land"], S["z_land"], S["i_low2"], 0.2))):
            n = v.size if extra is None else min(v.size, il + int(extra * fs))
            t = np.arange(n) / fs
            ax[0][j].plot(t, v[:n], color=tcol(k), lw=1.2)
            ax[1][j].plot(t, 100 * z[:n], color=tcol(k), lw=1.2)
            ax[0][j].plot(il / fs, v[il], MK["low"], mfc=tcol(k), mec="black", ms=8)
            ax[1][j].plot(il / fs, 100 * z[il], MK["low"], mfc=tcol(k), mec="black", ms=8)
            if extra is None:
                ax[0][j].plot(t[-1], v[n - 1], MK["to"], color=tcol(k), ms=14, mew=2)
                ax[1][j].plot(t[-1], 100 * z[n - 1], MK["to"], color=tcol(k), ms=14, mew=2)
    for j, ev in enumerate(("TD1", "TD2")):
        ax[0][j].axhline(0, color="#6b7280", lw=0.8)
        ax[1][j].axhline(0, color="#6b7280", lw=0.8)
        ax[1][j].set_xlabel(f"Time from {ev} (s)")
    ax[0][0].set_title("Contact 1: TD1 to take-off (TO2)", fontsize=9.5)
    ax[0][1].set_title("Landing: TD2 to 0.2 s after the lowest COM", fontsize=9.5)
    ax[0][0].set_ylabel("COM velocity (m/s), up +")
    ax[1][0].set_ylabel("COM displacement (cm)")
    hd = _trial_handles(res) + [Line2D([], [], color="#6b7280", lw=0.8, label="zero")] + _marker_handles(
        [(MK["low"], "lowest COM (velocity = 0)"), (MK["to"], "take-off (TO2)")])
    fig.tight_layout(rect=(0, 0.06, 1, 1))
    _save(fig, path, hd)


def force_com_loops(ser, res, path):
    """Vertical force against COM lowering. Stiffness = peak force / peak COM lowering (dashed line)."""
    fs, Fz = ser["fs"], ser["Fz"]
    bw = res["body_weight"]["session_bw_N"]
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.6))
    for k, (T, S) in enumerate(zip(res["trials"], ser["trials"])):
        for j, (i0, z, il, n) in enumerate(((S["td1"], S["z_contact"], S["i_low1"], S["z_contact"].size),
                                            (S["td2"], S["z_land"], S["i_low2"], S["i_low2"] + int(0.3 * fs)))):
            d = -100 * z[:n]
            f = Fz[i0:i0 + n] / bw
            ip = int(np.argmax(f[:il + 1]))
            ax[j].plot(d, f, color=tcol(k), lw=1.1)
            ax[j].plot([0, d[il]], [0, f[ip]], color=tcol(k), lw=1.0, ls="--")
            ax[j].plot([d[ip], d[il]], [f[ip], f[ip]], color=tcol(k), lw=0.8, ls=":")
            ax[j].plot(d[ip], f[ip], MK["max"], mfc=tcol(k), mec="black", ms=7)
            ax[j].plot(d[il], f[il], MK["low"], mfc=tcol(k), mec="black", ms=8)
    ax[0].set_title("Contact 1: TD1 to TO2", fontsize=9.5)
    ax[1].set_title("Landing: TD2 to 0.3 s after the lowest COM", fontsize=9.5)
    for a in ax:
        a.set_xlabel("COM lowering below its touchdown height (cm)")
        a.set_ylabel("Vertical GRF (BW)")
        a.set_xlim(left=-1)
        a.set_ylim(bottom=0)
    hd = _trial_handles(res) + [Line2D([], [], color="#6b7280", ls="--", lw=1,
                                       label="stiffness: peak force / peak COM lowering")] + _marker_handles(
        [(MK["max"], "peak force"), (MK["low"], "lowest COM")])
    fig.tight_layout(rect=(0, 0.08, 1, 1))
    _save(fig, path, hd)


def loading_figure(ser, res, path):
    """Loading rate, 20-80% of force (Milner et al. 2006): force rise to the first peak with the
    20% and 80% points and the slope between them."""
    fs, Fz = ser["fs"], ser["Fz"]
    bw = res["body_weight"]["session_bw_N"]
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.2))
    for j, (ev, sec) in enumerate((("td1", "rebound"), ("td2", "landing"))):
        for k, (T, S) in enumerate(zip(res["trials"], ser["trials"])):
            i0 = S[ev]
            n1 = int(round(T[sec][f"{ev}_t_first_peak_s"] * fs))
            seg = Fz[i0:i0 + n1 + int(0.02 * fs)] / bw
            rise = seg[:n1 + 1]
            p1 = rise[-1]
            i20, i80 = int(np.argmax(rise >= 0.2 * p1)), int(np.argmax(rise >= 0.8 * p1))
            t = np.arange(seg.size) / fs * 1000
            lr = T[sec][f"{ev}_lr_f20_80_BW_s"]
            ax[j].plot(t, seg, color=tcol(k), lw=1.1, label=f"Trial {T['number']}: {lr:.1f} BW/s")
            ax[j].plot([t[i20], t[i80]], [rise[i20], rise[i80]], color=tcol(k), lw=1.6, ls="--")
            ax[j].plot([t[i20], t[i80]], [rise[i20], rise[i80]], "o", mfc="white", mec=tcol(k), mew=1.5, ms=6)
            ax[j].plot(t[n1], p1, MK["max"], mfc=tcol(k), mec="black", ms=6)
        ax[j].set_title(f"Loading rate after {ev.upper()}, 20-80% of the first-peak force", fontsize=9.5)
        ax[j].set_xlabel(f"Time from {ev.upper()} (ms)")
        ax[j].set_ylabel("Vertical GRF (BW)")
        ax[j].legend(fontsize=8, loc="upper left", title="loading rate", title_fontsize=8)
    hd = [Line2D([], [], color="#6b7280", ls="--", lw=1.6, label="slope = loading rate"),
          Line2D([], [], ls="", marker="o", mfc="white", mec="#6b7280", mew=1.5, label="20% and 80% of the peak"),
          Line2D([], [], ls="", marker=MK["max"], mfc="#6b7280", mec="black", label="first force peak")]
    fig.tight_layout(rect=(0, 0.08, 1, 1))
    _save(fig, path, hd)


def phase_timeline(res, path):
    """Each trial's phases as one bar: braking, propulsion, flight, absorption, then stance."""
    fig, ax = plt.subplots(figsize=(11, 2.9))
    cols = {"braking (TD1 to lowest COM)": "#dc2626", "propulsion (lowest COM to TO2)": "#f59e0b",
            "flight (TO2 to TD2)": "#e5e7eb", "landing absorption (TD2 to lowest COM)": "#2563eb",
            "to vertical TTS (lowest COM to TTS)": "#93c5fd", "stance after TTS (to end of quiet stance)": "#d1fae5"}
    for k, T in enumerate(res["trials"]):
        e = T["events_s"]
        tts = T.get("tts_short", {}).get("tts_rov100ms_V_s")
        b = [e["td1"], e["td1_lowest_com"], e["to2"], e["td2"], e["td2_lowest_com"],
             e["td2"] + tts if tts else e["td2_lowest_com"], e["stance_end"]]
        y = len(res["trials"]) - k
        for (lab, col), a, c in zip(cols.items(), b[:-1], b[1:]):
            w = (c - a)
            ax.barh(y, w, left=a - e["td1"], color=col, edgecolor="black", lw=0.5, height=0.6)
            if w >= 0.12:
                ax.text(a - e["td1"] + w / 2, y, f"{1000 * w:.0f}", ha="center", va="center", fontsize=7.5)
    ax.set_yticks([len(res["trials"]) - k for k in range(len(res["trials"]))],
                  [f"Trial {T['number']}" for T in res["trials"]])
    ax.set_xlabel("Time from first touchdown TD1 (s); numbers in bars are durations in ms")
    ax.set_title("Phase durations per trial", fontsize=10)
    ax.grid(axis="y", visible=False)
    hd = [Patch(fc=c, ec="black", lw=0.5, label=l) for l, c in cols.items()]
    fig.tight_layout(rect=(0, 0.2, 1, 1))
    _save(fig, path, hd, ncol=3)


def tts_curves(ser, res, path):
    """Range-of-variation TTS: window ranges, cubic fit, pooled quiet reference, TTS."""
    fs = ser["fs"]
    bw = res["body_weight"]["session_bw_N"]
    sig = {"V": lowpass(ser["Fz"], fs, 20.0) - bw, "AP": lowpass(ser["F_ap"], fs, 20.0),
           "ML": lowpass(ser["F_ml"], fs, 20.0)}
    names = {"V": "vertical (Fz - BW)", "AP": "anterior-posterior", "ML": "medial-lateral"}
    ref = res["tts_reference"]["rov_mean_N"]["0.1"]
    nt = len(res["trials"])
    fig, ax = plt.subplots(nt, 3, figsize=(11, 2.5 * nt + 0.8), sharex=True)
    ax = np.atleast_2d(ax)
    for k, (T, S) in enumerate(zip(res["trials"], ser["trials"])):
        dur = (S["se"] - S["td2"]) / fs
        for j, key in enumerate(("V", "AP", "ML")):
            a = ax[k][j]
            c = rov_curve(sig[key][S["td2"]:S["se"]], fs, 0.1)
            a.axvspan(dur - 1.0, dur, color="#fef3c7", lw=0)
            a.semilogy(c["t"], np.clip(c["rov"], 0.5, None), "o", ms=3.2, mfc=tcol(k), mec="none", alpha=0.85)
            v = T["tts_short"].get(f"tts_rov100ms_{key}_s")
            mf = c["tt"] <= (v if v else c["tt"][-1]) + 0.05
            a.semilogy(c["tt"][mf], np.clip(c["fit"][mf], 0.5, None), color="black", lw=1.1)
            a.axhline(ref[key], color="#6b7280", ls="--", lw=0.9)
            if v:
                a.axvline(v, color=tcol(k), lw=1.6)
                a.text(v + 0.04, 0.95, f"TTS {v:.2f} s", transform=a.get_xaxis_transform(), fontsize=8,
                       va="top", color=tcol(k), fontweight="bold")
            a.set_ylim(0.5, None)
            if k == 0:
                a.set_title(names[key], fontsize=9.5)
            if j == 0:
                a.set_ylabel(f"Trial {T['number']}\nrange per 0.1 s (N)")
            if k == nt - 1:
                a.set_xlabel("Time from landing TD2 (s)")
    hd = [Line2D([], [], ls="", marker="o", mfc="#6b7280", mec="none", label="force range in each 0.1 s window"),
          Line2D([], [], color="black", lw=1.1, label="cubic fit from the largest early range (shown to TTS)"),
          Line2D([], [], color="#6b7280", ls="--", lw=0.9, label="pooled quiet-stance reference"),
          Line2D([], [], color="#6b7280", lw=1.6, label="TTS: fit reaches the reference"),
          Patch(fc="#fef3c7", label="last 1 s of stance (reference window)")]
    fig.tight_layout(rect=(0, 0.06, 1, 1))
    _save(fig, path, hd, ncol=3)


def tts_methods(res, path):
    """Every TTS method and setting per axis, as a dot plot."""
    methods = [("rov100ms", "range of variation, 0.1 s"), ("rov200ms", "range of variation, 0.2 s"),
               ("rov250ms", "range of variation, 0.25 s"), ("rms_x1.5", "moving RMS < 1.5 x quiet"),
               ("rms_x2", "moving RMS < 2 x quiet"), ("rms_x3", "moving RMS < 3 x quiet")]
    fig, ax = plt.subplots(1, 3, figsize=(11, 3.8), sharey=True, sharex=True)
    for j, (key, lab) in enumerate((("V", "vertical"), ("AP", "anterior-posterior"), ("ML", "medial-lateral"))):
        for i, (m, ml) in enumerate(methods):
            for k, T in enumerate(res["trials"]):
                v = T.get("tts_short", {}).get(f"tts_{m}_{key}_s")
                if v is not None:
                    ax[j].plot(v, len(methods) - 1 - i + (k - 1) * 0.18, "o", mfc=tcol(k), mec="black", ms=6,
                               mew=0.5)
        ax[j].axhspan(len(methods) - 1.5, len(methods) - 0.5, color="#fef3c7", lw=0)
        ax[j].set_title(lab, fontsize=9.5)
        ax[j].set_xlabel("TTS from TD2 (s)")
    ax[0].set_yticks(range(len(methods)), [m[1] for m in methods][::-1], fontsize=8)
    hd = _trial_handles(res, dots=True) + [Patch(fc="#fef3c7", label="main method")]
    fig.tight_layout(rect=(0, 0.08, 1, 1))
    _save(fig, path, hd)


def dpsi_bars(res, path):
    """DPSI and its three terms per trial (common window)."""
    keys = [("APSI", "APSI\n(anterior-posterior)"), ("MLSI", "MLSI\n(medial-lateral)"), ("VSI", "VSI\n(vertical)"),
            ("DPSI", "DPSI\n(composite)")]
    fig, ax = plt.subplots(figsize=(8.5, 3.6))
    for k, T in enumerate(res["trials"]):
        d = T.get("dpsi_common", {})
        x = np.arange(len(keys)) + (k - 1) * 0.26
        bars = ax.bar(x, [d.get(c) or 0 for c, _ in keys], width=0.26, color=tcol(k), edgecolor="black", lw=0.5)
        ax.bar_label(bars, fmt="%.3f", fontsize=7, padding=1)
    ax.set_xticks(np.arange(len(keys)), [lab for _, lab in keys], fontsize=8.5)
    ax.set_ylabel("Index (unitless)")
    ax.set_title(f"Dynamic postural stability index, first {res['common_window_s']:.1f} s after TD2", fontsize=10)
    ax.margins(y=0.12)
    fig.tight_layout(rect=(0, 0.1, 1, 1))
    _save(fig, path, _trial_handles(res, bars=True))


def cop_stance_overlay(ser, res, path):
    """COP AP and ML during the landing stance, each trial minus its own stance mean."""
    fs = ser["fs"]
    fig, ax = plt.subplots(2, 1, figsize=(11, 5.4), sharex=True)
    for k, S in enumerate(ser["trials"]):
        for r, name in enumerate(("cop_ap", "cop_ml")):
            c = ser[name][S["td2"]:S["se"]]
            t = np.arange(c.size) / fs
            ax[r].plot(t, c - np.nanmean(c), color=tcol(k), lw=1.0)
    for r, lab in enumerate(("COP AP (mm)\nanterior +", "COP ML (mm)\nlateral +")):
        ax[r].axvspan(0, 0.02, color="#e5e7eb", lw=0)
        ax[r].axvline(0.4, color="#6b7280", ls="--", lw=0.8)
        ax[r].axhline(0, color="#9ca3af", lw=0.6)
        ax[r].set_ylabel(lab)
    ax[1].set_xlabel("Time from landing TD2 (s)")
    ax[0].set_title("Centre of pressure during the landing stance (20 Hz), each trial minus its stance mean",
                    fontsize=10)
    hd = _trial_handles(res) + [Patch(fc="#e5e7eb", label="first 20 ms masked (impact)"),
                                Line2D([], [], color="#6b7280", ls="--", lw=0.8,
                                       label="0.4 s: start of the stance window for COP metrics")]
    fig.tight_layout(rect=(0, 0.07, 1, 1))
    _save(fig, path, hd)


def cop_metric_bars(res, path):
    """COP metrics per window and trial."""
    wins = [("td1_20_200ms", "TD1\n20-200 ms"), ("td1_contact", "TD1+20 ms\nto TO2"),
            ("td2_20_200ms", "TD2\n20-200 ms"), ("td2_dynamic_0.4s_to_end", "TD2 0.4 s\nto end")]
    mets = [("path_mm", "Path length (mm)"), ("mean_velocity_mm_s", "Mean velocity (mm/s)"),
            ("ellipse95_area_mm2", "95% ellipse area (mm²)"), ("ap_range_mm", "AP range (mm)"),
            ("ml_range_mm", "ML range (mm)"), ("rms_distance_mm", "RMS distance (mm)")]
    fig, ax = plt.subplots(2, 3, figsize=(11, 6.2))
    for q, (mk, lab) in enumerate(mets):
        a = ax.flat[q]
        for k, T in enumerate(res["trials"]):
            x = np.arange(len(wins)) + (k - 1) * 0.26
            a.bar(x, [T["cop"][w].get(mk) or 0 for w, _ in wins], width=0.26, color=tcol(k), edgecolor="black", lw=0.4)
        a.set_xticks(np.arange(len(wins)), [w[1] for w in wins], fontsize=7)
        a.set_title(lab, fontsize=9.5)
    fig.suptitle("Centre-of-pressure metrics by window", fontsize=10)
    fig.tight_layout(rect=(0, 0.05, 1, 1))
    _save(fig, path, _trial_handles(res, bars=True))


def emg_overlay(ser, res, path, pre=0.3, post=0.4):
    """EMG envelopes aligned at TD1 and TD2, with the analysis windows."""
    te = ser["te"]
    fig, ax = plt.subplots(2, 2, figsize=(11, 6), sharey=True)
    for r, name in enumerate(("EMG1", "EMG2")):
        for j, ev in enumerate(("td1", "td2")):
            a = ax[r][j]
            a.axvspan(-0.15, 0, color="#fde68a", alpha=0.6, lw=0)
            a.axvspan(0, 0.05, color="#bfdbfe", alpha=0.9, lw=0)
            a.axvspan(0, 0.2, ymin=0, ymax=0.04, color="#6b7280", lw=0)
            for k, T in enumerate(res["trials"]):
                t0 = T["events_s"][ev]
                m = (te >= t0 - pre) & (te <= t0 + post)
                a.plot(te[m] - t0, 100 * ser["emg_env"][name][m], color=tcol(k), lw=1.1)
            a.axvline(0, color=EV_STYLE[ev][0], ls="--", lw=0.8)
            a.set_ylim(0, 105)
            a.set_title(f"{name} around {ev.upper()}", fontsize=9.5)
            if j == 0:
                a.set_ylabel(f"{name} (% session peak)")
            if r == 1:
                a.set_xlabel(f"Time from {ev.upper()} (s)")
    hd = _trial_handles(res) + [Patch(fc="#fde68a", alpha=0.6, label="pre-activation, 150 ms before contact"),
                                Patch(fc="#bfdbfe", label="0-50 ms after contact"),
                                Patch(fc="#6b7280", label="0-200 ms window (bar at the base)"),
                                Line2D([], [], color=C["ev"], ls="--", lw=0.8, label="touchdown")]
    fig.tight_layout(rect=(0, 0.1, 1, 1))
    _save(fig, path, hd, ncol=4)


def emg_bars(res, path):
    """EMG window values per trial (rectified-signal means, % of the session 50 ms peak)."""
    mets = [("pre100_pct", "100 ms\nbefore"), ("pre150_pct", "150 ms\nbefore"), ("post50_pct", "0-50 ms\nafter"),
            ("slr_30_60ms_pct", "30-60 ms\nafter"),
            ("post200_pct", "0-200 ms\nafter"), ("peak_post_pct", "envelope peak\n0-200 ms")]
    fig, ax = plt.subplots(2, 2, figsize=(11, 6.2), sharey=True)
    for r, name in enumerate(("EMG1", "EMG2")):
        for j, ev in enumerate(("td1", "td2")):
            a = ax[r][j]
            for k, T in enumerate(res["trials"]):
                x = np.arange(len(mets)) + (k - 1) * 0.26
                bars = a.bar(x, [T["emg"][name][ev].get(m) or 0 for m, _ in mets], width=0.26, color=tcol(k),
                             edgecolor="black", lw=0.4)
                a.bar_label(bars, fmt="%.0f", fontsize=6.5, padding=1)
            a.set_xticks(np.arange(len(mets)), [m[1] for m in mets], fontsize=7.5)
            a.set_title(f"{name}, {ev.upper()}", fontsize=9.5)
            a.set_ylim(0, 115)
            if j == 0:
                a.set_ylabel("% of session peak")
    fig.tight_layout(rect=(0, 0.05, 1, 1))
    _save(fig, path, _trial_handles(res, bars=True))


def fppa_trace(ser, res, path):
    """Knee frontal-plane projection angle from the video, aligned at TD2."""
    if "pose" not in ser:
        return False
    off = res["video"]["offset_s"]
    tp = ser["pose"]["t"] - off
    fp = ser["pose"]["fppa"]
    kin = res["video"].get("kinematics") or []
    fig, ax = plt.subplots(figsize=(11, 3.8))
    for k, T in enumerate(res["trials"]):
        e = T["events_s"]
        m = (tp >= e["td1"] - 0.2) & (tp <= e["stance_end"])
        t = tp[m] - e["td2"]
        ax.plot(t, fp[m], "-", color=tcol(k), lw=1.0, marker=".", ms=3)
        if k < len(kin) and kin[k].get("fppa_at_td2_deg") is not None:
            i = np.where(tp >= e["td2"])[0]
            if i.size:
                ax.plot(tp[i[0]] - e["td2"], kin[k]["fppa_at_td2_deg"], "o", mfc=tcol(k), mec="black", ms=7)
        for key, mk in (("td1", "<"), ("to2", "^")):
            ax.plot(e[key] - e["td2"], 1.0, mk, color=tcol(k), transform=ax.get_xaxis_transform(), ms=8, clip_on=False)
    ax.axvline(0, color=EV_STYLE["td2"][0], ls="--", lw=0.8)
    ax.axvspan(0, 0.5, color="#fef3c7", lw=0)
    ax.set_xlabel("Time from landing TD2 (s)")
    ax.set_ylabel("Knee FPPA (deg)")
    ax.set_title("Stance-knee FPPA from the video: ASIS marker, knee and ankle (each dot = one frame)", fontsize=10)
    hd = _trial_handles(res) + _marker_handles([("o", "first frame after TD2"), ("<", "TD1 (top edge)"),
                                                ("^", "TO2 (top edge)")]) + \
        [Patch(fc="#fef3c7", label="0-0.5 s after TD2 (peak and change window)")]
    fig.tight_layout(rect=(0, 0.1, 1, 1))
    _save(fig, path, hd, ncol=4)
    return True


def consistency(res, items, path):
    """Each trial as % difference from the 3-trial mean, with the CV, for the key measures."""
    labs, devs, cvs = [], [], []
    for path_, lab, _unit, sc, _dec, _note in items:
        v = []
        for T in res["trials"]:
            x = T
            for p in path_:
                x = x.get(p) if isinstance(x, dict) else None
            v.append(float(x) * sc if isinstance(x, (int, float)) else np.nan)
        v = np.array(v)
        mu = np.nanmean(v)
        if not np.isfinite(mu) or abs(mu) < 1e-12:
            continue
        labs.append(lab)
        devs.append(100 * (v - mu) / abs(mu))
        cvs.append(100 * np.nanstd(v, ddof=1) / abs(mu))
    n = len(labs)
    fig, ax = plt.subplots(figsize=(10, 0.32 * n + 1.4))
    for i, (d, cv) in enumerate(zip(devs, cvs)):
        y = n - 1 - i
        ax.plot([np.nanmin(d), np.nanmax(d)], [y, y], color="#d1d5db", lw=3, solid_capstyle="round", zorder=1)
        for k, x in enumerate(d):
            ax.plot(x, y, "o", mfc=tcol(k), mec="black", mew=0.5, ms=6, zorder=2)
        ax.text(1.01, y, f"CV {cv:.0f}%", transform=ax.get_yaxis_transform(), va="center", fontsize=7.5)
    ax.axvline(0, color="#6b7280", lw=0.8)
    ax.set_yticks(range(n), labs[::-1], fontsize=7.5)
    ax.set_xlabel("Difference from the 3-trial mean (%)")
    ax.set_title("Trial-to-trial spread of the key measures", fontsize=10)
    ax.grid(axis="y", visible=False)
    hd = _trial_handles(res, dots=True) + [Line2D([], [], color="#d1d5db", lw=3, label="range of the three trials"),
                                Line2D([], [], color="#6b7280", lw=0.8, label="3-trial mean")]
    fig.tight_layout(rect=(0, 0.04, 1, 1))
    _save(fig, path, hd)


def cop_entropy_figure(res, path):
    """COP sample entropy against COP displacement, during the TTS phase and after it."""
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.3))
    for j, c in enumerate(("AP", "ML")):
        for k, T in enumerate(res["trials"]):
            E = T.get("cop_entropy")
            if not E:
                continue
            p, q = E["td2_tts_phase"], E["td2_after_tts"]
            ax[j].annotate("", xy=(q[f"range_{c}_mm"], q[f"sampen_{c}"]), xytext=(p[f"range_{c}_mm"], p[f"sampen_{c}"]),
                           arrowprops={"arrowstyle": "->", "color": tcol(k), "lw": 1.2})
            ax[j].plot(p[f"range_{c}_mm"], p[f"sampen_{c}"], "o", mfc=tcol(k), mec="black", ms=9)
            ax[j].plot(q[f"range_{c}_mm"], q[f"sampen_{c}"], "s", mfc="white", mec=tcol(k), mew=2, ms=8)
        ax[j].set_title(f"{'Anterior-posterior' if c == 'AP' else 'Medial-lateral'} COP", fontsize=9.5)
        ax[j].set_xlabel(f"{c} COP displacement in the window (mm)")
        ax[j].set_ylabel("Sample entropy of COP velocity")
        ax[j].set_ylim(bottom=0)
        ax[j].set_xlim(left=0)
    hd = [Patch(fc=tcol(k), ec="black", lw=0.5, label=f"Trial {T['number']}") for k, T in enumerate(res["trials"])]
    hd += [Line2D([], [], ls="", marker="o", mfc="#9ca3af", mec="black", ms=8, label="TTS phase (TD2 + 150 ms to settled)"),
           Line2D([], [], ls="", marker="s", mfc="white", mec="#6b7280", mew=2, ms=8, label="after TTS (to end of stance)"),
           Line2D([], [], color="#6b7280", lw=1.2, label="arrow: change during recovery")]
    fig.tight_layout(rect=(0, 0.1, 1, 1))
    _save(fig, path, hd, ncol=3)


def cocontraction_figure(ser, res, path, pre=0.15, post=0.05):
    """VL (EMG1) and BF (EMG2) around TD2, with their common area, and the co-contraction index per window."""
    te = ser["te"]
    sm = ser["emg_sm"]
    nt = len(res["trials"])
    fig = plt.figure(figsize=(11, 6.4))
    gs = fig.add_gridspec(2, nt, height_ratios=[1.2, 1], hspace=0.45)
    for k, T in enumerate(res["trials"]):
        a = fig.add_subplot(gs[0, k])
        t0 = T["events_s"]["td2"]
        m = (te >= t0 - pre - 0.05) & (te <= t0 + post + 0.05)
        t = te[m] - t0
        vl, bf = 100 * sm["EMG1"][m], 100 * sm["EMG2"][m]
        a.axvspan(-pre, 0, color="#fde68a", alpha=0.45, lw=0)
        a.axvspan(0, post, color="#bfdbfe", alpha=0.7, lw=0)
        a.fill_between(t, 0, np.minimum(vl, bf), color="#9ca3af", alpha=0.6, lw=0)
        a.plot(t, vl, color=C["emg1"], lw=1.3)
        a.plot(t, bf, color=C["emg2"], lw=1.3)
        a.axvline(0, color=EV_STYLE["td2"][0], ls="--", lw=0.8)
        cc = T["cocontraction"]["td2"]
        a.set_title(f"Trial {T['number']}: CCI {cc['pre150']['cci_pct']:.0f}% before, {cc['post50']['cci_pct']:.0f}% after",
                    fontsize=9)
        a.set_xlabel("Time from TD2 (s)")
        a.set_ylim(0, 105)
        if k == 0:
            a.set_ylabel("EMG (% session peak)")
    b = fig.add_subplot(gs[1, :])
    labs = [("td1", "pre150", "TD1, 150 ms before"), ("td1", "post50", "TD1, 0-50 ms after"),
            ("td2", "pre150", "TD2, 150 ms before"), ("td2", "post50", "TD2, 0-50 ms after")]
    for k, T in enumerate(res["trials"]):
        x = np.arange(len(labs)) + (k - 1) * 0.26
        bars = b.bar(x, [T["cocontraction"][e][w]["cci_pct"] for e, w, _ in labs], width=0.26, color=tcol(k),
                     edgecolor="black", lw=0.5)
        b.bar_label(bars, fmt="%.0f", fontsize=7, padding=1)
    b.set_xticks(np.arange(len(labs)), [l for _, _, l in labs], fontsize=8.5)
    b.set_ylabel("VL-BF co-contraction index (%)")
    b.set_ylim(0, 110)
    hd = [Line2D([], [], color=C["emg1"], lw=1.3, label="VL (EMG1)"), Line2D([], [], color=C["emg2"], lw=1.3, label="BF (EMG2)"),
          Patch(fc="#9ca3af", alpha=0.6, label="common area (co-contraction)"),
          Patch(fc="#fde68a", alpha=0.45, label="150 ms before contact"), Patch(fc="#bfdbfe", alpha=0.7, label="0-50 ms after"),
          Line2D([], [], color=C["ev"], ls="--", lw=0.8, label="TD2")]
    hd += [Patch(fc=tcol(k), ec="black", lw=0.5, label=f"Trial {T['number']} (bars)") for k, T in enumerate(res["trials"])]
    fig.subplots_adjust(bottom=0.2, top=0.94)
    _save(fig, path, hd, ncol=5)
