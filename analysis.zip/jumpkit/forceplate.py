"""Force-plate signals: scaling, drift-corrected zeroing and Kistler force/moment/COP.

A piezoelectric plate drifts while it is loaded, so one zero taken at the start is not
enough. Here each of the 8 channels gets its own baseline, measured in every unloaded
period (before and between trials, and in the rebound flight phase). The baseline is
interpolated linearly in time between those anchors and subtracted.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .adicht import Record
from .signals import bouts, lowpass


@dataclass
class Plate:
    fs: float
    t: np.ndarray
    raw_N: dict                  # channel name -> N, before zeroing
    ch_N: dict                   # channel name -> N, after zeroing
    Fx: np.ndarray
    Fy: np.ndarray
    Fz: np.ndarray
    Mx: np.ndarray
    My: np.ndarray
    Mz: np.ndarray
    COPx_mm: np.ndarray          # NaN where Fz is below the COP validity threshold
    COPy_mm: np.ndarray
    cop_min_N: float
    unloaded_mask: np.ndarray
    anchors: list = field(default_factory=list)   # (t_mid, {channel: baseline N})
    drift_N: dict = field(default_factory=dict)   # channel -> max - min baseline over the record
    noise_sd_N: float = float("nan")              # SD of zeroed Fz in unloaded periods
    pkres_N: float = float("nan")                 # peak |Fz| residual in unloaded periods


def scale_plate(rec: Record, cfg: dict) -> tuple[float, dict]:
    p = cfg["plate"]
    out, fs = {}, None
    for k, c in p["channels"].items():
        ch = rec.channels[int(k)]
        fs = ch.fs
        out[c["name"]] = ch.counts.astype(float) * p["volts_per_count"] * c["N_per_V"]
    return fs, out


def kistler(ch: dict, p: dict) -> dict:
    """Kistler 8-channel equations with the lab's output gain (LabChart calculations)."""
    g, a, b = p["output_gain"], p["a_m"], p["b_m"]
    Fx = g * (ch["fx12"] + ch["fx34"])
    Fy = g * (ch["fy14"] + ch["fy23"])
    Fz = g * (ch["fz1"] + ch["fz2"] + ch["fz3"] + ch["fz4"])
    Mx = g * b * (ch["fz1"] + ch["fz2"] - ch["fz3"] - ch["fz4"])
    My = g * a * (-ch["fz1"] + ch["fz2"] + ch["fz3"] - ch["fz4"])
    Mz = g * (b * (-ch["fx12"] + ch["fx34"]) + a * (ch["fy14"] - ch["fy23"]))
    return dict(Fx=Fx, Fy=Fy, Fz=Fz, Mx=Mx, My=My, Mz=Mz)


def find_unloaded(Fz_raw: np.ndarray, fs: float, thr_N: float = 30.0, min_s: float = 0.15,
                  trim_s: float = 0.04) -> np.ndarray:
    """Mask of clearly unloaded samples, with transition edges trimmed off.

    The provisional zero is the lowest median among quiet 0.25 s windows (SD within 3x the
    quietest window). A standing start or a CMJ, where the plate is loaded most of the
    time, still gives the empty-plate level, as long as one flight or empty period exists.
    """
    w = max(5, int(round(0.25 * fs)))
    starts = np.arange(0, max(1, Fz_raw.size - w), max(1, w // 2))
    med = np.array([np.median(Fz_raw[i:i + w]) for i in starts])
    sd = np.array([np.std(Fz_raw[i:i + w]) for i in starts])
    quiet = sd <= max(3 * sd.min(), 2.0)
    lo = float(med[quiet].min())
    rough = Fz_raw - lo
    mask = np.zeros(len(Fz_raw), bool)
    trim = int(round(trim_s * fs))
    for s, e in bouts(rough < thr_N):
        if (e - s) / fs >= min_s and e - s > 2 * trim:
            mask[s + trim:e - trim] = True
    return mask


def build_plate(rec: Record, cfg: dict, cop_min_frac_bw: float = 0.10, cop_min_N: float = 50.0,
                bw_guess_N: float | None = None, cop_fc: float = 20.0) -> Plate:
    p = cfg["plate"]
    fs, raw = scale_plate(rec, cfg)
    n = len(next(iter(raw.values())))
    t = np.arange(n) / fs
    Fz_raw = kistler(raw, p)["Fz"]
    unl = find_unloaded(Fz_raw, fs)

    # Baseline anchors: median of each unloaded period, per channel.
    anchors = []
    for s, e in bouts(unl):
        anchors.append((0.5 * (t[s] + t[e - 1]), {k: float(np.median(v[s:e])) for k, v in raw.items()}))
    if not anchors:
        raise RuntimeError("no unloaded period found; cannot zero the plate")
    ta = np.array([a[0] for a in anchors])
    ch, drift = {}, {}
    for k, v in raw.items():
        base_pts = np.array([a[1][k] for a in anchors])
        ch[k] = v - np.interp(t, ta, base_pts)
        drift[k] = float(base_pts.max() - base_pts.min())

    F = kistler(ch, p)
    noise = float(np.std(F["Fz"][unl])) if unl.any() else float("nan")
    pkres = float(np.max(np.abs(F["Fz"][unl]))) if unl.any() else float("nan")

    # COP is only meaningful when the vertical load is large enough: Fz >= max(50 N, 10% BW)
    # (COP error grows as 1/Fz; Bobbert & Schamhardt 1990; Schmiedmayer & Kastner 2000).
    if bw_guess_N is None:
        loaded = F["Fz"][F["Fz"] > 100]
        bw_guess_N = float(np.median(loaded)) if loaded.size else 600.0
    cop_min = max(cop_min_N, cop_min_frac_bw * bw_guess_N)
    # COP from 20 Hz low-passed forces and moments (filtering before the division keeps
    # plate-impact transients out of the ratio). Samples near touchdown are masked later.
    Ff = {k: lowpass(F[k], fs, cop_fc) for k in ("Fx", "Fy", "Fz", "Mx", "My")}
    with np.errstate(divide="ignore", invalid="ignore"):
        ok = (F["Fz"] > cop_min) & (Ff["Fz"] > cop_min)
        copx = np.where(ok, (Ff["Fx"] * p["az0_m"] - Ff["My"]) / Ff["Fz"], np.nan) * 1000.0
        copy = np.where(ok, (Ff["Fy"] * p["az0_m"] + Ff["Mx"]) / Ff["Fz"], np.nan) * 1000.0

    return Plate(fs=fs, t=t, raw_N=raw, ch_N=ch, COPx_mm=copx, COPy_mm=copy, cop_min_N=cop_min,
                 unloaded_mask=unl, anchors=anchors, drift_N=drift, noise_sd_N=noise,
                 pkres_N=pkres, **F)


def lab_tare_check(rec1: Record, cfg: dict) -> dict:
    """Compare our zero-load channel values in a record with the lab's stored tare values."""
    _, raw = scale_plate(rec1, cfg)
    names = {k: c["name"] for k, c in cfg["plate"]["channels"].items()}
    out = {}
    for k, lab in cfg["plate"]["lab_tare_N"].items():
        ours = float(np.median(raw[names[k]][: int(1.0 * rec1.channels[int(k)].fs)]))
        out[names[k]] = {"ours_N": ours, "lab_N": lab, "diff_N": ours - lab}
    return out
