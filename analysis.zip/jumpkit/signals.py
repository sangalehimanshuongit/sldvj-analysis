"""Small signal-processing helpers shared by every module."""
from __future__ import annotations

import numpy as np
from scipy.signal import butter, sosfiltfilt


def bouts(mask: np.ndarray) -> list[tuple[int, int]]:
    """Return (start, end) index pairs of True runs; end is exclusive."""
    m = np.asarray(mask, bool)
    if m.size == 0:
        return []
    d = np.diff(m.astype(np.int8))
    starts = list(np.where(d == 1)[0] + 1)
    ends = list(np.where(d == -1)[0] + 1)
    if m[0]:
        starts.insert(0, 0)
    if m[-1]:
        ends.append(m.size)
    return list(zip(starts, ends))


def lowpass(x: np.ndarray, fs: float, fc: float, order: int = 4) -> np.ndarray:
    """Zero-lag Butterworth low-pass. order is the design order (effective order doubles)."""
    sos = butter(order, fc / (0.5 * fs), btype="low", output="sos")
    return sosfiltfilt(sos, np.asarray(x, float))


def bandpass(x: np.ndarray, fs: float, lo: float, hi: float, order: int = 4) -> np.ndarray:
    sos = butter(order, [lo / (0.5 * fs), hi / (0.5 * fs)], btype="band", output="sos")
    return sosfiltfilt(sos, np.asarray(x, float))


def highpass(x: np.ndarray, fs: float, fc: float, order: int = 4) -> np.ndarray:
    sos = butter(order, fc / (0.5 * fs), btype="high", output="sos")
    return sosfiltfilt(sos, np.asarray(x, float))


def cumtrapz0(y: np.ndarray, dt: float) -> np.ndarray:
    """Cumulative trapezoid integral that starts at 0 and keeps the input length."""
    y = np.asarray(y, float)
    out = np.zeros_like(y)
    out[1:] = np.cumsum(0.5 * (y[1:] + y[:-1])) * dt
    return out


def nanpath(x: np.ndarray, y: np.ndarray) -> float:
    """Path length summed within valid runs only (no jumps across NaN gaps)."""
    ok = np.isfinite(x) & np.isfinite(y)
    if ok.sum() < 2:
        return float("nan")
    total = 0.0
    for s, e in bouts(ok):
        if e - s > 1:
            total += float(np.sum(np.hypot(np.diff(x[s:e]), np.diff(y[s:e]))))
    return total


def ellipse95(x: np.ndarray, y: np.ndarray) -> dict:
    """95% prediction ellipse of a 2-D point cloud (chi-square, 2 df).

    Area = pi * chi2(0.95, 2) * sqrt(lambda1 * lambda2), with chi2 = 5.991.
    """
    ok = np.isfinite(x) & np.isfinite(y)
    x, y = x[ok], y[ok]
    if x.size < 5:
        return {"area_mm2": float("nan")}
    cov = np.cov(np.vstack([x, y]))
    w, v = np.linalg.eigh(cov)
    w = np.clip(w, 0, None)
    k = 5.991464547107979
    major = np.sqrt(k * w[1])
    minor = np.sqrt(k * w[0])
    ang = float(np.degrees(np.arctan2(v[1, 1], v[0, 1])))
    return {"area_mm2": float(np.pi * major * minor), "semi_major_mm": float(major),
            "semi_minor_mm": float(minor), "angle_deg": ang,
            "cx": float(x.mean()), "cy": float(y.mean())}
