"""Blind cross-session comparison of drop-jump sessions.

Stacks every ``session_summary_<session>_<participant>.csv`` into one table keyed by session
code only, with each measure's mean, SD and MDC95 (2.77 x the trial-to-trial SD, as in
``report_extra.cycle_panel``). A code-to-group mapping (supplied by the lab after unblinding)
is optional. Without it, sessions are never grouped or labelled by cycle phase.
"""
from __future__ import annotations

import glob
import os
import re

import numpy as np
import pandas as pd

from .report_extra import PANEL

MDC_FACTOR = 2.77                           # 1.96 * sqrt(2)
ID_COLS = ["session", "participant_code", "session_code", "file", "n_trials"]


def measure_key(label: str) -> str:
    """Column stem used in the session summary (same rule as report_extra.cycle_panel)."""
    return re.sub(r"[^a-z0-9]+", "_", label.lower()).strip("_")


MEASURES = [(measure_key(lab), lab, unit) for _, lab, unit, _, _, _ in PANEL]


def find_summaries(root: str) -> list[str]:
    return sorted(glob.glob(os.path.join(root, "**", "session_summary_*.csv"), recursive=True))


def load_summaries(paths) -> pd.DataFrame:
    """One row per session. A session found twice (same file name) keeps its newest summary."""
    rows = []
    for p in paths:
        d = pd.read_csv(p, dtype={"participant_code": str, "session_code": str})
        d["_mtime"] = os.path.getmtime(p)
        rows.append(d)
    if not rows:
        raise SystemExit("no session_summary_*.csv found")
    df = pd.concat(rows, ignore_index=True).sort_values("_mtime").drop_duplicates("file", keep="last")
    df["session"] = df["session_code"].astype(str) + "_" + df["participant_code"].astype(str)
    return df.drop(columns="_mtime").sort_values("session").reset_index(drop=True)


def long_table(summ: pd.DataFrame) -> pd.DataFrame:
    """Session x measure: mean, SD, MDC95."""
    out = []
    for _, r in summ.iterrows():
        for key, lab, unit in MEASURES:
            m, s = r.get(f"{key}_mean"), r.get(f"{key}_sd")
            out.append({**{c: r[c] for c in ID_COLS}, "measure": lab, "unit": unit,
                        "mean": m, "sd": s, "mdc95": MDC_FACTOR * s if pd.notna(s) else np.nan})
    return pd.DataFrame(out)


def apply_mapping(tab: pd.DataFrame, mapping: pd.DataFrame) -> pd.DataFrame:
    """Add a 'group' column from a mapping CSV with columns 'session' (for example AB_1234) and 'group'.

    Sessions missing from the mapping stop the run, so no session is grouped by accident."""
    mp = mapping.astype(str).set_index("session")["group"]
    missing = sorted(set(tab["session"]) - set(mp.index))
    if missing:
        raise SystemExit(f"mapping has no group for: {', '.join(missing)}")
    return tab.assign(group=tab["session"].map(mp))


def group_table(tab: pd.DataFrame) -> pd.DataFrame:
    """Per group and measure: number of sessions, mean of session means, SD between sessions,
    pooled within-session SD and its MDC95. Only built when a mapping was given."""
    rows = []
    for (g, lab), d in tab.groupby(["group", "measure"], sort=False):
        pooled = float(np.sqrt(np.nanmean(d["sd"] ** 2))) if d["sd"].notna().any() else np.nan
        rows.append({"group": g, "measure": lab, "unit": d["unit"].iloc[0], "n_sessions": len(d),
                     "mean": d["mean"].mean(), "sd_between": d["mean"].std(ddof=1) if len(d) > 1 else np.nan,
                     "sd_within_pooled": pooled, "mdc95_pooled": MDC_FACTOR * pooled})
    return pd.DataFrame(rows)


def figure(tab: pd.DataFrame, path: str) -> str:
    """One panel per measure: session mean (dot), trial SD (thick bar) and mean +/- MDC95 (light band).

    With a 'group' column the sessions are ordered and coloured by group; otherwise by code only."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch

    grouped = "group" in tab.columns
    order = (tab.drop_duplicates("session").sort_values(["group", "session"] if grouped else ["session"])["session"].tolist())
    groups = sorted(tab["group"].unique()) if grouped else []
    pal = ["#2563eb", "#d97706", "#059669", "#7c3aed", "#be185d", "#0891b2"]
    gcol = {g: pal[i % len(pal)] for i, g in enumerate(groups)}
    meas = [m for _, m, _ in MEASURES if m in set(tab["measure"])]
    nc = 4
    nr = int(np.ceil((len(meas) + 1) / nc))
    fig, axs = plt.subplots(nr, nc, figsize=(3.2 * nc, max(2.3 * nr, 3)), squeeze=False)
    x = {s: i for i, s in enumerate(order)}
    for ax, lab in zip(axs.flat, meas):
        d = tab[tab["measure"] == lab]
        for _, r in d.iterrows():
            col = gcol.get(r.get("group"), "#1f2937") if grouped else "#1f2937"
            xi = x[r["session"]]
            if pd.notna(r["mdc95"]):
                ax.fill_between([xi - 0.3, xi + 0.3], r["mean"] - r["mdc95"], r["mean"] + r["mdc95"],
                                color=col, alpha=0.15, lw=0)
            if pd.notna(r["sd"]):
                ax.errorbar(xi, r["mean"], yerr=r["sd"], fmt="none", ecolor=col, elinewidth=2.2, capsize=0)
            ax.plot(xi, r["mean"], "o", color=col, ms=5)
        unit = d["unit"].iloc[0]
        ax.set_title(lab + (f" ({unit})" if unit else ""), fontsize=8)
        ax.set_xticks(range(len(order)))
        ax.set_xticklabels(order, fontsize=7, rotation=45 if len(order) > 4 else 0, ha="right" if len(order) > 4 else "center")
        ax.set_xlim(-0.6, len(order) - 0.4)
        ax.tick_params(axis="y", labelsize=7)
        ax.grid(alpha=0.3)
        ax.spines[["top", "right"]].set_visible(False)
    rest = list(axs.flat)[len(meas):]
    for ax in rest:
        ax.axis("off")
    h = [Line2D([], [], ls="", marker="o", color="#1f2937", label="session mean (3 trials)"),
         Line2D([], [], color="#1f2937", lw=2.2, label="± trial-to-trial SD"),
         Patch(color="#1f2937", alpha=0.15, label="± MDC95 (2.77 × SD): a smaller\nchange is within trial noise")]
    if grouped:
        h += [Patch(color=gcol[g], label=f"group {g}") for g in groups]
    rest[0].legend(handles=h, loc="center left", fontsize=7.5, frameon=False, title="Key", title_fontsize=8,
                   alignment="left")
    fig.suptitle("Sessions compared by code" + (" and lab-supplied group" if grouped else " only (blind: no grouping)"),
                 fontsize=10)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)
    return path
